# # 不同的api的参数不同 使用functools.partial 对函数进行默认参数设置
# from functools import partial
# import tushare as ts
#
#
# # 对于所有接口
# apis = {}
# # 查询当前所有正常上市交易的股票列表
# # 名称	类型	默认显示	描述
#
# # ts_code	str	Y	TS代码
#
# # name	str	Y	股票名称
#
# # area	str	Y	地域
#
# # industry	str	Y	所属行业
#
# # market	str	Y	市场类型（主板/创业板/科创板/CDR）
#
# # list_status	str	N	上市状态 L上市 D退市 P暂停上市
#
# # list_date	str	Y	上市日期
#
# # delist_date	str	N	退市日期
# apis["stock_basic"] = partial(
#     ts.stock_basic,
#     exchange="",
#     list_status="L",
#     fields="ts_code,name,area,industry,market, list_status, list_date, delist_date",
# )
#
# # 日线行情 前复权
# apis["daily_qfq"] = partial(
#     ts.pro_bar, start_date=start_time, adj="qfq", end_date=end_time
# )
# # 日线行情 后复权
# apis["daily_hfq"] = partial(
#     ts.pro_bar, start_date=start_time, adj="hfq", end_date=end_time
# )
# # 每日指标 交易量 换手率等
# fields = "ts_code, trade_date, close, turnover_rate, turnover_rate_f, volume_ratio, pe, pe_ttm, pb, ps, ps_ttm, dv_ratio, dv_ttm, total_share, float_share, free_share, total_mv, circ_mv"
# apis["daily_basic"] = partial(
#     pro.daily_basic, start_date=start_time, end_date=end_time, fields=fields
# )
#
# # 每日涨跌停
# apis["limit_list"] = partial(pro.limit_list, start_date=start_time, end_date=end_time)
#
# # 财务数据
# apis["balancesheet"] = partial(
#     pro.balancesheet, start_date=start_time, end_date=end_time
# )
# apis["income"] = partial(pro.income, start_date=start_time, end_date=end_time)
# apis["cashflow"] = partial(pro.cashflow, start_date=start_time, end_date=end_time)
# apis["fina_indicator"] = partial(
#     pro.fina_indicator, start_date=start_time, end_date=end_time
# )
#
# # 股东人数
# apis["stk_holdernumber"] = partial(
#     pro.stk_holdernumber, start_date=start_time, end_date=end_time
# )
# # 股东增减持
# apis["stk_holdertrade"] = partial(pro.stk_holdertrade)
#
#
# # 个股资金流向
# apis["moneyflow"] = partial(pro.moneyflow, start_date=start_time, end_date=end_time)
# pro_bar_qfq = partial(ts.pro_bar, start_date=start_time, adj="qfq", end_date=end_time)
#
#
# # api_name = list(apis.keys())[-1]
