import os
from typing import Dict

from loguru import logger
from pandas import DataFrame

from ..server import Worker
from .utils import mainCallback


class 东财api登录失败(Exception):
    pass


class EMWorker(Worker):
    def __init__(self, username: str, password: str):
        super().__init__("em")
        self._client = None
        self._login = False
        self.username = username
        self.password = password

    @classmethod
    def __log_info(cls, logMessage):
        logger.info(logMessage)
        return 1

    def start(self):
        if self._login:
            return
        try:
            from EmQuantAPI import c

            start_options = f"ForceLogin=1,UserName={self.username},PassWord={self.password},TestLatency=1"
            login_result = c.start(start_options, EMWorker.__log_info, mainCallback)
            if login_result.ErrorCode != 0:
                logger.error("东财api登录失败！")
                raise 东财api登录失败("东财api登录失败！")
        except ImportError:
            logger.warning("请先安装东财接口安装包再使用！")
        except InterruptedError as e:
            logger.error(f"东财登录失败! {e}")
        else:
            self._client = c
            self._login = True

    def stop(self):
        # 退出
        if self._login:
            login_result = self._client.stop()
            if login_result.ErrorCode != 0:
                logger.error("东财api退出失败！")
            else:
                self._login = False

    def raw_api(self, func_name, *args):
        """东财原始接口, 请参考东财接口文档。

        Parameters
        ----------
        func_name: 东财的函数名称，包括ctr，css,csd, sector等等
        args: 东财接口的其他参数


        Returns
        -------
        Dict
        注意：由于序列化的原因，EmQuantData和pandas都会转换成dict返回。所以，不建议将isPandas设置成1.

        Notes
        _____
        如调用订阅接口需要送回调函数，回调函数样例在utils.py中。订阅接口还需要记录serialid，取消订阅时需要用。
        """
        args_str = "', '".join(args)
        try:
            func = getattr(self._client, func_name)
            logger.debug(f"调用东财接口{func_name}({args_str})")
            data = func(*args)
            if not isinstance(data, self._client.EmQuantData) and not isinstance(
                data, DataFrame
            ):
                error_msg = f"调用{func_name}({args_str})时返回数据格式不规范，返回数据为：{args_str}"
                logger.error(error_msg)
                return error_msg
            elif isinstance(data, self._client.EmQuantData):
                if data.ErrorCode != 0:
                    error_msg = f"东财接口{func}返回错误： {data.ErrorMsg}"
                    logger.error(error_msg)
                    return error_msg
                else:
                    logger.trace(f"{func_name}({args_str})调用成功，返回数据如下：{data}")
                    return data
            else:
                logger.trace(f"{func_name}({args_str})调用成功，返回数据如下：{data}")
                return data

        except AttributeError:
            return f"东财接口没有此函数{func_name}！"
        except Exception:
            error_msg = f"东财接口没有此函数{func_name}！"
            logger.error(error_msg)
            return error_msg


def em_client():
    if not hasattr(em_client, "client"):
        if "EM_USER" not in os.environ or "EM_PASSWORD" not in os.environ:
            logger.warning("请在环境变量中设置EM_USER和EM_PASSWORD，对应东财api的用户名和密码")
            return
        else:
            em_client.user = os.environ["EM_USER"]
            em_client.password = os.environ["EM_PASSWORD"]
            em_client.client = EMWorker(em_client.user, em_client.password)
            em_client.client.start()
    return em_client.client


def run_em_api(*args) -> Dict:
    return em_client().raw_api(*args[0])
