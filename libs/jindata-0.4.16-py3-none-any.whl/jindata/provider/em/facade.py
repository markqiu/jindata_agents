# def get_all_securities(types=["stock"], dates=None):
#     cn_stock_market = c.sector("001004", to_time_str(now_pd_timestamp()))
#     cn_stock_market_df = pd.DataFrame(cn_stock_market.Data, columns=["code"])
#     cn_stock_market = [i for i in cn_stock_market_df.code if "." in i]
#     cn_stock = split_list_average_n(cn_stock_market, 100)
#     for code_list in cn_stock:
#         data_css = c.css(
#             code_list, "NAME,CODE,LISTDATE,LISTMKT,DELISTDATE", "ispandas=1"
#         )
#         self.logger.debug(f"{code_list[0]}-{code_list[-1]}的数据获取成功!")
#         if data_css.empty:
#             self.logger.debug(f"{code_list[0]}-{code_list[-1]}的数据获取失败，请检查!")
#             return
#         data_css.rename(
#             columns={
#                 "NAME": "name",
#                 "LISTDATE": "start_date",
#                 "IPOLISTDATE": "start_date",
#                 "DELISTDATE": "end_date",
#             },
#             inplace=True,
#         )
#         df_stock = self.to_zvt_entity(data_css, entity_type="stock")
#         df_to_db(
#             df_stock,
#             data_schema=Stock,
#             provider=self.provider,
#             force_update=self.force_update,
#         )
#     self.logger.debug("persist stock list success")
#     c.stop()
