# map1 = {
#     # table: dividend_detail
#     "pub_date": "announce_date",  # 除权除息日
#     "ex_date": "dividend_date",  # 除权除息日
#     "record_date": "record_date",  # 股权登记日
#     "pay_date": "dividend_pay_date",  # 派息日
#     "dividend_implement_date": "announce_date_dividend_implementation",  # 分红实施公告日
#     "proportion": "dividend_per_share_after_tax",  # 每股股利(税后)
#     "split_ratio": "split_ratio",  # 分拆（合并、赠送）比例
#     "process": "dividend_plan_progress",  # 分红方案进度
#
#     # table: fund_dividend_detail
#     "DIVPLANANNCDATE": "announce_date",  # 预案公告日
#     "DIVAGMANNCDATE": "announcement_date_general_meeting",  # 股东大会公告日
#     "DIVEXDATE": "dividend_date",  # 除权除息日
#     "DIVRECORDDATE": "record_date",  # 股权登记日
#     "DIVIMPLANNCDATE": "announce_date_dividend_implementation",  # 分红实施公告日
#     "DIVLASTTRDDATESHAREB": "last_trading_day_b_shares",  # B股最后交易日
#     "DIVCASHPSAFTAX": "dividend_per_share_after_tax",  # 每股股利(税后)
#     "DIVCASHPSBFTAX": "dividend_per_share_before_tax",  # 每股股利(税前)
#     "DIVPROGRESS": "dividend_plan_progress",  # 分红方案进度
#     "DIVPAYDATE": "dividend_pay_date",  # 派息日
#     "DIVSTOCKPS": "share_bonus_per_share",  # 每股送股比例
#     "DIVCAPITALIZATIONPS": "per_share_conversion_ratio",  # 每股转增比例
#     "DIVCASHANDSTOCKPS": "dividend",  # 分红送转方案
#
#     # table: rights_issue_detail
#     "RTISSANNCDATE": "rtiss_announcement_date",  # 配股公告日
#     "RTISSREGISTDATE": "record_date",  # 股权登记日
#     "RTISSEXDIVDATE": "rtiss_date",  # 配股除权日
#     "RTISSLISTDATE": "rtiss_listing_date",  # 配股上市日
#     "RTISSPAYSDATE": "rtiss_pays_date",  # 缴款起始日
#     "RTISSPAYEDATE": "rtiss_paye_date",  # 缴款终止日
#     "RTISSPERTISSHARE": "rtiss_per_share",  # 每股配股数
#     "RTISSBASESHARES": "rtiss_base_shares",  # 基准股本
#     "RTISSPLANNEDVOL": "rtiss_plan_number",  # 计划配股数
#     "RTISSACTVOL": "rights_issues",  # 实际配股
#     "RTISSPRICE": "rights_issue_price",  # 配股价格
#     "RTISSCOLLECTION": "rights_raising_fund",  # 实际募集资金
#     "RTISSNETCOLLECTION": "rtiss_net_proceeds",  # 配股募集资金净额
#     "RTISSEXPENSE": "rtiss_tax",  # 配股费用
#
#     #table: holder_trading
#     "NOTICEDATE": "report_date",  # 公告日期
#     "SHAREHDNAME": "holder_name",  # 股东名称
#     "SHAREHDTYPE": "holder_share_type",  # 股东类型
#     "IS_controller": "holder_controller",  # 是否实际控制人
#     "POSITION1": "holder_positions",  # 高管职务
#     "FX": "holder_direction",  # 方向
#     "BDHCGZS": "holder_share_af",  # 变动后_持股总数(万股)
#     "CHANGENUM": "volume",  # 变动_流通股数量(万股) 变动股份数量
#     "BDHCGBL": "holding_pct",  # 变动后_占总股本比例(%)
#     "JYPJJ": "price",  # 交易均价(元)
#     "BDQSRQ": "holder_start_date",  # 变动起始日期
#     "BDJZRQ": "holder_end_date",  # 变动截止日期
#     "CLB_REMARK": "holder_remark",  # 说明
#
#     # table: holder_trade_plan
#     "HOLDDECREASEANNCDATENEWPLAN": "report_date",  # 公告日期
#     "HOLDDECREASENAMENEWPLAN": "holder_name",  # 股东名称
#     # 'FX': 'holder_direction',  # 方向
#     "DECRENEWMAXSHANUM": "volume_plan_max",  # 最新计划减持股份数量上限(股)
#     "DECRENEWMINSHANUM": "volume_plan_min",  # 最新计划减持股份数量下限(股)
#     "HOLDMAXSHARENEWPLAN": "volume_plan_max",  # 最新计划增持股份数量上限(股)
#     "HOLDMINSHARENEWPLAN": "volume_plan_min",  # 最新计划增持股份数量下限(股)
#     "DECRENEWPROGRESS": "plan_progress ",  # 减持计划进度
#     "HOLDPLANSCHEDULE": "plan_progress ",  # 增持计划进度
# }
#
# map2 = {
#     #table audit_opinions
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 审计单位
#     "audit_unit": "AGENCY",
#     # 审计单位薪酬
#     "audit_unit_pay": "AUDITPAY",
#     # 审计年限(境内）
#     "audit_year": "AUDITYEAR",
#     # 非标意见说明
#     # "non_standard_opinion_description": "INTERPRETATION",
#     # 审计意见类别
#     "audit_opinion_category": "CATEGORY",
#     # 签字注册会计师
#     "CPA": "CPA",
#
#     #table balance_sheet
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 流动资产
#     # CASHTOCL
#     # 货币资金
#     "cash_and_cash_equivalents": "BALANCESTATEMENT_9",
#     # 应收票据
#     "note_receivable": "BALANCESTATEMENT_11",
#     # 应收账款
#     "accounts_receivable": "BALANCESTATEMENT_12",
#     # 预付款项
#     "advances_to_suppliers": "BALANCESTATEMENT_14",
#     # 其他应收款
#     "other_receivables": "BALANCESTATEMENT_222",
#
#     # 租赁负债
#     "lease_liabilities": "BALANCESTATEMENT_228",
#     # 应付短期债券
#     "payable_short_term_bonds": "BALANCESTATEMENT_147",
#     # 应收账款融资项
#     "accounts_receivable_financing_items": "BALANCESTATEMENT_223",
#
#     # 存货
#     "inventories": "BALANCESTATEMENT_17",
#     # 一年内到期的非流动资产
#     "current_portion_of_non_current_assets": "BALANCESTATEMENT_20",
#     # 其他流动资产
#     "other_current_assets": "BALANCESTATEMENT_21",
#     # 流动资产合计
#     "total_current_assets": "BALANCESTATEMENT_25",
#     # 非流动资产
#     #
#     # 可供出售金融资产
#     "fi_assets_saleable": "BALANCESTATEMENT_26",
#     # 长期应收款
#     "long_term_receivables": "BALANCESTATEMENT_30",
#     # 长期股权投资
#     "long_term_equity_investment": "BALANCESTATEMENT_29",
#     # 投资性房地产
#     "real_estate_investment": "BALANCESTATEMENT_28",
#     # 固定资产
#     "fixed_assets": "BALANCESTATEMENT_31",
#     # 在建工程
#     "construction_in_process": "BALANCESTATEMENT_33",
#     # 无形资产
#     "intangible_assets": "BALANCESTATEMENT_37",
#     # 商誉
#     "goodwill": "BALANCESTATEMENT_39",
#     # 长期待摊费用
#     "long_term_prepaid_expenses": "BALANCESTATEMENT_40",
#     # 递延所得税资产
#     "deferred_tax_assets": "BALANCESTATEMENT_41",
#     # 其他非流动资产
#     "other_non_current_assets": "BALANCESTATEMENT_42",
#     # 非流动资产合计
#     "total_non_current_assets": "BALANCESTATEMENT_46",
#     # 资产总计
#     "total_assets": "BALANCESTATEMENT_74",
#     # 流动负债
#     #
#     # 短期借款
#     "short_term_borrowing": "BALANCESTATEMENT_75",
#     # 吸收存款及同业存放
#     "accept_money_deposits": "BALANCESTATEMENT_153",
#     # 应付账款
#     "accounts_payable": "BALANCESTATEMENT_78",
#     # 预收款项
#     "advances_from_customers": "BALANCESTATEMENT_79",
#     # 应付职工薪酬
#     "employee_benefits_payable": "BALANCESTATEMENT_80",
#     # 应交税费
#     "taxes_payable": "BALANCESTATEMENT_81",
#     # 应付利息
#     "interest_payable": "BALANCESTATEMENT_82",
#     # 其他应付款
#     "other_payable": "BALANCESTATEMENT_84",
#     # 一年内到期的非流动负债
#     "current_portion_of_non_current_liabilities": "BALANCESTATEMENT_88",
#     # 其他流动负债
#     "other_current_liabilities": "BALANCESTATEMENT_89",
#     # 流动负债合计
#     "total_current_liabilities": "BALANCESTATEMENT_93",
#     # 一般风险准备
#     "fi_generic_risk_reserve": "BALANCESTATEMENT_134",
#     # 非流动负债
#     #
#     # 长期借款
#     "long_term_borrowing": "BALANCESTATEMENT_94",
#     # 长期应付款
#     "long_term_payable": "BALANCESTATEMENT_96",
#     # 递延收益
#     "deferred_revenue": "BALANCESTATEMENT_148",
#     # 递延所得税负债
#     "deferred_tax_liabilities": "BALANCESTATEMENT_98",
#     # 其他非流动负债
#     "other_non_current_liabilities": "BALANCESTATEMENT_99",
#     # 非流动负债合计
#     "total_non_current_liabilities": "BALANCESTATEMENT_103",
#     # 负债合计
#     "total_liabilities": "BALANCESTATEMENT_128",
#     # 所有者权益(或股东权益)
#     #
#     # 实收资本（或股本）
#     "capital": "BALANCESTATEMENT_129",
#     # 资本公积
#     "capital_reserve": "BALANCESTATEMENT_130",
#     # 专项储备
#     "special_reserve": "BALANCESTATEMENT_159",
#     # 盈余公积
#     "surplus_reserve": "BALANCESTATEMENT_131",
#     # 未分配利润
#     "undistributed_profits": "BALANCESTATEMENT_132",
#     # 归属于母公司股东权益合计
#     "equity": "BALANCESTATEMENT_140",
#     # 少数股东权益
#     "equity_as_minority_interest": "BALANCESTATEMENT_136",
#     # 应收利息
#     "fi_interest_receivable": "BALANCESTATEMENT_16",
#     # 应收股利	其中:应收股利(元)
#     "fi_dividend_rec": "BALANCESTATEMENT_15",
#     # 股东权益合计 所有者权益(或股东权益)合计
#     "total_equity": "BALANCESTATEMENT_141",
#     # 负债和股东权益合计
#     "total_liabilities_and_equity": "BALANCESTATEMENT_145",
#     # 其中:优先股（其他权益工具）
#     "fi_preferred_stock": "BALANCESTATEMENT_196",
#     # 拆出资金
#     "fi_lending_to_other_fi": "BALANCESTATEMENT_50",
#     # 其他权益工具
#     "fi_other_equity_instruments": "BALANCESTATEMENT_195",
#     # 永续债
#     "fi_perpetual_bond": "BALANCESTATEMENT_197",
#     # 减:库存股
#     "fi_inventory_share": "BALANCESTATEMENT_133",
#     # 其他综合收益
#     "other_comprehensive_income": "BALANCESTATEMENT_199",
#     # 外币报表折算差额		外币报表折算差额(元)
#     "fi_diffconversionfc": "BALANCESTATEMENT_135",
#     # 归属于母公司所有者权益的调整项目	 归属于母公司股东权益其他项目(元)
#     "fi_parent_equity_other": "BALANCESTATEMENT_161",
#     # 归属于母公司所有者权益的差错金额	 归属于母公司股东权益平衡项目(元)
#     "fi_parent_equity_balance": "BALANCESTATEMENT_162",
#     # 所有者权益的调整项目  股东权益其他项目(元)
#     "fi_sh_equity_other": "BALANCESTATEMENT_137",
#     # 所有者权益的差错金额	股东权益平衡项目(元)
#     "fi_sh_equity_balance": "BALANCESTATEMENT_138",
#     # 应付债券
#     "fi_bond_payable": "BALANCESTATEMENT_95",
#     # 负债和权益的调整项目	负债和股东权益其他项目(元)
#     "fi_liab_sh_equity_other": "BALANCESTATEMENT_142",
#     # 负债和权益的差错金额	负债和股东权益平衡项目(元)
#     "fi_liab_sh_equity_balance": "BALANCESTATEMENT_143",
#     # 结算备付金
#     "fi_deposit_reservation_for_balance": "BALANCESTATEMENT_67",
#     # 交易性金融资产		交易性金融资产
#     "fi_trade_finasset_notfvtpl": "BALANCESTATEMENT_224",
#     # 衍生金融资产
#     "fi_financial_derivative_asset": "BALANCESTATEMENT_51",
#     # 应收保费
#     "fi_premiums_receivable": "BALANCESTATEMENT_55",
#     # 应收分保账款
#     "fi_reinsurance_premium_receivable": "BALANCESTATEMENT_57",
#     # 应收分保合同准备金
#     "fi_reinsurance_contract_reserve": "BALANCESTATEMENT_152",
#     # 买入返售金融资产
#     "fi_buying_sell_back_fi__asset": "BALANCESTATEMENT_52",
#     # 流动资产的调整项目		流动资产其他项目(元)
#     "fi_lasset_other": "BALANCESTATEMENT_22",
#     # 流动资产的差错金额		流动资产平衡项目(元)
#     "fi_lasset_balance": "BALANCESTATEMENT_23",
#     # 发放委托贷款及垫款		发放贷款及垫款(元)
#     "fi_loan_advances": "BALANCESTATEMENT_53",
#     # 保险合同准备金
#     "fi_contract_reserve": "BALANCESTATEMENT_154",
#     # 持有至到期投资
#     "fi_held_to_maturity_investment": "BALANCESTATEMENT_27",
#     # 工程物资	工程物资(元)
#     "fi_construction_material": "BALANCESTATEMENT_32",
#     # 固定资产清理	固定资产清理(元)
#     "fi_liquidate_fixed_asset": "BALANCESTATEMENT_34",
#     # 生产性生物资产		生产性生物资产(元)
#     "fi_product_biology_asset": "BALANCESTATEMENT_35",
#     # 油气资产	油气资产(元)
#     "fi_oil_gas_asset": "BALANCESTATEMENT_36",
#     # 研发支出		开发支出(元)	DEVELOPEXP
#     "fi_develop_exp": "BALANCESTATEMENT_38",
#     # 非流动资产的调整项目		非流动资产其他项目(元)
#     "fi_nonl_asset_other": "BALANCESTATEMENT_43",
#     # 非流动资产的差错金额		非流动资产平衡项目(元)
#     "fi_nonl_asset_balance": "BALANCESTATEMENT_44",
#     # 资产的调整项目		资产其他项目(元)
#     "fi_asset_other": "BALANCESTATEMENT_71",
#     # 资产的差错金额		资产平衡项目(元)
#     "fi_asset_balance": "BALANCESTATEMENT_72",
#     # 向中央银行借款
#     "fi_borrowings_from_central_bank": "BALANCESTATEMENT_105",
#     # 拆入资金
#     "fi_borrowings_from_fi": "BALANCESTATEMENT_106",
#     # 交易性金融负债		交易性金融负债
#     "fi_trade_finliab_notfvtpl": "BALANCESTATEMENT_226",
#     # 衍生金融负债
#     "fi_financial_derivative_liability": "BALANCESTATEMENT_107",
#     # 存款证及应付票据  应付票据
#     "fi_notes_payable": "BALANCESTATEMENT_77",
#     # 卖出回购金融资产款
#     "fi_sell_buy_back_fi_asset": "BALANCESTATEMENT_108",
#     # 应付手续费及佣金
#     "fi_fees_and_commissions_payable": "BALANCESTATEMENT_113",
#     # 应付股利		其中:应付股利(元)
#     "fi_dividend_payable": "BALANCESTATEMENT_83",
#     # 代理买卖证券款
#     "fi_receiving_as_agent": "BALANCESTATEMENT_123",
#     # 代理承销证券款		代理承销证券款(元)
#     "fi_agentuw_security": "BALANCESTATEMENT_124",
#     # 流动负债的调整项目		流动负债其他项目(元)
#     "fi_lliab_other": "BALANCESTATEMENT_90",
#     # 流动负债的差错金额		流动负债平衡项目(元)
#     "fi_lliab_balance": "BALANCESTATEMENT_91",
#     # 专项应付款		专项应付款(元)
#     "fi_special_pay": "BALANCESTATEMENT_97",
#     # 预计负债
#     "fi_estimated_liabilities": "BALANCESTATEMENT_86",
#     # 非流动负债的调整项目		非流动负债其他项目(元)
#     "fi_non_liab_other": "BALANCESTATEMENT_100",
#     # 非流动负债的差错金额		非流动负债平衡项目(元)
#     "fi_non_liab_balance": "BALANCESTATEMENT_101",
#     # 负债的调整项目		负债其他项目(元)
#     "fi_liab_other": "BALANCESTATEMENT_125",
#     # 负债的差错金额		负债平衡项目(元)
#     "fi_liab_balance": "BALANCESTATEMENT_126",
#     # 应付分保账款
#     "fi_dividend_payable_for_reinsurance": "BALANCESTATEMENT_114",
#
#     # table: cash_flow_statement
#         # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 经营活动产生的现金流量
#     #
#     # 销售商品、提供劳务收到的现金
#     "cash_from_selling": "CASHFLOWSTATEMENT_9",
#     # 收到的税费返还
#     "tax_refund": "CASHFLOWSTATEMENT_10",
#     # 收到其他与经营活动有关的现金
#     "cash_from_other_op": "CASHFLOWSTATEMENT_11",
#     # 质押贷款净增加额
#     "fi_insured_pledge_loans_increase": "CASHFLOWSTATEMENT_53",
#     # 经营活动现金流入小计
#     "total_op_cash_inflows": "CASHFLOWSTATEMENT_25",
#     # 购买商品、接受劳务支付的现金
#     "cash_to_goods_services": "CASHFLOWSTATEMENT_26",
#     # 支付给职工以及为职工支付的现金
#     "cash_to_employees": "CASHFLOWSTATEMENT_27",
#     # 支付的各项税费
#     "taxes_and_surcharges": "CASHFLOWSTATEMENT_28",
#     # 支付其他与经营活动有关的现金
#     "cash_to_other_related_op": "CASHFLOWSTATEMENT_29",
#     # 经营活动现金流出小计
#     "total_op_cash_outflows": "CASHFLOWSTATEMENT_37",
#     # 经营活动产生的现金流量净额
#     "net_op_cash_flows": "CASHFLOWSTATEMENT_39",
#     # 处置固定资产、无形资产和其他长期资产收回的现金净额
#     "cash_from_disposal_fixed_intangible_assets": "CASHFLOWSTATEMENT_42",
#     # 投资活动产生的现金流量
#     # 收回投资收到的现金
#     "cash_from_disposal_of_investments": "CASHFLOWSTATEMENT_40",
#     # 取得投资收益收到的现金
#     "cash_from_returns_on_investments": "CASHFLOWSTATEMENT_41",
#     # 处置子公司及其他营业单位收到的现金净额
#     "cash_from_disposal_subsidiaries": "CASHFLOWSTATEMENT_43",
#     # 收到其他与投资活动有关的现金
#     "cash_from_other_investing": "CASHFLOWSTATEMENT_44",
#     # 投资活动现金流入小计
#     "total_investing_cash_inflows": "CASHFLOWSTATEMENT_48",
#     # 购建固定资产、无形资产和其他长期资产支付的现金
#     "cash_to_acquire_fixed_intangible_assets": "CASHFLOWSTATEMENT_49",
#     # 投资支付的现金
#     "cash_to_investments": "CASHFLOWSTATEMENT_50",
#     # 取得子公司及其他营业单位支付的现金净额
#     "cash_to_acquire_subsidiaries": "CASHFLOWSTATEMENT_51",
#     # 支付其他与投资活动有关的现金
#     "cash_to_other_investing": "CASHFLOWSTATEMENT_52",
#     # 投资活动现金流出小计
#     "total_investing_cash_outflows": "CASHFLOWSTATEMENT_57",
#     # 投资活动产生的现金流量净额
#     "net_investing_cash_flows": "CASHFLOWSTATEMENT_59",
#     # 筹资活动产生的现金流量
#     #
#     # 吸收投资收到的现金
#     "cash_from_accepting_investment": "CASHFLOWSTATEMENT_60",
#     # 子公司吸收少数股东投资收到的现金
#     "cash_from_subsidiaries_accepting_minority_interest": "CASHFLOWSTATEMENT_118",
#     # 取得借款收到的现金
#     "cash_from_borrowings": "CASHFLOWSTATEMENT_61",
#     # 发行债券收到的现金
#     "cash_from_issuing_bonds": "CASHFLOWSTATEMENT_63",
#     # 收到其他与筹资活动有关的现金
#     "cash_from_other_financing": "CASHFLOWSTATEMENT_62",
#     # 筹资活动现金流入小计
#     "total_financing_cash_inflows": "CASHFLOWSTATEMENT_68",
#     # 偿还债务支付的现金
#     "cash_to_repay_borrowings": "CASHFLOWSTATEMENT_69",
#     # 分配股利、利润或偿付利息支付的现金
#     "cash_to_pay_interest_dividend": "CASHFLOWSTATEMENT_70",
#     # 子公司支付给少数股东的股利、利润
#     "cash_to_pay_subsidiaries_minority_interest": "CASHFLOWSTATEMENT_119",
#     # 支付其他与筹资活动有关的现金
#     "cash_to_other_financing": "CASHFLOWSTATEMENT_71",
#     # 筹资活动现金流出小计
#     "total_financing_cash_outflows": "CASHFLOWSTATEMENT_75",
#     # 筹资活动产生的现金流量净额
#     "net_financing_cash_flows": "CASHFLOWSTATEMENT_77",
#     # 汇率变动对现金及现金等价物的影响
#     "foreign_exchange_rate_effect": "CASHFLOWSTATEMENT_78",
#     # 现金及现金等价物净增加额
#     "net_cash_increase": "CASHFLOWSTATEMENT_82",
#     # 加: 期初现金及现金等价物余额
#     "cash_at_beginning": "CASHFLOWSTATEMENT_83",
#     # 期末现金及现金等价物余额
#     "cash": "CASHFLOWSTATEMENT_84",
#     # 客户存款和同业及其他金融机构存放款项净增加额
#     # 客户存款和同业存放款项净增加额
#     "fi_deposit_increase": "CASHFLOWSTATEMENT_12",
#     # 支付保单红利的现金
#     "fi_cash_to_dividends": "CASHFLOWSTATEMENT_195",
#     # 向中央银行借款净增加额
#     "fi_borrow_from_central_bank_increase": "CASHFLOWSTATEMENT_13",
#     # 向其他金融机构拆入资金净增加额
#     "fi_lending_from_increase": "CASHFLOWSTATEMENT_14",
#     # 收到原保险合同保费取得的现金
#     "fi_cash_from_premium_of_original": "CASHFLOWSTATEMENT_16",
#     # 收到再保险业务现金净额
#     "fi_cash_from_reinsurance": "CASHFLOWSTATEMENT_17",
#     # 保户储金及投资款净增加额
#     "fi_insured_deposit_increase": "CASHFLOWSTATEMENT_64",
#     # 处置交易性金融资产净增加额
#     "fi_disposal_trade_asset_add": "CASHFLOWSTATEMENT_18",
#     # 客户贷款及垫款净增加额
#     "fi_loan_advance_increase": "CASHFLOWSTATEMENT_30",
#     # 存放中央银行和同业款项净增加额
#     "fi_deposit_in_others_add": "CASHFLOWSTATEMENT_31",
#     # 支付原保险合同赔付款项的现金
#     "fi_cash_to_insurance_claim": "CASHFLOWSTATEMENT_32",
#     # 支付利息、手续费及佣金的现金
#     "fi_cash_to_interest_commission": "CASHFLOWSTATEMENT_33",
#     # 收取的利息、手续费及佣金的现金 收取利息、手续费及佣金的现金
#     "fi_cash_from_interest_commission": "CASHFLOWSTATEMENT_186",
#     # 拆入资金净增加额
#     "fi_borrowing_increase": "CASHFLOWSTATEMENT_20",
#     # 回购业务资金净增加额
#     "fi_cash_from_repurchase_increase": "CASHFLOWSTATEMENT_21",
#     # 经营活动现金流入的调整项目
#     # 经营活动现金流入的其他项目
#     "fi_operate_flow_inother": "CASHFLOWSTATEMENT_22",
#     # 经营活动现金流入的差错金额
#     # 经营活动现金流入的平衡项目(元)
#     "fi_operate_flow_in_balance": "CASHFLOWSTATEMENT_23",
#     # 经营活动现金流量净额的差错金额
#     # 经营活动产生的现金流量净额其他项目(元)
#     "fi_operate_flow_other": "CASHFLOWSTATEMENT_121",
#     # 投资活动现金流入的调整项目
#     # 投资活动现金流入的其他项目(元)
#     "fi_inv_flow_in_other": "CASHFLOWSTATEMENT_45",
#     # 投资活动现金流入的差错金额
#     # 投资活动现金流入的平衡项目(元)
#     "fi_inv_flow_in_balance": "CASHFLOWSTATEMENT_46",
#     # 投资活动现金流出的调整项目
#     # 投资活动现金流出的其他项目(元)
#     "fi_inv_flow_out_other": "CASHFLOWSTATEMENT_54",
#     # 投资活动现金流出的差错金额
#     # 投资活动现金流出的平衡项目(元)
#     "fi_inv_flow_out_balance": "CASHFLOWSTATEMENT_55",
#     # 投资活动现金流量净额的差错金额
#     # 投资活动产生的现金流量净额其他项目(元)
#     "fi_inv_flow_other": "CASHFLOWSTATEMENT_122",
#     # 筹资活动现金流入的调整项目
#     # 筹资活动现金流入的其他项目(元)
#     "fi_fina_flow_in_other": "CASHFLOWSTATEMENT_65",
#     # 筹资活动现金流入的差错金额
#     # 筹资活动现金流入的平衡项目(元)
#     "fi_fina_flow_in_balance": "CASHFLOWSTATEMENT_66",
#     # 筹资活动现金流出的调整项目
#     # 其中:子公司减资支付给少数股东的现金(元)
#     "fi_subsidiary_reduct_capital": "CASHFLOWSTATEMENT_124",
#     # 筹资活动现金流出的差错金额
#     # 筹资活动现金流出的其他项目(元)
#     "fi_fina_flow_out_other": "CASHFLOWSTATEMENT_72",
#     # 筹资活动现金流量净额的差错金额
#     # 筹资活动产生的现金流量净额其他项目(元)
#     "fi_fina_flow_other": "CASHFLOWSTATEMENT_125",
#     # 影响现金及现金等价物的调整项目		现金及现金等价物净增加额其他项目(元)
#     "fi_ni_cash_equi_other": "CASHFLOWSTATEMENT_79",
#     # 影响现金及现金等价物的差错金额		现金及现金等价物净增加额平衡项目(元)
#     "fi_ni_cash_equi_balance": "CASHFLOWSTATEMENT_80",
#     # 影响期末现金及现金等价物余额的调整项目		期末现金及现金等价物余额其他项目(元)
#     "fi_cash_equi_ending_other": "CASHFLOWSTATEMENT_126",
#     # 影响期末现金及现金等价物余额的差错金额		期末现金及现金等价物余额平衡项目(元)
#     "fi_cash_equi_ending_balance": "CASHFLOWSTATEMENT_127",
#     # 经营活动现金流出的调整项目		经营活动现金流出的其他项目(元)
#     "fi_operate_flow_out_other": "CASHFLOWSTATEMENT_34",
#     # 经营活动现金流出的差错金额		经营活动现金流出的平衡项目(元)
#     "fi_operate_flow_out_balance": "CASHFLOWSTATEMENT_35",
#     # 固定资产折旧、油气资产折耗、生产性生物资产折旧
#     "fixed_assets_depreciation": "CASHFLOWSTATEMENT_87",
#     # 资产减值准备
#     "assets_depreciation_reserves": "CASHFLOWSTATEMENT_86",
#     # 无形资产摊销
#     "intangible_assets_amortization": "CASHFLOWSTATEMENT_88",
#     # 长期待摊费用摊销
#     "defferred_expense_amortization": "CASHFLOWSTATEMENT_89",
#     # 处置固定资产、无形资产和其他长期资产的损失
#     "fix_intan_other_asset_dispo_loss": "CASHFLOWSTATEMENT_92",
#     # 固定资产报废损失
#     "fixed_asset_scrap_loss": "CASHFLOWSTATEMENT_93",
#
#     # table: finance_capital_structure
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     "debt_asset_ratio": "LIBILITYTOASSET",  # 资产负债率
#     "em": "ASSETSTOEQUITY",  # 权益乘数
#     "ca_to_asset": "CATOASSET",  # 流动资产/总资产
#     "nc_to_asset": "NCATOASSET",  # 非流动资产/总资产
#     "tangible_assets_to_asset": "TANGIBLEASSETSTOASSET",  # 有形资产/总资产
#     "equity_to_total_capital": "EQUITYTOTOTALCAPITAL",  # 归属母公司股东的权益/全部投入资本
#     "interest_liblity_to_total_capital": "INTERESTLIBILITYTOTOTALCAPITAL",  # 带息负债/全部投入资本
#     "cl_to_libility": "CLTOLIBILITY",  # 流动负债/负债合计
#     "cnl_to_libility": "NCLTOLIBILITY",  # 非流动负债/负债合计
#     "interest_liblity_to_libility": "INTERESLIBILITYTOLIBILITY",  # 有息负债率
#
#     # table: finance_balance_sheet_structure_analysis
#         # 更新时间
#     "pub_date": "STMTACTDATE",
#     "cfo_to_gr": "CFOTOGR",  # 经营活动产生的现金流量净额/营业总收入
#     "sales_cash_intoor": "SALESCASHINTOOR",  # 销售商品提供劳务收到的现金/营业收入
#     "qcfi_to_cf": "QCFITOCF",  # 投资活动产生的现金流量净额占比
#     "qcfo_to_cfo": "QCFOTCFO",  # 经营活动产生的现金流量净额占比
#     "qcfo_to_or": "QCFOTOOR",  # 经营活动产生的现金流量净额/营业收入
#     "qcfo_to_operate_income": "QCFOTOOPERATEINCOME",  # 经营活动产生的现金流量净额/经营活动净收益
#     "qcff_to_cf": "QCFFTOCF",  # 筹资活动产生的现金流量净额占比
#     # 'ADV_R_R': '',  # 预收款项/营业收入
#     # 'AR_R': '',  # 应收账款/营业收入
#     # 'P_FIXA_O_DA': '',  # 投资支出/折旧和摊销
#     # 'C_RCVRY_A': '',  # 全部资产现金回收率
#     # 'N_CF_OPA_OP': '',  # 经营活动产生的现金流量净额/营业利润
#
#     # table: finance_cash_position
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 销售商品提供劳务收到的现金/营业收入
#     "sales_cash_in_to_or": "SALESCASHINTOOR",
#     # 经营活动产生的现金流量净额/营业收入
#     "cfo_to_or": "CFOTOOR",
#     # 经营活动产生的现金流量净额/经营活动净收益
#     "cfo_to_op_in": "CFOTOOPERATEINCOME",
#     # 资本支出/折旧摊销
#     "capital_expenditure": "CAPITALEXPENDITURE",
#     # 销售商品提供劳务收到的现金/营业收入 ttm
#     "sales_cash_in_to_or_ttm": "SALESCASHINTOORTTM",
#     # 经营活动产生的现金流量净额/营业收入 ttm
#     "cfo_to_or_ttm": "CFOTOORTTM",
#     # 经营活动产生的现金流量净额/经营活动净收益
#     "cfo_to_op_in_ttm": "CFOTOOPERATEINCOMETTM",
#     # 经营活动产生的现金流量净额/营业总收入
#     "cfo_to_gr": "CFOTOGR",
#     # 经营活动产生的现金流量净额/净利润
#     "cfo_to_np": "CFOTONP",
#
#     # table: finance_debtpaying_ability
#     "debt_asset_ratio": "LIBILITYTOASSET",  # 资产负债率
#     "conservative_quick_ratio": "CONSERVQUICKRATIO",  # 保守速动比率
#     "equity_ratio": "LIBILITYTOEQUITY",  # 产权比率
#     "equity_to_interest_libility": "EQUITYTOINTERESTLIBILITY",  # 归属母公司股东的权益与带息债务之比
#     "equity_to_libility": "EQUITYTOLIBILITY",  # 归属母公司股东的权益与负债合计之比
#     # 'cash_to_current_libility': 'CASHTOCL',  # 货币资金与流动负债之比
#     "cfo_to_interest_libility": "CFOTOINTERESTLIBILITY",  # 经营活动产生的现金流量净额与带息债务之比
#     "cfo_to_libility": "CFOTOLIBILITY",  # 经营活动产生的现金流量净额与负债合计之比
#     "cfo_to_net_libility": "CFOTONETLIBILITY",  # 经营活动产生的现金流量净额与净债务之比
#     "cfo_to_cl": "CFOTOSHORTLIBILITY",  # 经营活动产生的现金流量净额与流动负债之比
#     "current_ratio": "CURRENTTATIO",  # 流动比率
#     "quick_ratio": "QUICKTATIO",  # 速动比率
#     # 'ebitda_to_int_libility': 'EBITDATOINTLIBILITY',  # 息税折旧摊销前利润与带息债务之比
#     "ebitda_to_libility": "EBITDATOLIBILITY",  # 息税折旧摊销前利润与负债合计之比
#     # 'op_to_libility': 'OPTOLIBILITY',  # 营业利润与负债合计之比
#     # 'op_to_cl': 'OPTOCL',  # 营业利润与流动负债之比
#     "tangible_asset_to_interest_libility": "TANGIBLEASSETTOINTERESTLIBILITY",  # 有形资产与带息债务之比
#     "tangible_asset_to_libility": "TANGIBLEASSETTOLIBILITY",  # 有形资产与负债合计之比
#     "tangible_asset_to_net_libility": "TANGIBLEASSETTONETLIBILITY",  # 有形资产与净债务之比
#     # 'times_inte_cf': '',  # 现金流量利息保障倍数
#     # 'n_cf_opa_ncl': '',  # 经营活动现金流量净额与非流动负债之比
#     # 'cash_icl': '',  # 货币资金与带息流动负债之比
#     # 'tl_teap': '',  # 负债合计与归属于母公司的股东权益之比
#     # 'ncl_wc': '',  # 非流动负债与营运资金比率之比
#     # 'n_cf_nfa_cl': '',  # 非筹资性现金流量净额与流动负债之比
#     # 'n_cf_nfa_liab': '',  # 非筹资性现金流量净额与负债总额之比
#     # 'times_inte_ebit': '',  # EBIT利息保障倍数
#     # 'times_inte_ebitda': '',  # EBITDA利息保障倍数
#
#     # table: finance_derivative 财务衍生数据
#     "fi_interest_free_current_liabilities": "EXINTERESTCL",  # 无息流动负债
#     "fi_interest_free_non_current_liabilities": "EXINTERESTNCL",  # 无息非流动负债
#     "fi_interest_bearing_debt": "INTERESTLIBILITY",  # 带息债务
#     "fi_net_debt": "NETLIBILITY",  # 净债务
#     "fi_tangible_net_assets": "TANGIBLEASSET",  # 有形净资产
#     "fi_working_capital": "WORKINGCAPITAL",  # 营运资本
#     "fi_net_working_apital": "NETWORKINGCAPITAL",  # 净营运资本
#     "fi_retained_earnings": "RETAINED",  # 留存收益
#     "fi_gross_margin": "GROSSMARGIN",  # 毛利
#     "fi_operate_income": "OPERATEINCOME",  # 经营活动净收益
#     "fi_investment_income": "INVESTINCOME",  # 价值变动净收益
#     "fi_ebit": "EBIT",  # 息税前利润
#     "fi_ebitda": "EBITDA",  # 息税折旧摊销前利润
#     "fi_extraordinary_item": "EXTRAORDINARY",  # 非经常性损益
#     "fi_deducted_income": "DEDUCTEDINCOME",  # 扣除非经常性损益后的归属于上市公司股东的净利润
#     "fi_free_cash_flow_firm": "FCFF",  # 企业自由现金流量
#     "fi_free_cash_flow_equity": "FCFE",  # 股权自由现金流量
#     "fi_depreciation_amortization": "DA",  # 折旧与摊销
#     # 'EBIAT':'',#息前税后利润
#     # 'N_INT_EXP':'',#净利息费用
#     # 'INT_CL':'',#带息流动负债
#     # 'IC':'',#投入资本
#
#     # table: finance_du_pont    财务指标-杜邦分析
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     "inc_net_profit_shareholders_to_net_profit": "DUPONTPNITONI",  # 归属母公司股东的净利润与净利润之比
#     "roe_avg": "DUPONTROE",  # 净资产收益率ROE
#     "em": "DUPONTASSETSTOEQUITY",  # 权益乘数(杜邦分析)
#     "total_assets_turnover": "DUPONTASSETTURN",  # 总资产周转率
#     "net_profit_to_total_operate_revenue": "DUPONTNITOGR",  # 净利润与营业总收入之比
#     "net_profit_to_total_profits": "DUPONTTAXBURDEN",  # 净利润与利润总额之比
#     "total_profits_to_fi_ebit": "DUPONTINTBURDEN",  # 利润总额与息税前利润之比
#     "fi_ebit_to_total_op_income": "DUPONTEBITTOGR",  # 息税前利润与营业总收入之比
#
#     # table: finance_factor_ttm 财务因子TTM
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 营业总收入TTM
#     "total_op_income_ttm": "GRTTMR",
#     # 营业总成本TTM
#     "total_operating_costs_ttm": "GCTTMR",
#     # 营业收入TTM
#     "operating_income_ttm": "ORTTMR",
#     # 营业成本非金融类TTM
#     "oc_ttm": "OCTTMR",
#     # 营业支出金融类TTM
#     "expense_ttm": "EXPENSETTMR",
#     # 毛利TTM
#     "fi_gross_margin_ttm": "GROSSMARGINTTMR",
#     # 销售费用TTM
#     "sales_costs_ttm": "OPERATEEXPENSETTMR",
#     # 管理费用TTM
#     "managing_costs_ttm": "ADMINEXPENSETTMR",
#     # 财务费用TTM
#     "financing_costs_ttm": "FINAEXPENSETTMR",
#     # 资产减值损失TTM
#     "assets_devaluation_ttm": "IMPAIRMENTTTMR",
#     # 经营活动净收益TTM
#     "fi_operate_income_ttm": "OPERATEINCOMETTMR",
#     # 价值变动净收益TTM
#     "fi_investment_income_ttm": "INVESTINCOMETTMR",
#     # 营业利润TTM
#     "operating_profit_ttm": "OPTTMR",
#     # 营业外收支净额TTM
#     "non_op_profit_ttm": "NONOPERATEPROFITTTMR",
#     # 息税前利润TTM
#     "fi_ebit_ttm": "EBITTTMR",
#     # 利润总额TTM
#     "total_profits_ttm": "EBTTTMR",
#     # 所得税TTM
#     "tax_ttm": "TAXTTMR",
#     # 归属母公司股东的净利润TTM
#     "net_profit_as_parent_ttm": "PNITTMR",
#     # 扣除非经常性损益净利润TTM
#     "fi_deducted_income_ttm": "KCFJCXSYJLRTTMR",
#     # 净利润TTM
#     "net_profit_ttm": "NPTTMRP",
#     # 公允价值变动损益TTM
#     "fvvpalrp_ttm": "FVVPALRP",
#     # 投资收益TTM
#     "investment_income_ttm": "IRTTMRP",
#     # 对联营企业和合营企业的投资收益TTM
#     "iittmjvajvrp_ttm": "IITTMFJVAJVRP",
#     # 营业税金及附加TTM
#     "btaa_ttm": "BTAATTMRP",
#     # 销售商品提供劳务收到的现金TTM
#     "sales_cash_in_ttm": "SALESCASHINTTMR",
#     # 经营活动现金净流量TTM
#     "cfo_ttm": "CFOTTMR",
#     # 投资活动现金净流量TTM
#     "cfi_ttm": "CFITTMR",
#     # 筹资活动现金净流量TTM
#     "cff_ttm": "CFFTTMR",
#     # 现金净流量TTM
#     "cf_ttm": "CFTTMR",
#     # 资本支出TTM
#     "capexr_ttm": "CAPEXR",
#
#     # table: finance_growth_ability     财务指标-成长能力
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 总资产同比增长率（%）
#     "asset_yoy": "YOYASSET",
#     # 营业总收入同比增长率（%）
#     "total_op_income_growth_yoy": "YOYGR",
#     # 营业利润同比增长率（%）
#     "op_yoy": "YOYOP",
#     # 利润总额同比增长率（%）
#     "ebt_yoy": "YOYEBT",
#     # 净利润同比增长率（%）
#     "ni_yoy": "YOYNI",
#     # 归属母公司股东的净利润同比增长率（%）
#     "inc_net_profit_shareholders_yoy": "YOYPNI",
#     # 归属母公司股东的净利润同比增长率(扣非)（%）
#     "deducted_net_profit_growth_yoy": "YOYPNIDEDUCTED",
#     # 基本每股收益同比增长率（%）
#     "basic_eps_you": "YOYEPSBASIC",
#     # 稀释每股收益同比增长率（%）
#     "diluted_eps_yoy": "YOYEPSDILUTED",
#     # 净资产收益率同比增长率(摊薄)
#     "roe_liluted_yoy": "YOYROELILUTED",
#     # 经营活动产生的现金流量净额同比增长率（%）
#     "cfo_yoy": "YOYCFO",
#     # 每股经营活动中产生的现金流量净额同比增长率（%）
#     "cfo_ps_yoy": "YOYCFOPS",
#     # 资产总计相对年初增长率（%）
#     "asset_relative": "ASSETRELATIVE",
#     # 归属母公司股东的权益相对年初增长率（%）
#     "equity_relative": "EQUITYRELATIVE",
#     # 每股净资产相对年初增长率（%）
#     "bps_relative": "BPSRELATIVE",
#     # 营业收入环比增长率（%）
#     "op_income_growth_qoq": "RTROR",
#     # 归属净利润滚动环比增长（%）
#     "net_profit_growth_qoq": "RTRNI",
#     # 归属母公司股东的净利润环比增长率（扣非）（%）
#     "deducted_net_profit_growth_qoq": "RTRPNIDEDUCTED",
#
#     # table: finance_income_statement_structure_analysis 财务指标-利润表结构分析
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     "financial_expense_rate": "QFINAEXPENSETOGR",  # 财务费用与营业总收入之比
#     "operating_profit_to_total_profit": "QOPERATEINCOMETOEBT",  # 经营活动净收益与利润总额之比
#     "net_profit_to_total_operate_revenue": "QNITOGR",  # 净利润与营业总收入之比
#     "admin_expense_rate": "QADMINEXPENSETOGR",  # 管理费用与营业总收入之比
#     "operating_profit_to_operating_revenue": "QOPTOGR",  # 营业利润与营业总收入之比
#     "total_operating_cost_to_total_operating_income": "QGCTOGR",  # 营业总成本与营业总收入之比
#
#     # table: finance_operational_capability财务指标-盈利能力
#     "pub_date": "STMTACTDATE",  # 公布日期
#     "fixed_assets_turnover_rate": "FATURNRATIO",  # 固定资产周转率
#     "current_asset_turnover_rate": "CATURNRATIO",  # 流动资产周转率
#     "total_assets_turnover": "ASSETTURNRATIO",  # 总资产周转率
#     "inventory_turnover": "INVTURNRATIO",  # 存货周转率
#     "inventory_turnover_days": "INVTURNDAYS",  # 存货周转天数
#     "receivables_turnover": "ARTURNRATIO",  # 应收账款周转率(含应收票据)
#     "receivables_turnover_days": "ARTURNDAYS",  # 应收账款周转天数(含应收票据)
#     "operating_cycle": "TURNDAYS",  # 营业周期
#     "accounts_payable_turnover_rate": "APTURNRATIO",  # 应付账款周转率(含应付票据)
#     "accounts_payable_turnover_days": "APTURNDAYS",  # 应付账款周转天数(含应付票据)
#
#     # table: finance_per_share 财务指标-每股指标
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     "fcfe_ps": "FCFEPS",  # 每股股东自由现金流量
#     "fcff_ps": "FCFFPS",  # 每股企业自由现金流量
#     "cf_ps_ttm": "CFPSTTM",  # 每股现金流量净额TTM(元)
#     "cf_ps": "CFPS",  # 每股现金流量净额(元)
#     "cfo_ps_ttm": "CFOPSTTM",  # 每股经营活动产生的现金流量净额TTM(元)
#     "cfo_ps": "CFOPS",  # 每股经营活动产生的现金流量净额(元)
#     "retained_ps": "RETAINEDPS",  # 每股留存收益(元)
#     "undistributed_ps": "UNDISTRIBUTEDPS",  # 每股未分配利润(元)
#     "surplus_reserve_ps": "SURPLUSRESERVEPS",  # 每股盈余公积(元)
#     "capital_reserve_ps": "CAPITALRESERVEPS",  # 每股资本公积(元)
#     "ebit_ps": "EBITPS",  # 每股息税前利润(元)
#     "or_ps_ttm": "ORPSTTM",  # 每股营业收入TTM(元)
#     "or_ps": "ORPS",  # 每股营业收入(元)
#     "gr_ps": "GRPS",  # 每股营业总收入(元)
#     "bps": "BPS",  # 每股净资产(元)
#     "eps_ttm": "EPSTTM",  # 每股收益EPSTTM(元)
#     "deducted_eps": "EPSEXBASIC",  # 扣非每股收益(元)
#     "diluted_eps": "EPSDILUTED",  # 稀释每股收益(元)
#     "eps_diluted_end": "EPSDILUTEDEND",  # 期末摊薄每股收益(元)
#     "eps": "EPSBASIC",  # 基本每股收益(元)
#
#     # table: finance_profit_ability 财务指标-盈利能力
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 净资产收益率ROE(摊薄)(%)
#     "roe_diluted": "ROEDILUTED",
#     # 净资产收益率ROE(平均)(%)
#     "roe_avg": "ROEAVG",
#     # 净资产收益率ROE(加权)(%)
#     "roe_wa": "ROEWA",
#     # 净资产收益率ROE(扣除/摊薄)(%)
#     "roe_ex_diluted": "ROEEXDILUTED",
#     # 净资产收益率ROE(扣除/加权)(%)
#     "roe_ex_wa": "ROEEXWA",
#     # 总资产报酬率ROA(%)
#     "roa": "ROA",
#     # 投入资本回报率ROIC(%)
#     "roic": "ROIC",
#     # 净资产收益率ROE(TTM)(%)
#     "roe_ttm": "ROETTM",
#     # 总资产报酬率ROA(TTM)(%)
#     "roa_ttm": "ROATTM",
#     # 总资产净利率ROA(%)
#     "net_roa": "NROA",
#     # 总资产净利率(TTM)(%)
#     "n_roa_ttm": "NROATTM",
#     # 销售净利率(%)
#     "np_margin": "NPMARGIN",
#     # 销售净利率(TTM)(%)
#     "np_margin_ttm": "NPMARGINTTM",
#     # 销售毛利率(%)
#     "gp_margin": "GPMARGIN",
#     # 销售毛利率(TTM)(%)
#     "gp_margin_ttm": "GPMARGINTTM",
#     # 销售期间费用率(%)
#     "expense_to_or": "EXPENSETOOR",
#     # 销售期间费用率(TTM)(%)
#     "expense_to_ors_ttm": "EXPENSETOORSTTM",
#     # 净利润/营业总收入(%)
#     "ni_to_gr": "NITOGR",
#     # 净利润/营业总收入(TTM)(%)
#     "ni_to_gr_ttm": "NITOGRTTM",
#     # 营业利润/营业总收入(%)
#     "op_to_gr": "OPTOGR",
#     # 营业利润/营业总收入(TTM)(%)
#     "op_to_gr_ttm": "OPTOGRTTM",
#     # 营业总成本/营业总收入(TTM)(%)
#     "gc_to_gr_ttm": "GCTOGRTTM",
#     # 营业费用/营业总收入(TTM)(%)
#     "operae_expense_to_gr_ttm": "OPERATEEXPENSETOGRTTM",
#     # 管理费用/营业总收入(TTM)(%)
#     "admin_expense_to_gr_ttm": "ADMINEXPENSETOGRTTM",
#     # 财务费用/营业总收入(TTM)(%)
#     "fina_expense_to_gr_ttm": "FINAEXPENSETOGRTTM",
#     # 资产减值损失/营业总收入(TTM)(%)
#     "impart_to_gr_ttm": "IMPAIRTOGRTTM",
#     # 净资产收益率ROETTM(扣非)(%)
#     "deducted_roe_ttm": "ROETTMDEDUCTED",
#     # 投入资本回报率ROIC(TTM)(%)
#     "roic_ttm": "ROICTTM",
#     # 成本费用利润率(%)
#     "np_to_cost_expense": "NPTOCOSTEXPENSE",
#     # 研发费用/营业总收入(%)
#     "rd_expense_to_gr": "RDEXPENSETOGR",
#
#     #table: finance_revenue_quality 财务指标-收益质量
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 营业外收支净额
#     "non_op_profit": "NONOPERATEPROFIT",
#     # 价值变动净收益/利润总额
#     "invest_income_to_ebt": "INVESTINCOMETOEBT",
#     # 营业外收支净额/利润总额
#     "non_op_profit_to_ebt": "NONOPERATEPROFITTOEBT",
#     # 所得税/利润总额
#     "tax_to_ebt": "TAXTOEBT",
#     # 扣除非经常性损益的净利润/净利润
#     "deducted_profit_to_ebt": "DEDUCTEDPROFITTOEBT",
#     # 经营活动净收益/利润总额
#     "op_income_to_ebt": "OPERATEINCOMETOEBT",
#     # 经营活动净收益/利润总额(TTM)
#     "op_income_to_ebt_ttm": "OPERATEINCOMETOEBTTTM",
#     # 价值变动净收益/利润总额(TTM)
#     "invest_income_to_ebt_ttm": "INVESTINCOMETOEBTTTM",
#     # 营业外收支净额/利润总额(TTM)
#     "non_op_profit_to_ebt_ttm": "NONOPERATEPROFITTOEBTTTM",
#
#     #table: income_statement 利润表
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 营业总收入
#     "total_op_income": "INCOMESTATEMENT_83",
#     # 营业收入
#     "operating_income": "INCOMESTATEMENT_9",
#     # 营业总成本
#     "total_operating_costs": "INCOMESTATEMENT_84",
#     # 营业成本
#     "operating_costs": "INCOMESTATEMENT_10",
#     # 研发费用
#     "rd_costs": "INCOMESTATEMENT_89",
#     # 提取保险合同准备金净额
#     "net_change_in_insurance_contract_reserves": "INCOMESTATEMENT_35",
#     # 营业税金及附加
#     "business_taxes_and_surcharges": "INCOMESTATEMENT_11",
#     # 销售费用
#     "sales_costs": "INCOMESTATEMENT_12",
#     # 管理费用
#     "managing_costs": "INCOMESTATEMENT_13",
#     # 财务费用
#     "financing_costs": "INCOMESTATEMENT_14",
#     # 资产减值损失
#     "assets_devaluation": "INCOMESTATEMENT_15",
#     # 其他经营收益
#     #
#     # 加: 投资收益
#     "investment_income": "INCOMESTATEMENT_17",
#     # 其中: 对联营企业和合营企业的投资收益
#     "investment_income_from_related_enterprise": "INCOMESTATEMENT_82",
#     # 营业利润
#     "operating_profit": "INCOMESTATEMENT_48",
#     # 加: 营业外收入
#     "non_operating_income": "INCOMESTATEMENT_49",
#     # 减: 营业外支出
#     "non_operating_costs": "INCOMESTATEMENT_50",
#     # 其中: 非流动资产处置净损失
#     "loss_on_disposal_non_current_asset": "INCOMESTATEMENT_51",
#     # 利润总额
#     "total_profits": "INCOMESTATEMENT_55",
#     # 减: 所得税费用
#     "tax_expense": "INCOMESTATEMENT_56",
#     # 净利润
#     "net_profit": "INCOMESTATEMENT_60",
#     # 其中: 归属于母公司股东的净利润
#     "net_profit_as_parent": "INCOMESTATEMENT_61",
#     # 少数股东损益
#     "net_profit_as_minority_interest": "INCOMESTATEMENT_62",
#     # 每股收益
#     # 基本每股收益
#     "eps": "INCOMESTATEMENT_80",
#     # 稀释每股收益
#     "diluted_eps": "INCOMESTATEMENT_81",
#     # 其他综合收益
#     "other_comprehensive_income": "INCOMESTATEMENT_114",
#     # 综合收益总额
#     "total_comprehensive_income": "INCOMESTATEMENT_113",
#     # 归属于母公司所有者的综合收益总额
#     "total_comprehensive_income_as_parent": "INCOMESTATEMENT_93",
#     # 归属于少数股东的综合收益总额
#     "total_comprehensive_income_as_minority_interest": "INCOMESTATEMENT_94",
#     # 公允价值变动收益
#     "fi_income_from_fair_value_change": "INCOMESTATEMENT_16",
#     # 汇兑收益
#     "fi_income_from_exchange": "INCOMESTATEMENT_25",
#     # 其中:利息收入
#     "fi_interest_income": "INCOMESTATEMENT_19",
#     # 已赚保费
#     "fi_net_income_from_premium": "INCOMESTATEMENT_28",
#     # 其中:手续费及佣金收入
#     "fi_incomes_from_fees_and_commissions": "INCOMESTATEMENT_22",
#     # 利息支出
#     "fi_interest_expenses": "INCOMESTATEMENT_20",
#     # 手续费及佣金支出
#     "fi_expenses_for_fees_and_commissions": "INCOMESTATEMENT_23",
#     # 退保金
#     "fi_insurance_surrender_costs": "INCOMESTATEMENT_39",
#     # 保单红利支出
#     "fi_dividend_expenses_to_insured": "INCOMESTATEMENT_40",
#     # 分保费用
#     "fi_reinsurance_expenses": "INCOMESTATEMENT_38",
#     # 赔付支出净额
#     "fi_net_payouts": "INCOMESTATEMENT_33",
#     # 资产处置收益
#     "fi_asset_disposal_income": "INCOMESTATEMENT_123",
#     # 其他收益
#     "fi_other_income": "INCOMESTATEMENT_124",
#     # 持续经营净利润
#     "fi_net_profit_continuing_operations": "INCOMESTATEMENT_125",
#     # 终止经营净利润
#     "fi_iscontinued_operating_net_profit": "INCOMESTATEMENT_126",
#
#     # table: cash_flow_statement_qtr 单季度_现金流量表
#     # 经营活动产生的现金流量
#     # 销售商品、提供劳务收到的现金
#     "cash_from_selling": "SALEGOODSSERVICEREC_S",
#     # 收到的税费返还
#     "tax_refund": "TAXRETURNREC_S",
#     # 收到其他与经营活动有关的现金
#     "cash_from_other_op": "OTHEROPERATEREC_S",
#     # 经营活动现金流入小计
#     "total_op_cash_inflows": "SUMOPERATEFLOWIN_S",
#     # 购买商品、接受劳务支付的现金
#     "cash_to_goods_services": "BUYGOODSSERVICEPAY_S",
#     # 支付给职工以及为职工支付的现金
#     "cash_to_employees": "EMPLOYEEPAY_S",
#     # 支付的各项税费
#     "taxes_and_surcharges": "TAXPAY_S",
#     # 支付其他与经营活动有关的现金
#     "cash_to_other_related_op": "OTHEROPERATEPAY_S",
#     # 经营活动现金流出小计
#     "total_op_cash_outflows": "SUMOPERATEFLOWOUT_S",
#     # 经营活动产生的现金流量净额
#     "net_op_cash_flows": "OPERATEFLOWOTHER_S",
#     # 投资活动产生的现金流量
#     # 收回投资收到的现金
#     "cash_from_disposal_of_investments": "DISPOSALINVREC_S",
#     # 取得投资收益收到的现金
#     "cash_from_returns_on_investments": "INVINCOMEREC_S",
#     # 处置固定资产、无形资产和其他长期资产收回的现金净额
#     "cash_from_disposal_fixed_intangible_assets": "DISPFILASSETREC_S",
#     # 处置子公司及其他营业单位收到的现金净额
#     "cash_from_disposal_subsidiaries": "DISPSUBSIDIARYREC_S",
#     # 收到其他与投资活动有关的现金
#     "cash_from_other_investing": "OTHERINVREC_S",
#     # 质押贷款净增加额
#     "fi_insured_pledge_loans_increase": "NIPLEDGELOAN_S",
#     # 投资活动现金流入小计
#     "total_investing_cash_inflows": "SUMINVFLOWIN_S",
#     # 购建固定资产、无形资产和其他长期资产支付的现金
#     "cash_to_acquire_fixed_intangible_assets": "BUYFILASSETPAY_S",
#     # 投资支付的现金
#     "cash_to_investments": "INVPAY_S",
#     # 取得子公司及其他营业单位支付的现金净额
#     "cash_to_acquire_subsidiaries": "GETSUBSIDIARYPAY_S",
#     # 支付其他与投资活动有关的现金
#     "cash_to_other_investing": "OTHERINVPAY_S",
#     # 投资活动现金流出小计
#     "total_investing_cash_outflows": "SUMINVFLOWOUT_S",
#     # 投资活动产生的现金流量净额
#     "net_investing_cash_flows": "INVFLOWOTHER_S",
#     # 支付保单红利的现金
#     "fi_cash_to_dividends": "DIVIPAY_S",
#     # 筹资活动产生的现金流量
#     # 吸收投资收到的现金
#     "cash_from_accepting_investment": "ACCEPTINVREC_S",
#     # 子公司吸收少数股东投资收到的现金
#     "cash_from_subsidiaries_accepting_minority_interest": "SUBSIDIARYACCEPT_S",
#     # 取得借款收到的现金
#     "cash_from_borrowings": "LOANREC_S",
#     # 发行债券收到的现金
#     "cash_from_issuing_bonds": "ISSUEBONDREC_S",
#     # 收到其他与筹资活动有关的现金
#     "cash_from_other_financing": "OTHERFINAREC_S",
#     # 筹资活动现金流入小计
#     "total_financing_cash_inflows": "SUMFINAFLOWIN_S",
#     # 偿还债务支付的现金
#     "cash_to_repay_borrowings": "REPAYDEBTPAY_S",
#     # 分配股利、利润或偿付利息支付的现金
#     "cash_to_pay_interest_dividend": "DIVIPROFITORINTPAY_S",
#     # 子公司支付给少数股东的股利、利润
#     "cash_to_pay_subsidiaries_minority_interest": "SUBSIDIARYPAY_S",
#     # 支付其他与筹资活动有关的现金
#     "cash_to_other_financing": "OTHERFINAPAY_S",
#     # 筹资活动现金流出小计
#     "total_financing_cash_outflows": "SUMFINAFLOWOUT_S",
#     # 筹资活动产生的现金流量净额
#     "net_financing_cash_flows": "FINAFLOWOTHER_S",
#     # 汇率变动对现金及现金等价物的影响
#     "foreign_exchange_rate_effect": "EFFECTEXCHANGERATE_S",
#     # 现金及现金等价物净增加额
#     "net_cash_increase": "NICASHEQUIOTHER_S",
#     # 加: 期初现金及现金等价物余额
#     "cash_at_beginning": "CASHEQUIBEGINNING_S",
#     # 期末现金及现金等价物余额
#     "cash": "CASHEQUIENDINGOTHER_S",
#     # 客户存款和同业及其他金融机构存放款项净增加额
#     "fi_deposit_increase": "NIDEPOSIT_S",
#     # 向中央银行借款净增加额
#     "fi_borrow_from_central_bank_increase": "NIBORROWFROMCBANK_S",
#     # 拆入资金净增加额
#     "fi_borrowing_increase": "NIBORROWFUND_S",
#     # 回购业务资金净增加额
#     "fi_cash_from_repurchase_increase": "NIBUYBACKFUND_S",
#     # 收取利息、手续费及佣金的现金
#     "fi_cash_from_interest_commission": "INTANDCOMMREC_S",
#     # 保户储金及投资款净增加额
#     "fi_insured_deposit_increase": "NIINSUREDDEPOSITINV_S",
#     # 收到再保险业务现金净额
#     "fi_cash_from_reinsurance": "NETRIREC_S",
#     # 保险相关
#     # 收到原保险合同保费取得的现金
#     "fi_cash_from_premium_of_original": "PREMIUMREC_S",
#     # 向其他金融机构拆入资金净增加额
#     "fi_lending_from_increase": "NIBORROWFROMFI_S",
#     # 处置交易性金融资产净增加额
#     "fi_disposal_trade_asset_add": "NIDISPTRADEFASSET_S",
#     # 客户贷款及垫款净增加额
#     "fi_loan_advance_increase": "NILOANADVANCES_S",
#     # 存放中央银行和同业款项及其他金融机构净增加额
#     "fi_deposit_in_others_add": "NIDEPOSITINCBANKFI_S",
#     # 支付原保险合同赔付等款项的现金
#     "fi_cash_to_insurance_claim": "INDEMNITYPAY_S",
#     # 支付利息、手续费及佣金的现金
#     "fi_cash_to_interest_commission": "INTANDCOMMPAY_S",
#     # 更新时间
#     "pub_date": "STMTACTDATE",
#
#     # table:  financial_index_qtr   单季度_财务指标表
#     "pub_date": "STMTACTDATE",   # 更新时间
#     "q_eps": "QEPS", # 单季度.每股收益EPS
#     "q_deducted_profit": "QDEDUCTEDPROFIT", # 单季度.扣除非经常损益后的净利润
#     "q_operate_income": "QOPERATEINCOME", #  单季度.经营活动净收益
#     "q_invest_income": "QINVESTINCOME", #  单季度.价值变动净收益
#     "q_roe": "QROE", #  单季度.净资产收益率ROE
#     "q_roe_deducted": "QROEDEDUCTED", #  单季度.净资产收益率(扣除非经常损益)
#     "q_roa": "QROA", #  单季度.总资产净利率ROA
#     "q_npmargin": "QNPMARGIN", #  单季度.销售净利率
#     "q_gpmargin": "QGPMARGIN", #  单季度.销售毛利率
#     "q_nitocost_expense": "QNITOCOSTEXPENSE", #  单季度.成本费用利润率
#     "q_optoebt": "QOPTOEBT",        # 单季度.营业利润/利润总额
#     "q_yoy_nideducted": "QYOYNIDEDUCTED", #  单季度.扣除非经常损益后的净利润同比增长率
#     "q_qoq_nideducted": "QQOQNIDEDUCTED", #  单季度.扣除非经常损益后的净利润环比增长率
#     "q_yoy_pni": "QYOYPNI", #  单季度.归属母公司股东的净利润同比增长率
#     "q_qoq_pni": "QCGRPNI", #  单季度.归属母公司股东的净利润环比增长率
#     "q_yoy_cfo": "QYOYCFO", #  单季度.经营活动产生的现金流量净额同比增长率
#     "q_qoq_cfo": "QQOQCFO", #  单季度.经营活动产生的现金流量净额环比增长率
#
#     "q_yoy_cf": "QYOYCF", #  单季度.现金流量净额同比增长率
#     "q_qoq_cf": "QQOQCF", #  单季度.现金流量净额环比增长率
#     "q_yoy_gpmargin": "QYOYGPMARGIN", #  单季度.毛利率同比增长率
#     "q_qoq_gpmargin": "QQOQGPMARGIN", #  单季度.毛利率环比增长率
#     "q_yoy_roe": "QYOYROE", #  单季度.净资产收益率ROE同比增长率
#     "q_qoq_roe": "QQOQROE", #  单季度.净资产收益率ROE环比增长率
#
#     # table: income_statement_qtr 单季度现金流量表
#         # 更新时间
#     "pub_date": "STMTACTDATE",
#     # 营业总收入(元)
#     "total_op_income": "TOTALOPERATEREVE_S",
#     # 营业收入
#     "operating_income": "OPERATEREVE_S",
#     # 营业总成本
#     "total_operating_costs": "TOTALOPERATEEXP_S",
#     # 营业成本
#     "operating_costs": "OPERATEEXP_S",
#     # 提取保险合同准备金净额
#     "net_change_in_insurance_contract_reserves": "NETCONTACTRESERVE_S",
#     # 营业税金及附加
#     "business_taxes_and_surcharges": "OPERATETAX_S",
#     # 销售费用
#     "sales_costs": "SALEEXP_S",
#     # 管理费用
#     "managing_costs": "MANAGEEXP_S",
#     # 财务费用
#     "financing_costs": "FINANCEEXP_S",
#     # 资产减值损失
#     "assets_devaluation": "ASSETDEVALUELOSS_S",
#     # 其他经营收益
#     # 加: 投资收益
#     "investment_income": "INVESTINCOME_S",
#     # 其中: 对联营企业和合营企业的投资收益
#     "investment_income_from_related_enterprise": "INVESTJOINTINCOME_S",
#     # 营业利润
#     "operating_profit": "OPERATEPROFIT_S",
#     # 加: 营业外收入
#     "non_operating_income": "NONOPERATEREVE_S",
#     # 减: 营业外支出
#     "non_operating_costs": "NONOPERATEEXP_S",
#     # 其中: 非流动资产处置净损失
#     "loss_on_disposal_non_current_asset": "NONLASSETNETLOSS_S",
#     # 利润总额
#     "total_profits": "SUMPROFIT_S",
#     # 减: 所得税费用
#     "tax_expense": "INCOMETAX_S",
#     # 净利润
#     "net_profit": "NETPROFIT_S",
#     # 其中: 归属于母公司股东的净利润
#     "net_profit_as_parent": "PARENTNETPROFIT_S",
#     # 少数股东损益
#     "net_profit_as_minority_interest": "MINORITYINCOME_S",
#     # 其他综合收益
#     "other_comprehensive_income": "OTHERCINCOME_S",
#     # 综合收益总额
#     "total_comprehensive_income": "SUMCINCOME_S",
#     # 归属于母公司所有者的综合收益总额
#     "total_comprehensive_income_as_parent": "PARENTCINCOME_S",
#     # 归属于少数股东的综合收益总额
#     "total_comprehensive_income_as_minority_interest": "MINORITYCINCOME_S",
#     # 已赚保费(元)
#     "fi_net_income_from_premium": "PREMIUMEARNED_S",
#     # 手续费及佣金收入
#     "fi_incomes_from_fees_and_commissions": "COMMREVE_S",
#     # 利息收入(元)
#     "fi_interest_income": "INTREVE_S",
#     # 利息支出(元)
#     "fi_interest_expenses": "INTEXP_S",
#     # 手续费及佣金支出(元)
#     "fi_expenses_for_fees_and_commissions": "COMMEXP_S",
#     # 退保金(元)
#     "fi_insurance_surrender_costs": "SURRENDERPREMIUM_S",
#     # 赔付支出净额(元)
#     "fi_net_payouts": "NETINDEMNITYEXP_S",
#     # 保单红利支出(元)
#     "fi_dividend_expenses_to_insured": "POLICYDIVIEXP_S",
#     # 分保费用
#     "fi_reinsurance_expenses": "RIEXP_S",
#     # 公允价值变动收益(损失以“-”号填列)
#     "fi_income_from_fair_value_change": "FVALUEINCOME_S",
#     # 汇兑收益(损失以“-”号填列)
#     "fi_income_from_exchange": "EXCHANGEINCOME_S",
#     # 资产处置收益
#     "fi_asset_disposal_income": "ADISPOSALINCOME_S",
#     # 其他收益
#     "fi_other_income": "MIOTHERINCOME_S",
#     # 持续经营净利润
#     "fi_net_profit_continuing_operations": "CONTINUOUSONPROFIT_S",
#     # 终止经营净利润
#     "fi_iscontinued_operating_net_profit": "TERMINATIONONPROFIT_S",
#
#
#
#
# }
#
# map_data = {value[0]: key for key, value in self.get_data_map().items()}
#
