import pickle

from zero.encoder import Encoder


class Worker:
    def __init__(self, name: str):
        self._login = False
        self.name = name

    def start(self):
        raise NotImplementedError

    def stop(self):
        raise NotImplementedError

    def is_login(self):
        return self._login


class JEncoder(Encoder):
    @classmethod
    def encode(cls, obj):
        return pickle.dumps(obj, pickle.HIGHEST_PROTOCOL)

    @classmethod
    def decode(cls, obj):
        return pickle.loads(obj)
