# 统一的数据接口，和数据源无关
# 可以综合评价各接口数据源的情况，来排序选择数据源来取数据，前提是各数据源支持相同的接口
from typing import List


def find_data_source(func_nme: str, by: str) -> callable:
    """统一控制数据源的使用，TODO 根据流量和更新时间来选择数据源
    Args:
        func_nme: 函数名称
        by: "剩余流量"|"有没有数据"|"数据更新时间"

    Returns:

    """
    _module = locals()["jq"]
    return getattr(_module, func_nme)


def get_all_securities(types: List = ("stock"), start_date=None, end_date=None):
    """获取所有股票信息"""
    func = find_data_source("get_all_securities", "剩余流量")
    return func(types, start_date, end_date)
