# facade接口是为满足provider server的统一api，而针对各自数据源的api的封装, 例如jindata\provider\jq\facade.py，是针对jq接口的api实现。
from functools import partial

import pandas as pd
from zero import ZeroClient

from ..server import JEncoder

# 目前聚宽的类型
jindata_to_jq_entity_map = {
    "stocks": "stock",
    "funds": "fund",
    "index": "index",
}

_client = ZeroClient("localhost", 5559, encoder=JEncoder)
jq_client = partial(_client.call, "run_jq_api")


def jq_call(*args):
    return jq_client(args)


def get_all_securities(types=("stocks"), start_date=None, end_date=None):
    """获取所有证券信息
    返回数据格式：
        字段	            名称	              备注
        display_name	中文名称
        name	        缩写简称
        start_date	    上市日期
        end_date	    退市日期	      如果没有退市则为2200-01-01
        type	        证券类型	          stock(股票)，index(指数)，etf(ETF基金)，fja（分级A），fjb（分级B），fjm（分级母基金），
                                      mmf（场内交易的货币基金）open_fund（开放式基金）, bond_fund（债券基金）, stock_fund（股票型基金）,
                                      QDII_fund（QDII 基金）, money_market_fund（场外交易的货币基金）, mixture_fund（混合型基金）, options(期权)
    Note:
    如果不支持的类型会被丢弃
    """
    types = [
        jindata_to_jq_entity_map[type_name]
        for type_name in types
        if type_name in jindata_to_jq_entity_map
    ]
    dates = jq_call("get_trade_days", start_date, end_date)
    data_list = []
    for date in dates:
        data_list.append(jq_call("get_all_securities", types, date))
    if data_list:
        data = pd.concat(data_list)
        data.columns = ["中文名称", "缩写简称", "上市日期", "退市日期", "证券类型"]
        return data
    else:
        return pd.DataFrame()
