# {
#     # table: dividend_financing 分红
#     # 分红总额
#     "dividend_money": "bonus_amount_rmb",
#     # 新股
#     "ipo_issues": "ipo_shares",
#     # IPO募集资金
#     "ipo_raising_fund": "ipo_raising_fund",
#     # 增发
#     "spo_issues": "spo_issues",
#     "spo_raising_fund": "spo_raising_fund",
#     # 配股
#     "rights_issues": "rights_issues",
#     "rights_raising_fund": "rights_raising_fund",  # 实际配股
#     "rights_issue_price": "rights_issue_price",  # 实际增发
#     "spo_price": "spo_price",  # 实际募集
#     # table: balance_sheet 资产负债表
#     # 流动资产
#     #
#     # 货币资金
#     "cash_and_cash_equivalents": "cash_equivalents",
#     # 应收票据
#     "note_receivable": "bill_receivable",
#     # 应收账款
#     "accounts_receivable": "account_receivable",
#     # 预付款项
#     "advances_to_suppliers": "advance_payment",
#     # 其他应收款
#     "other_receivables": "other_receivable",
#     # 存货
#     "inventories": "inventories",
#     # 一年内到期的非流动资产
#     "current_portion_of_non_current_assets": "non_current_asset_in_one_year",
#     # 其他流动资产
#     ###"other_current_assets": "Otherlasset",
#     # 流动资产合计
#     "total_current_assets": "total_current_assets",
#     # 非流动资产
#     #
#     # 可供出售金融资产
#     "fi_assets_saleable": "hold_for_sale_assets",
#     # 长期应收款
#     "long_term_receivables": "longterm_receivable_account",
#     # 长期股权投资
#     "long_term_equity_investment": "longterm_equity_invest",
#     # 投资性房地产
#     "real_estate_investment": "investment_property",
#     # 固定资产
#     "fixed_assets": "fixed_assets",
#     # 在建工程
#     "construction_in_process": "constru_in_process",
#     # 无形资产
#     "intangible_assets": "intangible_assets",
#     # 商誉
#     "goodwill": "good_will",
#     # 长期待摊费用
#     "long_term_prepaid_expenses": "long_deferred_expense",
#     # 递延所得税资产
#     "deferred_tax_assets": "deferred_tax_assets",
#     # 其他非流动资产
#     "other_non_current_assets": "Othernonlasset",
#     # 非流动资产合计
#     "total_non_current_assets": "total_non_current_assets",
#     # 资产总计
#     "total_assets": "total_assets",
#     # 流动负债
#     #
#     # 短期借款
#     "short_term_borrowing": "shortterm_loan",
#     # 吸收存款及同业存放
#     "accept_money_deposits": "deposit_in_interbank",
#     # 应付账款
#     "accounts_payable": "accounts_payable",
#     # 预收款项
#     "advances_from_customers": "advance_peceipts",
#     # 应付职工薪酬
#     "employee_benefits_payable": "salaries_payable",
#     # 应交税费
#     "taxes_payable": "taxs_payable",
#     # 应付利息
#     "interest_payable": "interest_payable",
#     # 其他应付款
#     "other_payable": "other_payable",
#     # 一年内到期的非流动负债
#     "current_portion_of_non_current_liabilities": "non_current_liability_in_one_year",
#     # 其他流动负债
#     ### "other_current_liabilities": "Otherlliab",
#     # 流动负债合计
#     "total_current_liabilities": "total_current_liability",
#     # 非流动负债
#     #
#     # 长期借款
#     "long_term_borrowing": "longterm_loan",
#     # 长期应付款
#     "long_term_payable": "longterm_account_payable",
#     # 递延收益-非流动负债
#     "deferred_revenue": "deferred_earning",
#     # 递延所得税负债
#     "deferred_tax_liabilities": "deferred_tax_liability",
#     # 其他非流动负债
#     ### "other_non_current_liabilities": "Othernonlliab",
#     # 非流动负债合计
#     "total_non_current_liabilities": "total_non_current_liability",
#     # 负债合计
#     "total_liabilities": "total_liability",
#     # 所有者权益(或股东权益)
#     #
#     # 实收资本（或股本）
#     "capital": "paidin_capital",
#     # 资本公积
#     "capital_reserve": "capital_reserve_fund",
#     # 专项储备
#     "special_reserve": "specific_reserves",
#     # 盈余公积
#     "surplus_reserve": "surplus_reserve_fund",
#     # 未分配利润
#     "undistributed_profits": "retained_profit",
#     # 归属于母公司股东权益合计
#     "equity": "equities_parent_company_owners",
#     # 少数股东权益
#     "equity_as_minority_interest": "minority_interests",
#     # 股东权益合计
#     "total_equity": "total_owner_equities",
#     # 负债和股东权益合计
#     "total_liabilities_and_equity": "total_sheet_owner_equities",
#     # 银行相关
#     # 资产
#     # 现金及存放中央银行款项
#     # "fi_cash_and_deposit_in_central_bank": "cash_in_cb",
#     # 存放同业款项
#     # "fi_deposit_in_other_fi": "deposit_in_ib",
#     # 贵金属
#     # "fi_expensive_metals": "metal",
#     # 拆出资金
#     "fi_lending_to_other_fi": "lend_capital",
#     # 以公允价值计量且其变动计入当期损益的金融资产(交易性金融资产)
#     # "fi_financial_assets_effect_current_income": "fairvalue_fianancial_asset",
#     # 衍生金融资产
#     "fi_financial_derivative_asset": "derivative_financial_asset",
#     # 买入返售金融资产
#     "fi_buying_sell_back_fi__asset": "bought_sellback_assets",
#     # 应收利息
#     "fi_interest_receivable": "interest_receivable",
#     # 发放贷款及垫款
#     # "fi_disbursing_loans_and_advances": "loan_and_advance",
#     # 可供出售金融资产
#     #
#     # 持有至到期投资
#     "fi_held_to_maturity_investment": "hold_to_maturity_investments",
#     # 应收款项类投资
#     # "fi_account_receivable_investment": "investment_reveiable",
#     # 投资性房地产
#     # 其他资产
#     # "fi_other_asset": "other_asset",
#     # 资产总计
#     # 向中央银行借款
#     "fi_borrowings_from_central_bank": "borrowing_from_centralbank",
#     # 同业和其他金融机构存放款项
#     # "fi_deposit_from_other_fi": "deposit_in_ib_and_other",
#     # 拆入资金
#     "fi_borrowings_from_fi": "borrowing_capital",
#     # 以公允价值计量且其变动计入当期损益的金融负债
#     # "fi_financial_liability_effect_current_income": "fairvalue_financial_liability",
#     # 衍生金融负债
#     "fi_financial_derivative_liability": "derivative_financial_liability",
#     # 卖出回购金融资产款
#     "fi_sell_buy_back_fi_asset": "sold_buyback_secu_proceeds",
#     # 吸收存款
#     # "fi_savings_absorption": "deposit_absorb",
#     # 存款证及应付票据
#     "fi_notes_payable": "notes_payable",
#     # 预计负债
#     "fi_estimated_liabilities": "estimate_liability",
#     # 应付债券
#     "fi_bond_payable": "bonds_payable",
#     # 其他负债
#     # "fi_other_liability": "other_liability",
#     # 股本
#     # "fi_capital": "Shequity",
#     # 其他权益工具
#     "fi_other_equity_instruments": "other_equity_tools",
#     # 其中:优先股
#     # 负债及股东权益总计
#     # "fi_total_liability_equity": "total_liability_equity",
#     # 其中: 客户资金存款
#     # "fi_client_fund": "deposit_client",
#     # 结算备付金
#     "fi_deposit_reservation_for_balance": "settlement_provi",
#     # 其中: 客户备付金
#     # "fi_client_deposit_reservation_for_balance": "settlement_provi_client",
#     # 融出资金
#     # "fi_margin_out_fund": "finance_out",
#     # 应收款项类投资
#     # "fi_receivables": "investment_reveiable",
#     # 存出保证金
#     # "fi_deposit_for_recognizance": "margin_out",
#     # 可供出售金融资产
#     # 代理买卖证券款
#     "fi_receiving_as_agent": "proxy_secu_proceeds",
#     # 应付短期融资款
#     # "fi_short_financing_payable": "shortterm_loan_payable",
#     # 预计负债
#     # 保险相关
#     # 应收保费
#     "fi_premiums_receivable": "insurance_receivables",
#     # 应收分保账款
#     "fi_reinsurance_premium_receivable": "reinsurance_receivables",
#     # 应收分保合同准备金
#     "fi_reinsurance_contract_reserve": "reinsurance_contract_reserves_receivable",
#     # 保户质押贷款
#     # "fi_policy_pledge_loans": "margin_loan",
#     # 定期存款
#     # "fi_time_deposit": "deposit_period",
#     # 存出资本保证金
#     # "fi_deposit_for_capital_recognizance": "capital_margin_out",
#     # 投资性房地产
#     # 独立账户资产
#     # "fi_capital_in_independent_accounts": "Independentasset",
#     # 资产总计
#     # 预收账款
#     # "fi_advance_from_customers": "advance_peceipts",
#     # 预收保费
#     # "fi_advance_premium": "insurance_receive_early",
#     # 应付手续费及佣金
#     "fi_fees_and_commissions_payable": "commission_payable",
#     # 应付分保账款
#     "fi_dividend_payable_for_reinsurance": "reinsurance_payables",
#     # 应付赔付款
#     # "fi_claims_payable": "compensation_payable",
#     # 应付保单红利
#     # "fi_policy_holder_dividend_payable": "interest_insurance_payable",
#     # 保户储金及投资款
#     # "fi_policy_holder_deposits_and_investment_funds": "investment_money",
#     # 保险合同准备金
#     "fi_contract_reserve": "insurance_contract_reserves",
#     # table: cash_flow_statement 现金流量表
#     # 经营活动产生的现金流量
#     # 销售商品、提供劳务收到的现金
#     "cash_from_selling": "goods_sale_and_service_render_cash",
#     # 收到的税费返还
#     "tax_refund": "tax_levy_refund",
#     # 经营活动现金流入小计
#     "total_op_cash_inflows": "subtotal_operate_cash_inflow",
#     # 购买商品、接受劳务支付的现金
#     "cash_to_goods_services": "goods_and_services_cash_paid",
#     # 支付给职工以及为职工支付的现金
#     "cash_to_employees": "staff_behalf_paid",
#     # 支付的各项税费
#     "taxes_and_surcharges": "tax_payments",
#     # 经营活动现金流出小计
#     "total_op_cash_outflows": "subtotal_operate_cash_outflow",
#     # 经营活动产生的现金流量净额
#     "net_op_cash_flows": "net_operate_cash_flow",
#     # 投资活动产生的现金流量
#     # 收回投资收到的现金
#     "cash_from_disposal_of_investments": "invest_withdrawal_cash",
#     # 取得投资收益收到的现金
#     "cash_from_returns_on_investments": "invest_proceeds",
#     # 处置固定资产、无形资产和其他长期资产收回的现金净额
#     "cash_from_disposal_fixed_intangible_assets": "fix_intan_other_asset_dispo_cash",
#     # 处置子公司及其他营业单位收到的现金净额
#     "cash_from_disposal_subsidiaries": "net_cash_deal_subcompany",
#     # 投资活动现金流入小计
#     "total_investing_cash_inflows": "subtotal_invest_cash_inflow",
#     # 购建固定资产、无形资产和其他长期资产支付的现金
#     "cash_to_acquire_fixed_intangible_assets": "fix_intan_other_asset_acqui_cash",
#     # 投资支付的现金
#     "cash_to_investments": "invest_cash_paid",
#     # 取得子公司及其他营业单位支付的现金净额
#     "cash_to_acquire_subsidiaries": "net_cash_from_sub_company",
#     # 支付其他与投资活动有关的现金
#     ###"cash_to_other_investing": "Otherinvpay",
#     # 投资活动现金流出小计
#     "total_investing_cash_outflows": "subtotal_invest_cash_outflow",
#     # 投资活动现金流量净额
#     "net_investing_cash_flows": "net_invest_cash_flow",
#     # 筹资活动产生的现金流量
#     #
#     # 吸收投资收到的现金
#     "cash_from_accepting_investment": "cash_from_invest",
#     # 子公司吸收少数股东投资收到的现金
#     "cash_from_subsidiaries_accepting_minority_interest": "cash_from_mino_s_invest_sub",
#     # 取得借款收到的现金
#     "cash_from_borrowings": "cash_from_borrowing",
#     # 发行债券收到的现金
#     "cash_from_issuing_bonds": "cash_from_bonds_issue",
#     # 收到其他与筹资活动有关的现金
#     ###"cash_from_other_financing": "Otherfinarec",
#     # 筹资活动现金流入小计
#     "total_financing_cash_inflows": "subtotal_finance_cash_inflow",
#     # 偿还债务支付的现金
#     "cash_to_repay_borrowings": "borrowing_repayment",
#     # 分配股利、利润或偿付利息支付的现金
#     "cash_to_pay_interest_dividend": "dividend_interest_payment",
#     # 子公司支付给少数股东的股利、利润
#     "cash_to_pay_subsidiaries_minority_interest": "proceeds_from_sub_to_mino_s",
#     # 筹资活动现金流出小计
#     "total_financing_cash_outflows": "subtotal_finance_cash_outflow",
#     # 筹资活动产生的现金流量净额
#     "net_financing_cash_flows": "net_finance_cash_flow",
#     # 汇率变动对现金及现金等价物的影响
#     "foreign_exchange_rate_effect": "exchange_rate_change_effect",
#     # 现金及现金等价物净增加额
#     "net_cash_increase": "cash_equivalent_increase",
#     # 加: 期初现金及现金等价物余额
#     "cash_at_beginning": "cash_equivalents_at_beginning",
#     # 期末现金及现金等价物余额
#     "cash": "cash_and_equivalents_at_end",
#     # 银行相关
#     # 客户存款和同业及其他金融机构存放款项净增加额
#     "fi_deposit_increase": "net_deposit_increase",
#     # 向中央银行借款净增加额
#     "fi_borrow_from_central_bank_increase": "net_borrowing_from_central_bank",
#     # 收取的利息、手续费及佣金的现金
#     "fi_cash_from_interest_commission": "interest_and_commission_cashin",
#     # 客户贷款及垫款净增加额
#     "fi_loan_advance_increase": "net_loan_and_advance_increase",
#     # 支付利息、手续费及佣金的现金
#     "fi_cash_to_interest_commission": "handling_charges_and_commission",
#     # 保险相关
#     # 收到原保险合同保费取得的现金
#     "fi_cash_from_premium_of_original": "net_original_insurance_cash",
#     # 保户储金及投资款净增加额
#     "fi_insured_deposit_increase": "net_insurer_deposit_investment",
#     # 支付原保险合同赔付等款项的现金
#     "fi_cash_to_insurance_claim": "original_compensation_paid",
#     # 支付保单红利的现金
#     "fi_cash_to_dividends": "policy_dividend_cash_paid",
#     # 券商相关
#     # 拆入资金净增加额
#     "fi_borrowing_increase": "net_increase_in_placements",
#     # 回购业务资金净增加额
#     "fi_cash_from_repurchase_increase": "net_buyback",
#     # table: finance_factor
#     # 基本每股收益(元)
#     "basic_eps": "eps",
#     # 扣非每股收益(元)
#     "deducted_eps": "adjusted_profit",
#     # 稀释每股收益(元)
#     "diluted_eps": "diluted_eps",
#     # 每股净资产(元)
#     "bps": "net_asset_per_share",
#     # 每股资本公积(元)
#     "capital_reserve_ps": "capital_reserve_fund_per_share",
#     # 每股未分配利润(元)
#     # "undistributed_profit_ps": "retained_profit_per_share",
#     # 每股经营现金流(元)
#     # "op_cash_flow_ps": "cashflow_per_share_ttm",
#     # 成长能力指标
#     #
#     # 营业总收入(元)
#     # "total_op_income": "total_operating_revenue",
#     # 毛利润(元)
#     # "gross_profit": "Grossprofit",
#     # 净利润(元)
#     # "net_profit": "net_profit",
#     # 归属于母公司所有者的净利润(元)
#     "np_parent_company_owners": "np_parent_company_owners",
#     # 扣除非经常损益后的净利润(元)
#     "deducted_net_profit": "adjusted_profit",
#     # 营业总收入同比增长率
#     "total_op_income_growth_yoy": "inc_total_revenue_year_on_year",
#     # 归属母公司股东的净利润同比增长率
#     "inc_net_profit_shareholders_yoy ": "inc_net_profit_to_shareholders_year_on_year",
#     # 扣非净利润同比增长
#     # "deducted_net_profit_growth_yoy": "Bucklenetprofityoy",
#     # 营业总收入滚动环比增长
#     "op_income_growth_qoq": "inc_total_revenue_annual",
#     # 归属净利润滚动环比增长
#     "net_profit_growth_qoq": "inc_net_profit_to_shareholders_annual",
#     # 扣非净利润滚动环比增长
#     # "deducted_net_profit_growth_qoq": "Bucklenetprofitrelativeratio",
#     # 盈利能力指标
#     #
#     # 净资产收益率(加权)
#     "roe": "roe",
#     # 净资产收益率(扣非/加权)
#     "deducted_roe": "inc_return",
#     # 总资产收益率(加权)
#     # "rota": "Allcapitalearningsrate",
#     # 毛利率
#     "gross_profit_margin": "gross_profit_margin",
#     # 净利率
#     "net_margin": "net_profit_margin",
#     # 收益质量指标
#     #
#     # 预收账款/营业收入
#     # "advance_receipts_per_op_income": "Accountsrate",
#     # 销售净现金流/营业收入
#     # "sales_net_cash_flow_per_op_income": "Salesrate",
#     # 经营净现金流/营业收入
#     # "op_net_cash_flow_per_op_income": "Operatingrate",
#     # 实际税率
#     # "actual_tax_rate": "Taxrate",
#     # 财务风险指标
#     #
#     # 流动比率
#     # "current_ratio": "Liquidityratio",
#     # 速动比率
#     # "quick_ratio": "Quickratio",
#     # 现金流量比率
#     # "cash_flow_ratio": "Cashflowratio",
#     # 资产负债率
#     # "debt_asset_ratio": "Assetliabilityratio",
#     # 权益乘数
#     # "em": "Equitymultiplier",
#     # 产权比率
#     # "equity_ratio": "Equityratio",
#     # 营运能力指标(一般企业)
#     #
#     # 总资产周转天数(天)
#     # "total_assets_turnover_days": "Totalassetsdays",
#     # 存货周转天数(天)
#     "inventory_turnover_days": "Inventorydays",
#     # 应收账款周转天数(天)
#     "receivables_turnover_days": "Accountsreceivabledays",
#     # 总资产周转率(次)
#     "total_assets_turnover": "Totalassetrate",
#     # 存货周转率(次)
#     "inventory_turnover": "Inventoryrate",
#     # 应收账款周转率(次)
#     "receivables_turnover": "Accountsreceiveablerate",
#     # 专项指标(银行)
#     #
#     # 存款总额
#     "fi_total_deposit": "Totaldeposit",
#     # 贷款总额
#     "fi_total_loan": "Totalloan",
#     # 存贷款比例
#     "fi_loan_deposit_ratio": "Depositloanratio",
#     # 资本充足率
#     "fi_capital_adequacy_ratio": "Capitaladequacyratio",
#     # 核心资本充足率
#     "fi_core_capital_adequacy_ratio": "Corecapitaladequacyratio",
#     # 不良贷款率
#     "fi_npl_ratio": "Nplratio",
#     # 不良贷款拨备覆盖率
#     "fi_npl_provision_coverage": "Nplprovisioncoverage",
#     # 资本净额
#     "fi_net_capital": "Netcapital_b",
#     # 专项指标(保险)
#     #
#     # 总投资收益率
#     "insurance_roi": "Tror",
#     # 净投资收益率
#     "insurance_net_investment_yield": "Nror",
#     # 已赚保费
#     "insurance_earned_premium": "Eapre",
#     # 赔付支出
#     "insurance_payout": "Comexpend",
#     # 退保率
#     "insurance_surrender_rate": "Surrate",
#     # 偿付能力充足率
#     "insurance_solvency_adequacy_ratio": "Solvenra",
#     # 专项指标(券商)
#     #
#     # 净资本
#     "broker_net_capital": "Netcapital",
#     # 净资产
#     "broker_net_assets": "Netassets",
#     # 净资本/净资产
#     "broker_net_capital_assets_ratio": "Captialrate",
#     # 自营固定收益类证券规模/净资本
#     "broker_self_operated_fixed_income_securities_net_capital_ratio": "Incomesizerate",
#     # table: income_statement 利润表
#     # 营业总收入
#     "total_op_income": "total_operating_revenue",
#     # 营业收入
#     "operating_income": "operating_revenue",
#     # 营业总成本
#     "total_operating_costs": "total_operating_cost",
#     # 营业成本
#     "operating_costs": "operating_cost",
#     # 研发费用
#     # "rd_costs": "rd_expenses",
#     # 提取保险合同准备金净额
#     "net_change_in_insurance_contract_reserves": "withdraw_insurance_contract_reserve",
#     # 营业税金及附加
#     "business_taxes_and_surcharges": "operating_tax_surcharges",
#     # 销售费用
#     "sales_costs": "sale_expense",
#     # 管理费用
#     "managing_costs": "administration_expense",
#     # 财务费用
#     "financing_costs": "financial_expense",
#     # 资产减值损失
#     "assets_devaluation": "asset_impairment_loss",
#     # 其他经营收益
#     #
#     # 加: 投资收益
#     "investment_income": "investment_income",
#     # 其中: 对联营企业和合营企业的投资收益
#     "investment_income_from_related_enterprise": "invest_income_associates",
#     # 营业利润
#     "operating_profit": "operating_profit",
#     # 加: 营业外收入
#     "non_operating_income": "non_operating_revenue",
#     # 减: 营业外支出
#     "non_operating_costs": "non_operating_expense",
#     # 其中: 非流动资产处置净损失
#     "loss_on_disposal_non_current_asset": "disposal_loss_non_current_liability",
#     # 利润总额
#     "total_profits": "total_profit",
#     # 减: 所得税费用
#     "tax_expense": "income_tax_expense",
#     # 净利润
#     "net_profit": "net_profit",
#     # 其中: 归属于母公司股东的净利润
#     "net_profit_as_parent": "np_parent_company_owners",
#     # 少数股东损益
#     "net_profit_as_minority_interest": "minority_profit",
#     # 扣除非经常性损益后的净利润
#     # "deducted_net_profit": "adjusted_profit",
#     # 每股收益
#     "eps": "eps",
#     # 其他综合收益
#     "other_comprehensive_income": "other_comprehensive_income",
#     # 综合收益总额
#     "total_comprehensive_income": "total_composite_income",
#     # 归属于母公司所有者的综合收益总额
#     "total_comprehensive_income_as_parent": "ci_parent_company_owners",
#     # 归属于少数股东的综合收益总额
#     "total_comprehensive_income_as_minority_interest": "ci_minority_owners",
#     # 银行相关
#     # 其中:利息收入
#     "fi_interest_income": "interest_income",
#     # 利息支出
#     "fi_interest_expenses": "interest_expense",
#     # 手续费及佣金净收入
#     # "fi_net_incomes_from_fees_and_commissions": "commission_net_income",
#     # 其中:手续费及佣金收入
#     "fi_incomes_from_fees_and_commissions": "commission_income",
#     # 手续费及佣金支出
#     "fi_expenses_for_fees_and_commissions": "commission_expense",
#     # 公允价值变动收益
#     "fi_income_from_fair_value_change": "fair_value_variable_income",
#     # 汇兑收益
#     "fi_income_from_exchange": "exchange_income",
#     # 其他业务收入
#     "fi_other_income": "other_income",
#     # 保险相关
#     # 已赚保费
#     "fi_net_income_from_premium": "premiums_earned",
#     # 退保金
#     "fi_insurance_surrender_costs": "refunded_premiums",
#     # 保单红利支出
#     "fi_dividend_expenses_to_insured": "policy_dividend_payout",
#     # 分保费用
#     "fi_reinsurance_expenses": "reinsurance_cost",
#     # table: stock_performance_forecast 业绩预告
#     # 预告类型
#     "preview_type": "type",
#     # 预告净利润（下限）
#     "profit_min": "profit_min",
#     # 预告净利润（上限）
#     "profit_max": "profit_max",
#     # 去年同期净利润（上限）
#     "profit_last": "profit_last",
#     # 预告净利润变动幅度(下限)单位：%
#     "profit_ratio_min": "profit_ratio_min",
#     # 预告净利润变动幅度(上限)单位：%
#     "profit_ratio_max": "profit_ratio_max",
#     # 预告内容
#     "content": "content",
# }
#
# finance_factor_map["report_period"] = ("ReportDate", to_report_period_type)
# finance_factor_map["report_date"] = ("ReportDate", to_pd_timestamp)
