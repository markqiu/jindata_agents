import os
from typing import Dict, List

from loguru import logger
from numpy import ndarray
from pandas import DataFrame

from ..server import Worker


class 聚宽客户端错误(Exception):
    pass


class JQWorker(Worker):
    def __init__(self, username: str, password: str):
        super().__init__("jq")
        self._client = None
        self._login = False
        os.environ["JQDATA_USERNAME"] = username
        os.environ["JQDATA_PASSWORD"] = password

    def start(self):
        if self._login:
            return
        try:
            import jqdatasdk as jq

            self._client = jq.JQDataClient.instance()
            self._sdk = jq
            self._client.ensure_auth()
            count = self._client.get_query_count()
            logger.info(f"聚宽客户端登录成功，流量情况：{count}")
        except ImportError:
            logger.warning("请先安装聚宽接口安装包再使用！")
        except InterruptedError as e:
            logger.error(f"聚宽登录失败! {e}")
        except Exception as e:
            logger.error(f"聚宽客户端登录失败，原因：{e}")
        else:
            self._login = True

    def stop(self):
        # 退出
        if self._login:
            self._client.logout()
            if self._client.inited:
                msg = "聚宽api退出失败！"
                logger.error(msg)
                raise 聚宽客户端错误(msg)
            else:
                self._login = False

    def raw_api(self, func_name: str, *args) -> Dict or List:
        """原始接口, 请参考接口文档。

        Parameters
        ----------
        func_name: 函数名称
        args: 接口的其他参数


        Returns
        -------
        DataFrame

        """
        args_str = "', '".join([str(a) for a in args])
        try:
            func = getattr(self._sdk, func_name)
            logger.debug(f"调用聚宽接口{func_name}({args_str})")
            data = func(*args)
            if not isinstance(data, DataFrame) and not isinstance(data, ndarray):
                error_msg = f"调用{func_name}({args_str})时返回数据格式不规范，返回数据为：{args_str}"
                logger.error(error_msg)
                return error_msg
            else:
                logger.trace(f"{func_name}({args_str})调用成功，返回数据如下：{data}")
                return data

        except AttributeError:
            msg = f"没有找到{func_name}，目前支持的函数列表：{self._sdk.__all__}"
            logger.error(msg)
            return msg
        except Exception as ee:
            error_msg = f"调用{func_name}错误, 聚宽接口报错，{ee}！"
            logger.error(error_msg)
            return error_msg


def jq_client():
    if not hasattr(jq_client, "client"):
        if "JQDATA_USERNAME" not in os.environ or "JQDATA_PASSWORD" not in os.environ:
            logger.warning("请在环境变量中设置JQDATA_USERNAME和JQDATA_PASSWORD，对应聚宽api的用户名和密码")
            return
        else:
            jq_client.client = JQWorker(
                os.environ["JQDATA_USERNAME"], os.environ["JQDATA_PASSWORD"]
            )
            jq_client.client.start()
    return jq_client.client


def run_jq_api(*args) -> List:
    return jq_client().raw_api(*args[0])
