from typing import List, Optional
import pandas as pd

from .base import BaseMixin


class SymbolsMixin(BaseMixin):
    def get_symbols(
        self,
        target_date: str = None,
    ) -> pd.DataFrame:
        script = """
        select trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol, list_date, end_date
        from loadTable("dfs://cn_zvt", `stock)
        where exchange in `sh`sz
        """
        df = self._run_query(script)
        df["end_date"] = pd.to_datetime(
            df["end_date"].fillna(pd.to_datetime("2200-12-31"))
        )

        if target_date:
            target_date = pd.to_datetime(target_date)
            df = df[(df["list_date"] <= target_date) & (df["end_date"] >= target_date)]

        return df

    def get_symbols_active_on_date(self, df, target_date):
        """
        在给定的日期返回所有活跃的symbol

        :param df: DataFrame 包含 'list_date', 'end_date' 和 'symbol' 列
        :param target_date: 需要查询的日期, 格式为 'YYYY-MM-DD'
        :return: 该日期内活跃的symbol列表
        """
        target_date = pd.to_datetime(target_date)
        is_active_mask = (df["list_date"] <= target_date) & (
            df["end_date"] >= target_date
        )
        return df.loc[is_active_mask, "symbol"].tolist()

    def get_suspend_info_for_period(
        self, start_date: str = None, end_date: str = None, symbols: List[str] = None
    ):
        # 转换日期格式
        start_date = self.convert_to_db_date_format(start_date)
        end_date = self.convert_to_db_date_format(end_date)

        # 构建查询条件
        base_condition = f"timestamp between {start_date} and {end_date} "
        # 添加股票代码条件
        symbols_condition = ""
        if symbols:
            symbols_str = self.convert_to_db_symbols(symbols)
            symbols_condition = f" and symbol in {symbols_str}"

        script = f"""
        select timestamp,trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol,paused
        from loadTable('dfs://cn_zvt', `stock_1d_list)
        where {base_condition}{symbols_condition}
        context by entity_id
        """
        # 执行查询，获取停牌数据
        df = self._run_query(script)
        return df

    def get_symbol_name(
        self, start_date: str, end_date: str, symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        # 转换日期格式
        start_date = self.convert_to_db_date_format(start_date)
        end_date = self.convert_to_db_date_format(end_date)

        if symbols:
            symbols = [i[2:] for i in list(set(symbols))]
            symbols_str = self.convert_to_db_symbols(symbols)
            symbols_condition = f" and code in {symbols_str}"
        else:
            symbols_condition = ""
        script = f"""
        select trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol, new_name, change_date
        from loadTable("dfs://cn_zvt", `stock_name_change)
        where  exchange in `sh`sz and change_date <= {end_date}{symbols_condition}
        """
        df = self._run_query(script)
        if df.empty:
            return pd.DataFrame(columns=["timestamp", "symbol", "证券名称"])
        df.rename(columns={"new_name": "证券名称"}, inplace=True)
        # 首先，将日期列转换为datetime类型
        df["change_date"] = pd.to_datetime(df["change_date"])

        market_calen = self._run_query(
            f"getMarketCalendar('SSE', {start_date.split('T')[0]}, {end_date.split('T')[0]})"
        )
        market_df = pd.DataFrame(market_calen, columns=["timestamp"])

        def merge_data(data, market_df):
            return pd.merge_asof(
                market_df,
                data.sort_values("change_date"),
                left_on="timestamp",
                right_on="change_date",
                direction="backward",
            )

        df = df.groupby("symbol").apply(merge_data, market_df=market_df)
        df = df.reset_index(drop=True)
        return df[["timestamp", "symbol", "证券名称"]]

    def get_symbol_industry(
        self, start_date: str, end_date: str, symbols: Optional[List[str]] = None
    ) -> pd.DataFrame:
        # 转换日期格式
        start_date = self.convert_to_db_date_format(start_date)
        end_date = self.convert_to_db_date_format(end_date)

        base_condition = f"timestamp between {start_date} and {end_date} "
        symbols_condition = ""
        if symbols:
            symbols_str = self.convert_to_db_symbols(symbols)
            symbols_condition = f" and symbol in {symbols_str}"

        script = f"""
        select timestamp,symbol,value as 申万行业分类信息
        from loadTable("dfs://vectors_6M", `cn_vectors_1D)
        where factor_name = `申万行业分类信息 and {base_condition}{symbols_condition}
        """
        df = self._run_query(script)
        return df
