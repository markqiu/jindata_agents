import pandas as pd
from typing import Optional
from ..ddb_client import create_session_from_env, create_session
from .base import BaseMixin
from .factors import FactorsMixin
from .finance import FinanceMixin
from .symbols import SymbolsMixin
from .tdate import initialize_map, next_tdate


class JinDataQuantReader(SymbolsMixin, FactorsMixin, FinanceMixin, BaseMixin):
    def __init__(
            self,
            host: Optional[str] = None,
            port: Optional[int] = None,
            username: Optional[str] = None,
            password: Optional[str] = None,
    ):
        super().__init__()
        if any([host, port, username, password]):
            self.client = create_session(host, port, username, password)
        else:
            self.client = create_session_from_env()
        # 初始化因子缓存
        self.factors_cache = {}

    def _run_query(self, script):
        try:
            return self.client.run(script)
        except Exception as e:
            print(f"发生错误：{e}")
            return None

    def get_script_data(self, script):
        return self._run_query(script)

    def get_market_calendar(self, start_date: str = None, end_date: str = None):
        """获取交易日历
        Args:

        """
        start_date = (
            self.convert_to_db_date_format(start_date).split("T")[0]
            if start_date
            else None
        )
        end_date = (
            self.convert_to_db_date_format(end_date).split("T")[0] if end_date else None
        )

        if start_date and end_date:
            return self._run_query(
                f"getMarketCalendar('SSE', {start_date}, {end_date})"
            )
        elif start_date:
            return self._run_query(f"getMarketCalendar('SSE', {start_date})")
        elif end_date:
            return self._run_query(f"getMarketCalendar('SSE', ,{end_date})")
        else:
            return self._run_query("getMarketCalendar('SSE')")

    def get_adjacent_trade_day(self, observe_date: str, interval: int) -> pd.Timestamp:
        """获取观察点最近的交易日，当interval=0时，返回上一个最近的交易日
        Args:
            observe_date: 观察点
            interval: 间隔，正值代表向前查找，负值代表向后查找。
        """
        observe_date = pd.to_datetime(observe_date)
        if interval == 0:
            trading_days = self.get_market_calendar(observe_date, observe_date).astype(str)
            if observe_date.strftime("%Y-%m-%d") not in trading_days:
                interval = -1
        if interval > 0:
            start_date = observe_date
            end_date = observe_date + pd.DateOffset(days=(interval + 30) * 2)
        else:
            start_date = observe_date - pd.DateOffset(days=(abs(interval) + 30) * 2)
            end_date = observe_date
        trading_days = self.get_market_calendar(start_date, end_date).astype(str)
        initialize_map(trading_days)
        observe_date = pd.to_datetime(
            next_tdate(observe_date.strftime("%Y-%m-%d"), interval)
        )
        return observe_date
