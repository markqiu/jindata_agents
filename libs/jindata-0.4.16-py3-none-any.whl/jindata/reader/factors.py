from typing import List, Optional
import numpy as np
import pandas as pd

from .base import BaseMixin


class FactorsMixin(BaseMixin):
    def get_factors(
        self,
        source: str,
        frequency: str,
        factor_names: List[str],
        start_date: str,
        end_date: str,
        symbols: Optional[List[str]] = None,
        calculation_script: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        获取因子数据。

        Args:
            source (str): 数据源，可以是 '6M' 或 '6Y'。
            frequency (str): 数据的频率，'6M' 对应于 '1D' 或 '1M'，而 '6Y' 对应于 '1Q' 或 '1Y'。
            factor_names (List[str]): 需要查询的因子名称列表。
            start_date (str): 查询开始日期，格式为 'YYYY-MM-DD'。
            end_date (str): 查询结束日期，格式为 'YYYY-MM-DD'。
            symbols (Optional[List[str]]): 需要查询的股票代码列表，如果为 None 则查询所有股票。

        Returns:
            pd.DataFrame: 包含查询结果的 DataFrame。

        Raises:
            ValueError: 如果 source 或 frequency 参数的值无效。
        """
        # 验证输入
        if source not in ["6M", "1Y"]:
            raise ValueError("Source must be '6M' or '1Y'")

        # 选择数据表
        factors_table_mapping = {
            "6M": {"1D": "cn_factors_1D", "1M": "cn_factors_1M"},
            "1Y": {"1Q": "cn_factors_1Q", "1Y": "cn_factors_1Y"},
        }
        if frequency not in factors_table_mapping[source]:
            raise ValueError(
                f"Unsupported frequency '{frequency}' for source '{source}'"
            )
        factors_table = factors_table_mapping[source][frequency]

        # 将每个因子名放入单引号中，并使用逗号分隔它们
        formatted_factors = ",".join([f"'{name}'" for name in factor_names])

        # 转换日期格式
        start_date = self.convert_to_db_date_format(start_date)
        end_date = self.convert_to_db_date_format(end_date)

        # 构建查询条件
        base_condition = (
            f"timestamp between {start_date} and {end_date} "
            f"and factor_name in ({formatted_factors})"
        )
        # 添加股票代码条件
        symbols_condition = ""
        if symbols:
            symbols_str = self.convert_to_db_symbols(symbols)
            symbols_condition = f" and symbol in {symbols_str}"

        query_script = f"""
        factor_df = select timestamp, symbol, factor_name ,value from loadTable("dfs://factors_{source}", `{factors_table})
        where {base_condition}{symbols_condition}

        factor_df = select value from  factor_df pivot by timestamp, symbol, factor_name
        factor_df
        """

        if calculation_script:
            formatted_factors = ",".join([f"{name}" for name in factor_names])
            query_script += f"""
            result = select timestamp, symbol, {formatted_factors}{calculation_script}
            from factor_df context by symbol
            result
            """
        # 执行查询
        result = self._run_query(query_script)
        # 如果结果为空，则返回一个空的DataFrame
        if result.empty:
            return pd.DataFrame(columns=factor_names)

        # 确保所有请求的factor_names都在列中
        for col in factor_names:
            if col not in result.columns:
                result[col] = np.nan

        if symbols:
            # 创建一个新的DataFrame，其中包括所有的股票代码和日期
            all_dates = result.timestamp.unique()
            df_all = pd.DataFrame(
                [(date, symbol) for date in all_dates for symbol in list(set(symbols))],
                columns=["timestamp", "symbol"],
            )
            result = pd.merge(df_all, result, on=["timestamp", "symbol"], how="left")
        return result
