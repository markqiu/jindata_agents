from typing import List

import pandas as pd


class BaseMixin:
    def __init__(self):
        # 占位定义，实际的值将在JinDataQuantReader中定义
        self.client = None

    def _run_query(self, script):
        try:
            return self.client.run(script)
        except Exception as e:
            print(f"发生错误：{e}")
            return None

    def convert_to_db_symbols(self, symbols: List[str]) -> str:
        unique_symbols = list(set(symbols))
        return "".join([f"`{s}" for s in unique_symbols])

    def convert_to_db_date_format(self, date_str: str) -> str:
        """将日期字符串转换为 DolphinDB 日期格式。"""
        return pd.to_datetime(date_str).strftime("%Y.%m.%dT%H:%M:%S")
