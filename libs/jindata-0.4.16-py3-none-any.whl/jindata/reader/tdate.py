import datetime
import pandas as pd

_map = {}
PREV, NEXT, KEY, RESULT = 0, 1, 2, 3
_root = [None, None, None, None]
_root[:] = [_root, _root, None, None]


def date_to_timestamp(date):
    if isinstance(date, (datetime.date, datetime.datetime)):
        return date.strftime("%Y-%m-%d")
    else:
        return pd.to_datetime(date).strftime("%Y-%m-%d")


def to_date_string(date_str):
    return pd.to_datetime(date_str).strftime("%Y-%m-%d")


def next_tdate(date=None, _next: int = 1, return_same=True):
    if date is None:
        date_str = to_date_string(datetime.datetime.today().date())
    elif not isinstance(date, str):
        date_str = to_date_string(date)
    else:
        date_str = date

    node = _map.get(date_str, _root)

    while _next != 0:
        node = node[NEXT if _next > 0 else PREV]
        if node[KEY] == date_str:
            raise Exception("错误：到达循环链表的起始点")
        if node[RESULT] == 1:
            _next += 1 if _next < 0 else -1

    if (_next > 0 and node[KEY] < date_str) or (_next < 0 and node[KEY] > date_str):
        raise Exception("错误：找不到有效的交易日")

    return node[KEY] if not return_same or date is None else to_date_string(node[KEY])


def initialize_map(trading_days):
    global _root, _map
    last_node = _root

    for day in trading_days:
        # 创建新节点
        new_node = [last_node, None, day, 1]  # 假设结果值始终为1
        # 更新上一个节点的NEXT指向新节点
        last_node[NEXT] = new_node
        # 更新_map
        _map[day] = new_node
        # 更新最后一个节点
        last_node = new_node

    # 完成循环，将最后一个节点的NEXT指向_root，_root的PREV指向最后一个节点
    last_node[NEXT] = _root
    _root[PREV] = last_node
