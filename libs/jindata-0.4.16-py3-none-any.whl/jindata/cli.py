import importlib
import re
from typing import List

import numpy as np
import pandas as pd
import typer
import os
import platform
from loguru import logger

from .ddb_client import create_session_from_env
from .feishu import (
    get_sheet_values,
    get_all_data_sheet_info,
    update_metadata_sheet,
    Job,
    check_jobs,
    SHEET_TOKEN,
)
from . import VERSION
from .reader2 import cli as reader2_cli


app = typer.Typer()
app.add_typer(reader2_cli.app, name="reader2", help="管理 api的命令")


if platform.system().lower() == "windows":
    OSTYPE = "windows"
elif platform.system().lower() == "linux":
    OSTYPE = "linux"
elif platform.system().lower() == "darwin":
    OSTYPE = "macos"


@app.command()
def version():
    """
    显示版本号
    """
    print(VERSION)


@app.command()
def build():
    """
    编译打包
    """
    print("开始编译打包jindata，将在dist目录保存...")
    build_module = importlib.import_module("build")
    if not build_module:
        print("先安装build模块...")
        os.system("pip install build")
    import subprocess

    current_version_in_pyproject = subprocess.getoutput("poetry version -s")
    from jindata.__version__ import VERSION

    if current_version_in_pyproject != VERSION:
        os.system(f"poetry version {VERSION}")
    print("开始编译打包...")
    os.system("poetry build")


@app.command()
def test(name: str = "."):
    """
    运行pytest
    """
    print("开始运行pytest...")
    os.system(f"pytest {name}")


@app.command()
def update(name: str = "test"):
    """
    更新环境
    """
    print(f"开始安装环境{name}...")
    if OSTYPE == "windows":
        os.system(f"pip install -U -e .[{name}]")
    else:
        os.system(f"pip install -U -e '.[{name}]'")


@app.command()
def start_provider_server(name: str = "jq", port: int = 5559):
    """
    启动某数据源的转发服务
    """
    print(f"开始启动{name}...")
    from .provider.server import JEncoder
    from zero import ZeroServer

    if name == "jq":
        from .provider.jq.worker import run_jq_api

        server = ZeroServer(port=port, encoder=JEncoder)
        server.register_rpc(run_jq_api)
        server.run(2)
    elif name == "em":
        from .provider.em.worker import run_em_api

        server = ZeroServer(port=port, encoder=JEncoder)
        server.register_rpc(run_em_api)
        server.run(2)


@app.command()
def init_db(
    table_type: str = None,
    drop: bool = False,
):
    """
    初始化数据库，建表
    table_type: 表的类型，缺省为None，表示建所有的类型，如果设置了，则之建某一个类型。可以的类型为：factor, macro, finance, event。
    drop: 是否删除数据库，缺省为否
    """
    if table_type and table_type not in (
        "factor",
        "macro",
        "finance",
        "event",
    ):
        logger.error("table_type参数错误！")
        return

    ddb_session = create_session_from_env()
    logger.debug("连接ddb服务器成功！")
    table_info = get_all_data_sheet_info()
    for table in table_info:
        factor_names = []
        for (
            _,
            sheet_id,
            _,
            _,
            _old_db,
            _old_table,
            _new_db,
            _range_str,
            _,
            _,
        ) in table_info[table]:
            data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            # 一个table下面所有sheet内的factor都要建立分区
            factor_names.extend(df["指标名称"].drop_duplicates(keep="first").to_list())
        factor_names = list(set(factor_names))
        for (
            sheet_name,
            sheet_id,
            table_type,
            market_name,
            _old_db,
            _old_table,
            _new_db,
            _range_str,
            freq,
            is_vector,
        ) in table_info[table]:
            # 创建基础db
            if table_type == "factor" or table_type == "macro":
                # 创建因子db
                logger.info(
                    f"开始创建因子数据库和表: sheet_name={sheet_name}，sheet_id={sheet_id}，频率={freq}，是否向量={is_vector}..."
                )
                ddb_session.create_factor_db_table(
                    market_name,
                    table_type=table_type,
                    factor_names=factor_names,
                    freq=freq,
                    is_vector=is_vector,
                    drop=drop,
                )
                logger.info(
                    f"sheet_name={sheet_name}，sheet_id={sheet_id}, 频率={freq}, 是否向量={is_vector} 创建因子数据库和表成功！"
                )
            if table_type == "finance":
                # 创建财务表
                ddb_session.create_factor_db_table(
                    market_name,
                    table_type=table_type,
                    factor_names=factor_names,
                    freq=freq,
                    other_datetime_col_names=["报告期"],
                    other_datetime_col_types=["DATETIME"],
                    is_vector=is_vector,
                    drop=drop,
                )
                logger.info(
                    f"sheet_name={sheet_name}，sheet_id={sheet_id}, 频率={freq}, 是否向量={is_vector} 创建因子数据库和表成功！"
                )

            if table_type == "event":
                # 创建事件表
                raise NotImplementedError("暂未实现！")


@app.command()
def import_factors(start_year: int, end_year: int, sheet_ids: List[str] = None):
    """导入factor表的历史数据"""
    ddb_session = create_session_from_env()
    # 解析元数据表并逐表导入数据
    table_info = get_all_data_sheet_info()
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            table_type,
            _market_name,
            old_db,
            _old_table,
            new_db,
            _range_str,
            _freq,
            is_vector,
        ) in table_info[table]:
            # 基础表或者不在sheet_ids列表中的sheet不处理
            if (
                sheet_id is None
                or table_type == "macro"
                or (sheet_ids and sheet_id not in sheet_ids)
            ):
                continue

            data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df = df[df["数据源"].str.startswith("zvt.")]
            if df.empty:
                continue
            df_split = df["数据源"].str.split(pat=".", n=2)
            _, df["源数据表"], df["源指标名"] = (
                df_split.str[0],
                df_split.str[1],
                df_split.str[2],
            )
            zvt_import_info = {}
            for source_table, source_field, as_name in zip(
                df["源数据表"].tolist(),
                df["源指标名"].tolist(),
                df["指标名称"].tolist(),
                strict=True,
            ):
                source_table = re.sub(r"(?<!^)(?=[A-Z15])", "_", source_table).lower()
                source_table = source_table.replace("5_", "5")
                if source_table not in zvt_import_info:
                    zvt_import_info[source_table] = [
                        [" as ".join([source_field, as_name])],
                        [as_name],
                    ]
                else:
                    zvt_import_info[source_table][0].append(
                        " as ".join([source_field, as_name])
                    )
                    zvt_import_info[source_table][1].append(as_name)
            ddb_session.add_value_partitions(new_db, df["指标名称"].tolist())
            # 导入所有的表
            for table in zvt_import_info:
                logger.info(f"开始导入表{table}：{zvt_import_info[table][1]}...")
                ddb_session.import_history_data(
                    start_year,
                    end_year,
                    old_db,
                    table,
                    new_db,
                    sheet_id,
                    sql=f"""unpivot((select timestamp,  {'report_date, ' if table_type == 'finance' else ''}
                        (upper(split(entity_id, "_")[1])+split(entity_id, "_")[2]) as symbol, {", ".join(zvt_import_info[table][0])} from oldTable
                        where timestamp between year0 and year1),
                        `timestamp{'`report_date' if table_type == 'finance' else ''}`symbol, {zvt_import_info[table][1]})"""
                    if not is_vector
                    else f"""select timestamp, (upper(split(entity_id, "_")[1])+split(entity_id, "_")[2]) as symbol,
                    "{zvt_import_info[table][1][0]}" as factor_names, fixedLengthArrayVector(sw_l1,sw_l2,sw_l3) as value
                    from select int(block_code) as block_code from oldTable where block_type in ['sw_l1','sw_l2', 'sw_l3'] and
                        timestamp between year0 and year1 pivot by timestamp,entity_id,block_type""",
                )
                logger.info(f"导入表{table}：{zvt_import_info[table][1]}成功！")


@app.command()
def import_macro_factors(start_year: int, end_year: int, sheet_ids: List[str] = None):
    """导入宏观数据的factor的历史数据"""
    ddb_session = create_session_from_env()
    # 解析元数据表并逐表导入数据
    table_info = get_all_data_sheet_info()
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            table_type,
            _market_name,
            old_db,
            _old_table,
            new_db,
            _range_str,
            _freq,
            _is_vector,
        ) in table_info[table]:
            # 基础表或者不在sheet_ids列表中的sheet不处理
            if (
                sheet_id is None
                or table_type != "macro"
                or (sheet_ids and sheet_id not in sheet_ids)
            ):
                continue

            data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df = df[df["数据源"].str.startswith("zvt.")]
            if df.empty:
                continue
            df_split = df["数据源"].str.split(pat=".", n=2)
            _, df["源数据表"], df["源指标名"] = (
                df_split.str[0],
                df_split.str[1],
                df_split.str[2],
            )
            zvt_import_info = {}
            for source_table, source_factor_name, _as_name in zip(
                df["源数据表"].tolist(),
                df["源指标名"].tolist(),
                df["指标名称"].tolist(),
                strict=True,
            ):
                source_table = re.sub(r"(?<!^)(?=[A-Z15])", "_", source_table).lower()
                source_table = source_table.replace("5_", "5")
                if source_table not in zvt_import_info:
                    zvt_import_info[source_table] = [source_factor_name]
                else:
                    zvt_import_info[source_table].append(source_factor_name)
            ddb_session.add_value_partitions(new_db, df["指标名称"].tolist())
            # 注册所有的表
            for table in zvt_import_info:
                logger.info(f"开始导入表{table}：{zvt_import_info[table]}...")
                ddb_session.import_history_data(
                    start_year,
                    end_year,
                    old_db,
                    table,
                    new_db,
                    sheet_id,
                    sql=f"""select timestamp,  code as symbol, name as factor_name, value from loadTable("{old_db}", "{table}")
                     where code in {zvt_import_info[table]} and timestamp between year0 and year1""",
                )
                logger.info(f"导入表{table}：{zvt_import_info[table]}成功！")


@app.command()
def update_factors(start_datetime: str = None, sheet_ids: List[str] = None):
    """
    通过自身的timestamp和cn_zvt中的timestamp做对比，找出需要更新的日期区间，然后更新数据。

    Parameters:
        start_datetime: 开始时间，如果不送，则自动取当天往前1个月
    """
    ddb_session = create_session_from_env()
    # 解析元数据表并逐表导入数据
    table_info = get_all_data_sheet_info()
    jobs = []
    metadata_dfs = {}
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            table_type,
            _market_name,
            old_db,
            _old_table,
            new_db,
            _range_str,
            _freq,
            is_vector,
        ) in table_info[table]:
            # 基础表或者不在sheet_ids列表中的sheet不处理
            if (
                sheet_id is None
                or table_type == "macro"
                or (sheet_ids and sheet_id not in sheet_ids)
            ):
                continue
            logger.info(f"开始更新表{_sheet_name}...")
            data = get_sheet_values(SHEET_TOKEN, sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df.index = df.index + 2
            df = df[df["数据源"].str.startswith("zvt.")]
            if df.empty:
                continue
            df_split = df["数据源"].str.split(pat=".", n=2)
            _, df["源数据表"], df["源指标名"] = (
                df_split.str[0],
                df_split.str[1],
                df_split.str[2],
            )
            zvt_import_info = {}
            for source_table, source_field, as_name in zip(
                df["源数据表"].tolist(),
                df["源指标名"].tolist(),
                df["指标名称"].tolist(),
                strict=True,
            ):
                source_table = re.sub(r"(?<!^)(?=[A-Z15])", "_", source_table).lower()
                source_table = source_table.replace("5_", "5")
                if source_table not in zvt_import_info:
                    zvt_import_info[source_table] = [
                        [" as ".join([source_field, as_name])],
                        [as_name],
                    ]
                else:
                    zvt_import_info[source_table][0].append(
                        " as ".join([source_field, as_name])
                    )
                    zvt_import_info[source_table][1].append(as_name)
            ddb_session.add_value_partitions(new_db, df["指标名称"].tolist())

            metadata_dfs[sheet_id] = df
            # 导入sheet中定义的所有的表
            for table in zvt_import_info:
                job_id = ddb_session.update_data(
                    start_datetime,
                    old_db,
                    table,
                    new_db,
                    sheet_id,
                    sql=f"""unpivot((select timestamp,  {'report_date, ' if table_type == 'finance' else ''}
                        (upper(split(entity_id, "_")[1])+split(entity_id, "_")[2]) as symbol, {", ".join(zvt_import_info[table][0])} from oldTable
                        where timestamp between year0 and year1),
                        `timestamp{'`report_date' if table_type == 'finance' else ''}`symbol, {zvt_import_info[table][1]})"""
                    if not is_vector
                    else f"""select timestamp, (upper(split(entity_id, "_")[1])+split(entity_id, "_")[2]) as symbol,
                    "{zvt_import_info[table][1][0]}" as factor_names, fixedLengthArrayVector(sw_l1,sw_l2,sw_l3) as value
                    from select int(block_code) as block_code from oldTable where block_type in ['sw_l1','sw_l2', 'sw_l3'] and
                        timestamp between year0 and year1 pivot by timestamp,entity_id,block_type""",
                )
                logger.info(f"更新表{table}：{zvt_import_info[table][1]}成功！")
                jobs.append(
                    Job(
                        job_id,
                        SHEET_TOKEN,
                        sheet_id,
                        zvt_import_info[table][1],
                        _sheet_name,
                    )
                )
    check_jobs(jobs, metadata_dfs, "update_factors")


@app.command()
def update_macro_factors(start_datetime: str = None, sheet_ids: List[str] = None):
    """更新宏观数据至最新

    Parameters:
        start_datetime: 开始时间，如果不送，则自动取当天往前1个月
    """
    ddb_session = create_session_from_env()
    # 解析元数据表并逐表导入数据
    table_info = get_all_data_sheet_info()
    jobs = []
    metadata_dfs = {}
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            table_type,
            _market_name,
            old_db,
            _old_table,
            new_db,
            _range_str,
            _freq,
            _is_vector,
        ) in table_info[table]:
            # 基础表或者不在sheet_ids列表中的sheet不处理
            if (
                sheet_id is None
                or table_type != "macro"
                or (sheet_ids and sheet_id not in sheet_ids)
            ):
                continue
            logger.info(f"开始更新表{_sheet_name}...")
            data = get_sheet_values(SHEET_TOKEN, sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df.index = df.index + 2
            df = df[df["数据源"].str.startswith("zvt.")]
            if df.empty:
                continue
            df_split = df["数据源"].str.split(pat=".", n=2)
            _, df["源数据表"], df["源指标名"] = (
                df_split.str[0],
                df_split.str[1],
                df_split.str[2],
            )
            zvt_import_info = {}
            for source_table, source_factor_name, _as_name in zip(
                df["源数据表"].tolist(),
                df["源指标名"].tolist(),
                df["指标名称"].tolist(),
                strict=True,
            ):
                source_table = re.sub(r"(?<!^)(?=[A-Z15])", "_", source_table).lower()
                source_table = source_table.replace("5_", "5")
                if source_table not in zvt_import_info:
                    zvt_import_info[source_table] = [source_factor_name]
                else:
                    zvt_import_info[source_table].append(source_factor_name)
            ddb_session.add_value_partitions(new_db, df["指标名称"].tolist())
            metadata_dfs[sheet_id] = df
            # 注册所有的表
            for table in zvt_import_info:
                logger.info(f"开始导入表{table}：{zvt_import_info[table]}...")
                job_id = ddb_session.update_data(
                    start_datetime,
                    old_db,
                    table,
                    new_db,
                    sheet_id,
                    sql=f"""select timestamp,  code as symbol, name as factor_name, value from loadTable("{old_db}", "{table}")
                     where code in {zvt_import_info[table]} and timestamp between year0 and year1""",
                )
                sources = [f"zvt.Macroeconomic.{i}" for i in zvt_import_info[table]]
                indicators = df[df["数据源"].isin(sources)]["指标名称"].tolist()
                logger.info(f"更新表{table}：{zvt_import_info[table]}成功！")
                jobs.append(Job(job_id, SHEET_TOKEN, sheet_id, indicators, _sheet_name))
    check_jobs(jobs, metadata_dfs, "update_factors")


@app.command()
def append_factors(
    start_date: str = None,
    end_date: str = None,
    sheet_ids: List[str] = None,
    factor_names: List[str] = None,
):
    """计算factor表的因子
    Parameters:
        start_date: 开始时间，缺省为空为前一个交易日
        end_date： 结束时间，缺省为空，为当天
        factor_names: 指定要计算的因子名称列表
    """
    ddb_session = create_session_from_env()
    start_date = start_date or ddb_session.find_trade_day(interval=-2)
    end_date = end_date or np.datetime64("today")
    logger.info(f"开始处理因子计算，开始时间：{start_date}，结束时间：{end_date}")
    # 解析元数据表并逐表导入数据
    table_info = get_all_data_sheet_info()
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            _table_type,
            _market_name,
            _,
            _,
            new_db,
            _range_str,
            _freq,
            _is_vector,
        ) in table_info[table]:
            # 基础表或者不在sheet_ids列表中的sheet不处理
            if sheet_id is None or (sheet_ids and sheet_id not in sheet_ids):
                continue
            data = get_sheet_values(SHEET_TOKEN, sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df.index = df.index + 2
            df = df[df["数据源"].str.startswith("factor.")]
            if df.empty:
                continue
            df_split = df["数据源"].str.split(pat=".", n=2)
            _, df["文件名"], df["函数名"] = df_split.str[0], df_split.str[1], df_split.str[2]

            for file_name, func_name, factor_name in zip(
                df["文件名"].tolist(), df["函数名"].tolist(), df["指标名称"].tolist(), strict=True
            ):
                if factor_names and factor_name not in factor_names:
                    continue

                calc_func = getattr(
                    importlib.import_module(f"jindata.factors.{file_name}"),
                    func_name,
                )
                logger.info(f"开始计算因子：{factor_name}...")
                data_df = calc_func(start_date, end_date)
                logger.info(f"因子'{factor_name}'计算完成！")
                ddb_session.add_value_partitions(new_db, [factor_name])
                logger.info(f"开始导入因子'{factor_name}'...")
                ddb_session.append_factor(sheet_id, new_db, factor_name, data_df)
                logger.info(f"因子{factor_name}导入成功！")
                update_metadata_sheet(
                    df, SHEET_TOKEN, sheet_id, [factor_name], _sheet_name
                )


if __name__ == "__main__":
    app()
