import pandas as pd
import typer

from ..feishu import get_metadata

app = typer.Typer()


@app.command()
def update_metadata_store():
    """Update the metadata store."""
    print("## Welcome to Metadata Updater")
    print("-------------------------------")
    print("getting new metadata...")
    metadata_df = get_metadata()
    print("saving to data/metadata_store.h5...")
    f = pd.HDFStore(
        "data/metadata_store.h5", mode="w", complevel=5, complib="blosc:blosclz"
    )
    metadata_df.to_hdf(f, key="metadata")
    f.close()
    print("...done!")
