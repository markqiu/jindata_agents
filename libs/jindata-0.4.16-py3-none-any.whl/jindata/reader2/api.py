from typing import List

import pandas as pd

from ..ddb_client import DolphindbSession
from ..recorder.schema import gen_factor_table_name, gen_factor_db_name


def str_list_to_ddb_str(a_str_list: List[str]) -> str:
    return "`" + "`".join(a_str_list)


def str_to_ddb_timestamp(date_str: str, format: str = "%Y.%m.%dT%H:%M:%S") -> str:
    """将日期字符串转换为 DolphinDB 日期格式。"""
    return pd.to_datetime(date_str).strftime(format)


class JinDataQuantReader(DolphindbSession):
    """
    本接口是为自然语言处理查询做准备，因此主要提供以下标准化的查询：
    1. 通过数据名称查询所属实体名称、频率、单位等元数据信息
    2. 查询指定时间段内的股票行业信息
    3. 查询指定时间段内的因子数据，包括股票、经济数据等
    4. 查询指定时间段内的经济数据，如GDP、CPI等
    5. 查询指定时间段内的财务数据因子，如财务报表、利润表等
    """

    def __init__(
        self,
        host: str = None,
        port: int = None,
        user: str = None,
        password: str = None,
        startup: str = None,
    ):
        super().__init__(host, port, user, password, startup)

    @staticmethod
    def query_metadata_by_data_name(
        data_name: str, entity_name: str = None, is_like: bool = False
    ) -> list[tuple[str, str, str, str]]:
        """通过数据名称和所属实体名称查询数据的频率和单位信息
        注意：打开模糊查询开关时，可以通过这个接口猜测有哪些数据名和查询的数据名比较相近。
        注意：确保已经在后台执行了 `j reader2 update-metadata-store` 命令，否则可能会查询不到数据。

        Args:
            data_name (str): 数据名称
            entity_name (str, optional): 所属实体名称，默认为空，表示查询所有实体
            is_like (bool, optional): 是否使用模糊查询，默认为False。如果开启模糊查询，则对 data_name采取模糊查询的方式进行搜索，以便查出所有匹配的数据。
        TODO:
            目前未支持市场名称的查询，后续可以考虑增加市场名称的查询条件
        Returns:
            查询结果为[('数据名称', '所属实体名称, '频率', '单位')]，包含指定数据名称的元数据信息列表（有可能命中不同实体或不同频率的多条信息）
        """
        metadata_df = pd.read_hdf("data/metadata_store.h5", key="metadata")
        if entity_name:
            result = metadata_df.query(
                "数据名称 == @data_name and 所属实体名称 == @entity_name"
            )
        else:
            result = metadata_df.query(
                "数据名称 == @data_name"
                if not is_like
                else "数据名称.str.contains(@data_name)"
            )

        # 替换频率的中文为接口标准名称
        result.loc[result["频率"] == "日", "频率"] = "1D"
        result.loc[result["频率"] == "月", "频率"] = "1M"
        result.loc[result["频率"] == "季", "频率"] = "1Q"
        result.loc[result["频率"] == "半年", "频率"] = "6M"
        result.loc[result["频率"] == "年", "频率"] = "1Y"
        return result.values.tolist()

    def query_symbol_industry(
        self,
        symbols: list[str],
        start_date: str,
        end_date: str,
        market_name: str = "cn",
    ) -> pd.DataFrame:
        """
        查询指定时间段内的股票行业信息

        参数:
        symbols: 要查询的股票代码列表，类型为字符串列表
        start_date: 查询的起始日期，格式为字符串
        end_date: 查询的结束日期，格式为字符串
        market_name: 市场名称，默认为'cn'表示中国市场，类型为字符串

        返回值:
        返回一个 Pandas DataFrame，包含指定股票在指定时间范围内的行业信息
        """

        # 转换日期格式为数据库所需的格式
        start_date = str_to_ddb_timestamp(start_date)
        end_date = str_to_ddb_timestamp(end_date)

        # 构建查询脚本，包括查询条件和数据聚合方式
        query_script = f"""
            select value from loadTable("{gen_factor_db_name('factor', '1D', True)[1]}",
            `{gen_factor_table_name(market_name, '', '1D', True)})
            where timestamp between {start_date} and {end_date} {'and symbol in ' + str_list_to_ddb_str(symbols) if symbols else ''}
            pivot by timestamp, symbol, factor_name
        """

        # 执行查询并获取结果
        result = self.run(query_script)

        # 如果查询结果为空，返回一个空的 DataFrame
        if result.empty:
            return pd.DataFrame(columns="申万行业分类信息")

        return result

    def query_symbol_factors(
        self,
        symbols: list[str],
        start_date,
        end_date,
        frequency,
        factors: list[str] = None,
        market_name: str = "cn",
    ):
        """查询指定时间段内的因子数据，包括股票、经济数据等。
        注意：查询经济数据类的因子，建议采用 query_economic_factors 接口。

        Args:
            symbols (list[str]): 股票代码列表
            start_date: 查询开始日期
            end_date: 查询结束日期
            frequency: 查询频率
            factors (list[str], optional): 需要查询的因子列表，默认为None
            market_name (str, optional): 市场编码，默认为'cn'

        Returns:
            pandas.DataFrame: 查询结果的DataFrame，包含指定时间段内的股票行业信息
        """

        # 转换日期格式
        start_date = str_to_ddb_timestamp(start_date)
        end_date = str_to_ddb_timestamp(end_date)

        # 构建查询条件
        query_script = f"""
            select value from loadTable("{gen_factor_db_name('factor', frequency, False)[1]}",
             `{gen_factor_table_name(market_name, '', frequency, False)})
            where timestamp between {start_date} and {end_date} {'and symbol in ' + str_list_to_ddb_str(symbols) if symbols else ''}
            and factor_name in {str_list_to_ddb_str(factors)}
            pivot by timestamp, symbol, factor_name
        """

        # 执行查询
        result = self.run(query_script)
        # 如果结果为空，则返回一个空的DataFrame
        if result.empty:
            return pd.DataFrame(columns=factors)

        return result

    def query_economic_factors(
        self,
        symbols: list[str],
        start_date: str,
        end_date: str,
        frequency: str,
        market_name: str = "cn",
    ):
        """查询指定时间段内的经济数据，如GDP、CPI等。
        注意：通过 query_symbol_factors其实也可以查，但是相比本接口只查经济数据，使用更复杂。

        Args:
            symbols (list[str]): 经济指标代码列表
            start_date: 查询开始日期
            end_date: 查询结束日期
            frequency: 查询频率, 如'1Q', '1Y'。注意财务数据没有‘1D’的频率。
            market_name (str, optional): 市场编码，默认为'cn'
        Returns:
            pandas.DataFrame: 查询结果的DataFrame，包含指定时间段内的经济数据
        """
        # 转换日期格式
        start_date = str_to_ddb_timestamp(start_date)
        end_date = str_to_ddb_timestamp(end_date)

        # 构建查询条件
        query_script = f"""
            select value from loadTable("{gen_factor_db_name('factor', frequency, False)[1]}",
             `{gen_factor_table_name(market_name, '', frequency, False)})
            where timestamp between {start_date} and {end_date} {'and symbol in ' + str_list_to_ddb_str(symbols) if symbols else ''}
            pivot by timestamp, symbol, factor_name
        """

        # 执行查询
        result = self.run(query_script)
        return result

    def query_symbol_finance_factors(
        self,
        symbols: list[str],
        start_date: str,
        end_date: str,
        frequency: str,
        factors: list[str] = None,
        market_name: str = "cn",
    ):
        """查询指定时间段内的财务数据因子，如财务报表、利润表等。

        Args:
            symbols (list[str]): 股票代码列表
            start_date: 查询开始日期
            end_date: 查询结束日期
            frequency: 查询频率, 如'1Q', '1Y'。注意财务数据没有‘1D’的频率。
            factors (list[str], optional): 需要查询的因子列表，默认为None
            market_name (str, optional): 市场编码，默认为'cn'

        Returns:
            pandas.DataFrame: 查询结果的DataFrame，包含指定时间段内的财务数据
        """
        assert frequency in ["1Q", "1Y"], "财务数据的频率只能是'1Q'或'1Y'"

        # 转换日期格式
        start_date = str_to_ddb_timestamp(start_date)
        end_date = str_to_ddb_timestamp(end_date)

        # 构建查询条件
        query_script = f"""
            select value from loadTable("{gen_factor_db_name('finance', frequency, False)[1]}",
             `{gen_factor_table_name(market_name, 'finance', frequency, False)})
            where timestamp between {start_date} and {end_date} {'and symbol in ' + str_list_to_ddb_str(symbols) if symbols else ''}
            and factor_name in {str_list_to_ddb_str(factors)}
            pivot by timestamp, symbol, factor_name
        """

        # 执行查询
        result = self.run(query_script)
        return result

    def query(
        self,
        symbols: list[str],
        data_names: list[str],
        start: str = None,
        end: str = None,
    ) -> list[pd.DataFrame]:
        """
        执行查询数据的函数。
        处理逻辑：
            1. 将所有的数据名称调用query_metadata_by_data_name接口获取所属实体名称、频率、单位信息。
            2. 将data_names按照所属实体名称、频率进行分组。
            3. 对每一分组分别不同接口查询数据。
            4. 返回查询的分组结果信息以及查询结果列表。
        参数:
            symbols - 要查询的证券符号列表。
            data_names - 需要查询的数据列表。
            start - 查询的起始日期，默认为None。
            end - 查询的结束日期，默认为None。

        返回值:
        查询结果，具体类型取决于实现。

        NLP查询数据的思考：
        大致分为这几种类型的查询：
            1. 证券名称+某时间+因子名称查询
                这里的某时间是指一个比较含糊的时间，是一个时间点或者一个时间段，比如“3年前”、“2012年”等。
                比如，我想查询茅台的3年前的市值、市盈率、市净率等因子数据，或我想查询我们国家2012年的GDP。
            2. 证券名称+明确起始时间+数据名称查询
                比如，我想查询茅台的历史市值、市盈率、市净率等数据。我想查询我们国家的GDP的历史数据。
            3. 数据名称+某时间的查询
                比如，我想查询2012年的GDP
            4. 数据名称+明确起始时间的查询
                比如，我想查询2012 年到 2015 年GDP的历史数据
            5. 复合查询
                比如，我想查询白酒行业的所有上市公司的市值，并且按照年求和
        处理逻辑：
            1. 尝试抽取出证券名称（可多个）、数据名称（可多个）、开始时间、结束时间。如果无法抽取出某个参数，就用空值代替。
            2. 通常人们只说证券名称而且往往是简称而不是证券全称，因此，要根据证券简称找出证券全称和对应的证券代码，将证券代码列表保存到symbols变量中。
            3. 将抽取出的证券名称和代码给人确认，如果有错误，就让用户重新输入。
            4. 通常人们提及数据名称时往往用简称、别名等，所以需要调用query_metadata_by_data_name接口获取所有相关数据的数据名称、所属实体名称、频率、单位等信息，让人确认并替换抽取时产生的空值。
            5. 人们也常常不明确的说出开始时间和结束时间，而是含糊的说最近几年，几年前，需要将这些时间按照经验转换为具体的时间段。
            6. 按照所属实体名称、频率和开始时间和结束时间的不同对上面的信息进行分组，然后询问用户这些分组的正确性以及哪些是用户真正想要的分组。
            7. 根据用户确认的结果，调用一次query接口查询数据并返回。
        例子：
            例1（未完成，让我再想想）：
                问题：我想查询茅台的3年前的市值、市盈率、市净率等因子数据。
                推理过程：先确定茅台的证券代码为 SH600519，然后调用query_metadata_by_data_name('市值')，
                query_metadata_by_data_name('市值')得到市值的实体名称为A股股票，频率为1D，单位为元。
                答案：实体名称：A股股票
        """
        pass
