import os

import dolphindb as ddb
import time
import asyncio
import threading
import dolphindb.settings as keys

from loguru import logger

from .utils import SingletonClass


class DolphindbClientASync(SingletonClass):
    """异步的dolphindb客户端，支持连接池，必须采用异步调用的方式。例子见下面的main函数

    Returns:
        _type_: _description_
    """

    _pool: ddb.DBConnectionPool = None

    def __new__(cls, *args, **kwargs):
        super(SingletonClass, cls).__new__(cls, *args, **kwargs)
        cls._pool = ddb.DBConnectionPool(
            "localhost", 8902, 20, "admin", "123456", False, False, False, False, False
        )
        return cls

    @classmethod
    async def run(cls, script):
        return await cls._pool.run(script)

    @classmethod
    async def run_task(cls, script):
        task = loop.create_task(cls.run(script))
        result = await asyncio.gather(task)
        return result

    @classmethod
    def start_thread_loop(cls, loop):
        "Run an event loop in a thread"
        asyncio.set_event_loop(loop)
        loop.run_forever()

    @classmethod
    def close(cls):
        cls._pool.shutDown()


class DolphindbSession:
    """通过ddb的连接建立一个同步连接dolphindb的session，然后在一个session内完成一个任务，然后关闭这个session。
        本类是在dolphindb sdk的基础上封装了在一个session下去常用的操作，并在用完以后能够自动回收并清理内存。
    Note:
        例子见下面的main函数
    """

    def __init__(
            self, host: str = None, port: int = None, user: str = None, password: str = None, startup: str = None
    ) -> None:
        """初始化dolphindb客户端和建立起session，所有参数走环境变量，如果没有环境变量，则使用默认值"""
        self._host: str = host or os.environ["DDB_HOST"]
        self._port: int = port or os.environ["DDB_PORT"]
        self._user: str = user or os.environ["DDB_USER"]
        self._password: str = password or os.environ["DDB_PASSWORD"]
        self._s = ddb.session(compress=True, protocol=keys.PROTOCOL_DDB)
        self._s.connect(
            self._host, int(self._port), self._user, self._password, startup=startup, reconnect=True
        )

    def run(self, script, *args, **kwargs):
        return self._s.run(script, *args, **kwargs)

    def close(self):
        self._s.close()

    def __del__(self):
        if hasattr(self, "_s") and self._s is not None:
            self._s.clearAllCache(dfs=True)
            self.close()


def create_session(
        host: str,
        port: int,
        user: str,
        password: str,
        startup: str = "use jinniuai_data",
) -> DolphindbSession:
    """创建一个session"""
    try:
        session = DolphindbSession(host, port, user, password, startup=startup)
    except Exception as e:
        logger.error("创建dolphindb的session失败，请检查dolphindb的参数是否正确")
        raise e
    return session


def create_session_from_env() -> DolphindbSession:
    """从环境变量创建一个session，环境变量包括：
    DDB_HOST: dolphindb的host
    DDB_PORT: dolphindb的端口
    DDB_USER: dolphindb的用户名
    DDB_PASSWORD: dolphindb的密码
    """
    try:
        host = os.environ["DDB_HOST"]
        port = os.environ["DDB_PORT"]
        user = os.environ["DDB_USER"]
        password = os.environ["DDB_PASSWORD"]
    except KeyError:
        logger.error("没有设置dolphindb的参数，请设置DDB_HOST、DDB_PORT、DDB_USER、DDB_PASSWORD环境变量")
        raise KeyError(
            "没有设置dolphindb的参数，请设置DDB_HOST、DDB_PORT、DDB_USER、DDB_PASSWORD环境变量"
        ) from exec
    session = create_session(host, int(port), user, password)
    return session


if __name__ == "__main__":
    asyncclient = DolphindbClientASync()
    start = time.time()
    print("In main thread", threading.current_thread())
    loop = asyncio.get_event_loop()
    # create an event loop and run_forever in subthread

    t = threading.Thread(target=DolphindbClientASync.start_thread_loop, args=(loop,))
    t.start()
    task1 = asyncio.run_coroutine_threadsafe(
        asyncclient.runTask("sleep(1000);1+1"), loop
    )
    task2 = asyncio.run_coroutine_threadsafe(
        asyncclient.runTask("sleep(3000);1+2"), loop
    )
    task3 = asyncio.run_coroutine_threadsafe(
        asyncclient.runTask("sleep(5000);1+3"), loop
    )
    task4 = asyncio.run_coroutine_threadsafe(
        asyncclient.runTask("sleep(1000);1+4"), loop
    )

    print("the main thread is not blocked")
    end = time.time()
    print(f"Used time: {end - start}")
    asyncclient.close()

    start = time.time()
    ddbclient = DolphindbSession("localhost", 8902, "admin", "123456")
    ddbclient.run("sleep(1000);1+1")
    print("the main thread is blocked")
    end = time.time()
    print(f"Used time: {end - start}")
    ddbclient.close()
