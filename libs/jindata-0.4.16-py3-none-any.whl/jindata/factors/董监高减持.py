from datetime import timedelta

import pandas as pd

from ..ddb_client import create_session_from_env
from .utils import (
    get_symbols_script,
    get_symbols_active_on_date,
    get_holder_trading_script,
)


client = create_session_from_env()


def calculate_reduction_percentage(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子：过去一年董监高合计减持比例
    """
    start_date = (pd.to_datetime(start_date) - timedelta(days=365)).strftime(
        "%Y.%m.%dT00:00:00"
    )
    end_date = pd.to_datetime(end_date).strftime("%Y.%m.%dT00:00:00")

    holder_trading_script = get_holder_trading_script(start_date, end_date)
    holder_df = client.run(holder_trading_script)
    if holder_df.empty:
        return pd.DataFrame(columns=["timestamp", "symbol", "factor_name", "value"])

    symbols_script = get_symbols_script()
    stock_symbols = client.run(symbols_script)
    stock_symbols["end_date"].fillna("2099-01-01", inplace=True)

    trade_dates = client.run(
        f"getMarketCalendar('SSE',"
        f" {start_date.split('T')[0]}, "
        f"{end_date.split('T')[0]})"
    )

    all_data = []
    for target_date in pd.to_datetime(trade_dates):
        one_year_ago = target_date - timedelta(days=365)
        symbols = get_symbols_active_on_date(stock_symbols, target_date)
        symbols_set = set(symbols)  # convert list to set for efficient lookup
        df = holder_df[
            holder_df["timestamp"].between(one_year_ago, target_date)
            & holder_df.symbol.isin(symbols_set)  # use set for lookup
        ]
        if not df.empty:
            df_pct = df.groupby("symbol").change_pct.sum()
            extract = pd.DataFrame(df_pct).reset_index()
            extract["timestamp"] = target_date
            all_data.append(extract)

    if all_data:
        data = pd.concat(all_data)
        data = data.rename(columns={"change_pct": "value"})
        data = data[["timestamp", "symbol", "value"]]
        data["factor_name"] = "过去一年董监高合计减持比例"
        data = data.sort_values(by=["timestamp", "symbol"])
    else:
        data = pd.DataFrame(columns=["timestamp", "symbol", "factor_name", "value"])

    return data


if __name__ == "__main__":
    from jindata.factors.utils import timer_decorator

    start_date = "2022-01-01"
    end_date = "2023-07-01"
    calculate_reduction_percentage_optimized = timer_decorator(
        calculate_reduction_percentage
    )
    df = calculate_reduction_percentage_optimized(start_date, end_date)
    assert_df = df[df["symbol"] == "SH600021"]
    assert assert_df.shape[0] == 286
    assert_df.drop_duplicates(subset=["value"], keep="last", inplace=True)
    assert assert_df.shape[0] == 9
