import pandas as pd
from datetime import timedelta

from .utils import rolling_percentile
from ..ddb_client import create_session_from_env

client = create_session_from_env()


def calculate_leading_indicator(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子名称：普林格先行指标
    symbol：JNZD0000002
    所属实体：宏观数据
    频率：月
    """
    # 计算滚动5年同比分位数所需的基础日期
    base_date = pd.to_datetime(start_date) - pd.Timedelta(days=365 * 6)

    start_time = pd.to_datetime(base_date).strftime("%Y.%m.%dT%H:%M:%S")
    end_time = pd.to_datetime(end_date).strftime("%Y.%m.%dT%H:%M:%S")

    factor_names = ["M1", "M2"]
    script = f"""
    select value
    from loadTable("dfs://factors_6M", `cn_factors_1M)
    where factor_name in {factor_names} and
    timestamp between {start_time} and {end_time}
    pivot by timestamp, factor_name;
    """
    df = client.run(script)

    # 对数据进行排序
    df.sort_values(by=["timestamp"], inplace=True)

    # 计算上一年同期的日期
    df["previous_year"] = (df["timestamp"] - timedelta(days=365)).apply(
        lambda x: x.strftime("%Y.%m")
    )
    df["current_period"] = df["timestamp"].apply(lambda x: x.strftime("%Y.%m"))

    # 合并数据，得到上一年同期的M1和M2
    df = pd.merge(
        df,
        df[["current_period", "M1", "M2"]],
        how="left",
        left_on=["previous_year"],
        right_on=["current_period"],
        suffixes=("", "_previous_year"),
    )

    # 计算M1和M2的同比增长率
    df["M1_YoY"] = (df["M1"] / df["M1_previous_year"] - 1) * 100
    df["M2_YoY"] = (df["M2"] / df["M2_previous_year"] - 1) * 100

    df.dropna(subset=["M1_YoY"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    df["M1_YoY_percentile"] = rolling_percentile(df["M1_YoY"], window=5 * 12)
    df["M2_YoY_percentile"] = rolling_percentile(df["M2_YoY"], window=5 * 12)

    # 计算先行指标
    df.eval("value = (M1_YoY_percentile + M2_YoY_percentile) / 2", inplace=True)
    # 选择计算结果在开始和结束日期之间的数据
    df = df[df["timestamp"].between(start_date, end_date)]
    df.dropna(subset=["value"], inplace=True)
    df.reset_index(drop=True, inplace=True)
    df["factor_name"] = "普林格先行指标"
    df["symbol"] = "JNZD0000002"
    df = df[["timestamp", "symbol", "factor_name", "value"]]
    return df


if __name__ == "__main__":
    from jindata.factors.utils import timer_decorator

    start_date = "2021-01-01"
    end_date = "2023-07-17"
    calculate_reduction_percentage_optimized = timer_decorator(
        calculate_leading_indicator
    )
    data = calculate_reduction_percentage_optimized(start_date, end_date)
    print(data.head())
    assert data[data["timestamp"] == "2021-05-01"].value.values[0] - 32.5 <= 0.0001
    # 画图看下效果
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 6))
    plt.plot(data["timestamp"], data["value"], marker="o")
    plt.title("巴菲特估值方法的优化版指标")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid(True)
    plt.show()
