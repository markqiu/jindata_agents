import pandas as pd
import numpy as np

from ..ddb_client import create_session_from_env
from .utils import get_finance_factors_1Q_script

client = create_session_from_env()

COL_ROE = "净资产收益率ROE（扣除比摊薄）（百分比）"
COL_ROE_FIX = "净资产收益率ROE（扣除比摊薄）（百分比）_fix"
COL_OP_YOY = "营业总收入同比增长率（百分比）"
COL_OP_YOY_FIX = "营业总收入同比增长率（百分比）_fix"
"""
"导入期"=0, "成长期"=1, "成熟期"=2, "衰退期"=3
"""


def calculate_enterprise_life_cycle(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子：企业生命周期
    """
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    years = set()
    current_date = start_date
    while current_date <= end_date:
        if current_date.month < 5:
            years.add(current_date.year - 2)
        else:
            years.add(current_date.year - 1)
        # 移动到下一个月
        current_date += pd.DateOffset(months=1)

    # 将集合转换为列表并排序
    years = sorted(years)

    res_list = []
    for year in years:
        report_dates = [f"{year}-12-31"]
        start = f"{year + 1}-01-01"
        end = f"{year + 1}-05-01"

        finance_factors_script = get_finance_factors_1Q_script(
            [COL_ROE, COL_OP_YOY],
            start_date=pd.to_datetime(start).strftime("%Y.%m.%dT00:00:00"),
            end_date=pd.to_datetime(end).strftime("%Y.%m.%dT00:00:00"),
            report_dates=report_dates,
        )
        df = client.run(finance_factors_script)
        df = df.dropna()

        if df.empty:
            continue
        df.fillna(0, inplace=True)

        df[COL_OP_YOY_FIX] = df[COL_OP_YOY].clip(
            lower=df[COL_OP_YOY].quantile(0.20), upper=df[COL_OP_YOY].quantile(0.80)
        )
        df[COL_ROE_FIX] = df[COL_ROE].clip(
            lower=df[COL_ROE].quantile(0.20), upper=df[COL_ROE].quantile(0.80)
        )

        # 计算中位数
        median1 = df[COL_ROE_FIX].median()
        median2 = df[COL_OP_YOY_FIX].median()

        # 四象限划分
        df["企业生命周期"] = np.select(
            [
                (df[COL_ROE] > median1) & (df[COL_OP_YOY] > median2),
                (df[COL_ROE] > median1) & (df[COL_OP_YOY] <= median2),
                (df[COL_ROE] <= median1) & (df[COL_OP_YOY] > median2),
                (df[COL_ROE] <= median1) & (df[COL_OP_YOY] <= median2),
            ],
            [1, 2, 0, 3],
        )

        # 财报全部更新完后计算，取最后一天为计算日期
        df["timestamp"] = df.timestamp.max()
        res_list.append(df)

    data = pd.concat(res_list)
    data = data[["timestamp", "报告期", "symbol", "企业生命周期"]]
    data = data.rename(columns={"企业生命周期": "value"})
    data.reset_index(drop=True, inplace=True)
    data["factor_name"] = "企业生命周期"
    data["value"] = data["value"].astype(float)
    return data


if __name__ == "__main__":
    from jindata.factors.utils import timer_decorator

    start_date = "2022-01-01"
    end_date = "2023-07-01"

    # 在这里应用装饰器
    calculate_reduction_percentage_optimized = timer_decorator(
        calculate_enterprise_life_cycle
    )
    df = calculate_reduction_percentage_optimized(start_date, end_date)
    data = df[df["symbol"] == "SH600519"]
    assert data.shape[0] == 3
