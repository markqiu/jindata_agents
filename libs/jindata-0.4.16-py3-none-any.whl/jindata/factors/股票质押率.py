import pandas as pd

from ..ddb_client import create_session_from_env
from .utils import (
    get_equity_pledge_script,
    get_symbols_script,
    get_symbols_active_on_date,
)


client = create_session_from_env()


def calculate_pledge_ratio(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子：股票质押
    """

    start_datetime = pd.to_datetime(start_date)
    end_datetime = pd.to_datetime(end_date)

    formatted_start_date = start_datetime.strftime("%Y.%m.%dT00:00:00")
    base_date = (start_datetime - pd.DateOffset(years=4)).strftime("%Y.%m.%dT00:00:00")
    formatted_end_date = end_datetime.strftime("%Y.%m.%dT00:00:00")

    equity_script = get_equity_pledge_script(base_date, formatted_end_date)
    equity_df = client.run(equity_script)

    symbols_script = get_symbols_script()
    stock_symbols = client.run(symbols_script)
    stock_symbols["end_date"].fillna("2099-01-01", inplace=True)

    trade_dates = client.run(
        f"getMarketCalendar('SSE',{formatted_start_date.split('T')[0]},"
        f" {formatted_end_date.split('T')[0]})"
    )

    all_data = []

    for target_date in pd.to_datetime(trade_dates):
        symbols = get_symbols_active_on_date(stock_symbols, target_date)
        filtered_equity = equity_df[
            (equity_df.symbol.isin(symbols))
            & (equity_df["start_date"] <= target_date)
            & (equity_df["end_date"] >= target_date)
        ]
        if not filtered_equity.empty:
            filtered_equity.sort_values("timestamp", ascending=True, inplace=True)

            def process_group(data):
                data.drop_duplicates(subset=["pledgor"], keep="last", inplace=True)
                return data["pledge_total_ratio"].sum()

            group_sum_df = (
                filtered_equity.groupby("symbol").apply(process_group).reset_index()
            )

            group_sum_df.columns = ["symbol", "pledge_total_ratio_sum"]
            group_sum_df["timestamp"] = target_date
            all_data.append(group_sum_df)

    if all_data:
        extract_df = pd.concat(all_data)
        extract_df.rename(columns={"pledge_total_ratio_sum": "value"}, inplace=True)
        extract_df["factor_name"] = "股票质押率"
        return extract_df[["timestamp", "symbol", "value", "factor_name"]].sort_values(
            by=["timestamp", "symbol"]
        )
    else:
        raise ValueError(
            "股票质押率 因子计算结果为空，请检查数据，入参为：start_date: {}, end_date: {}".format(
                start_date, end_date
            )
        )


if __name__ == "__main__":
    start_date = "2023-09-11"
    end_date = "2023-09-11"
    df = calculate_pledge_ratio(start_date, end_date)
    assert df.shape[0] == 1154
    assert df[df["symbol"] == "SH600053"].value.values[0] - 36.5360 < 0.1
