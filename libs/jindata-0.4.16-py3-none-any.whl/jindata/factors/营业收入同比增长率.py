from datetime import timedelta

import pandas as pd

from ..ddb_client import create_session_from_env
from .utils import get_finance_factors_1Q_script

client = create_session_from_env()


FACTOR_NAME = "营业收入"
YOY_FACTOR_NAME = "营业收入同比增长率"
SYMBOL = "symbol"
REPORT_DATE = "报告期"
TIMESTAMP = "timestamp"


def calculate_finance_yoy(
    start_date: str, end_date: str, factor_names: str = FACTOR_NAME
) -> pd.DataFrame:
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)
    base_date = start_date - pd.Timedelta(days=365 * 2)  # 计算同比，需要多一年的数据

    finance_factors_script = get_finance_factors_1Q_script(
        [factor_names],
        start_date=base_date.strftime("%Y.%m.%dT00:00:00"),
        end_date=end_date.strftime("%Y.%m.%dT00:00:00"),
    )
    df = client.run(finance_factors_script)
    # 将数据按照 'symbol' 和 '报告期' 排序
    df.sort_values(by=[SYMBOL, REPORT_DATE], inplace=True)
    # 计算上一年同期的日期
    df["上年同期"] = df[REPORT_DATE] - timedelta(days=365)
    # 将数据按照 'symbol' 和 '上年同期' 合并，得到上一年同期的营业收入
    df = pd.merge(
        df,
        df[[SYMBOL, REPORT_DATE, FACTOR_NAME]],
        how="left",
        left_on=[SYMBOL, "上年同期"],
        right_on=[SYMBOL, REPORT_DATE],
        suffixes=("", "_上年同期"),
    )
    # 计算同比增长率
    df[YOY_FACTOR_NAME] = (df[FACTOR_NAME] - df["营业收入_上年同期"]) / df["营业收入_上年同期"] * 100
    df = df[df[TIMESTAMP] >= start_date]
    df = df[[TIMESTAMP, REPORT_DATE, SYMBOL, YOY_FACTOR_NAME]].dropna(
        subset=YOY_FACTOR_NAME
    )
    df.rename(columns={YOY_FACTOR_NAME: "value"}, inplace=True)
    df["factor_name"] = YOY_FACTOR_NAME
    return df


if __name__ == "__main__":
    start_date = "2023-01-01"
    end_date = "2023-06-29"

    import time

    p1 = time.perf_counter()
    df = calculate_finance_yoy(start_date, end_date)
    print(df.head())
    p2 = time.perf_counter()
    print(f"计算{df.shape[0]}条,耗时: {p2 - p1:.2f}s")

    assert df.shape[0] == 10260, "计算结果数量发生变动,请检查"
    cal_num = df[
        (df["symbol"] == "SH600000") & (df["报告期"] == "2022-12-31")
    ].value.values[0]
    assert abs(cal_num + 1.23) < 0.01, "SH600000  报告期 2022-12-31 计算结果发生变动,请检查"
