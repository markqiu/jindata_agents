import pandas as pd

from ..ddb_client import create_session_from_env
from .utils import get_symbols_script

client = create_session_from_env()


def calculate_st_name(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子：是否为ST或退市股票
    """

    start_datetime = pd.to_datetime(start_date)
    end_datetime = pd.to_datetime(end_date)

    formatted_start_date = start_datetime.strftime("%Y.%m.%dT00:00:00")
    formatted_end_date = end_datetime.strftime("%Y.%m.%dT00:00:00")

    script = f"""
    select trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol, new_name, change_date
    from loadTable("dfs://cn_zvt", `stock_name_change)
    where  exchange in `sh`sz and change_date <= {formatted_end_date}
    """
    df = client.run(script)
    df.rename(columns={"new_name": "证券名称"}, inplace=True)
    # 首先，将日期列转换为datetime类型
    df["change_date"] = pd.to_datetime(df["change_date"])

    symbols_script = get_symbols_script()
    stock_symbols = client.run(symbols_script)
    stock_symbols["end_date"].fillna("2099-01-01", inplace=True)

    trade_dates = client.run(
        f"getMarketCalendar('SSE',{formatted_start_date.split('T')[0]},"
        f" {formatted_end_date.split('T')[0]})"
    )
    df["是否为ST或退市股票"] = df["证券名称"].apply(lambda x: 1 if ("ST" in x or "退" in x) else 0)
    df["change_date"] = pd.to_datetime(df["change_date"])
    # 交易日期
    trade_dates_df = pd.DataFrame(trade_dates, columns=["trade_date"])
    df.dropna(subset=["symbol"])
    dfs = []
    for _symbol, group in df.groupby("symbol"):
        merged = pd.merge_asof(
            trade_dates_df,
            group.sort_values("change_date"),
            left_on="trade_date",
            right_on="change_date",
            direction="backward",
        )
        dfs.append(merged)

    df_daily = pd.concat(dfs)
    df_daily = pd.merge(df_daily, stock_symbols, on="symbol", how="left")
    df_daily = df_daily[
        (df_daily["trade_date"] <= df_daily["end_date"])
        & (df_daily["trade_date"] >= df_daily["list_date"])
    ]
    if not df_daily.empty:
        df_daily.rename(
            columns={"是否为ST或退市股票": "value", "trade_date": "timestamp"}, inplace=True
        )
        df_daily["factor_name"] = "是否为ST或退市股票"
        df_daily["value"] = df_daily["value"].astype(int)
        return df_daily[["timestamp", "symbol", "value", "factor_name"]].sort_values(
            by=["timestamp", "symbol"]
        )
    else:
        raise ValueError(
            "是否为ST或退市股票 因子计算结果为空，请检查数据，入参为：start_date: {}, end_date: {}".format(
                start_date, end_date
            )
        )


if __name__ == "__main__":
    start_date = "2023-09-14"
    end_date = "2023-09-14"
    df = calculate_st_name(start_date, end_date)
