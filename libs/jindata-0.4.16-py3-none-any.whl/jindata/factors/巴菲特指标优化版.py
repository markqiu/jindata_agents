import pandas as pd

from ..ddb_client import create_session_from_env

client = create_session_from_env()


def calculate_optimized_buffett(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子名称：巴菲特估值方法的优化版指标
    symbol：JNZD0000001
    所属实体：宏观数据
    频率：日
    """
    base_date = pd.to_datetime(start_date) - pd.Timedelta(days=365 * 1.5)

    start_time = pd.to_datetime(base_date).strftime("%Y.%m.%dT%H:%M:%S")
    end_time = pd.to_datetime(end_date).strftime("%Y.%m.%dT%H:%M:%S")

    # 获取央行总资产
    factor_names_str = "".join([f"`{f}" for f in ["央行总资产"]])
    script = f"""
    select timestamp,value as `央行总资产
    from loadTable("dfs://factors_6M", `cn_factors_1M)
    where factor_name in {factor_names_str} and
    timestamp between {start_time} and {end_time}
    """
    month_df = client.run(script)
    month_df = month_df[["timestamp", "央行总资产"]]
    month_df["timestamp"] = pd.to_datetime(month_df["timestamp"])
    month_df.set_index("timestamp", inplace=True)

    # 获取GDP：当季值
    factor_names_str = "".join([f"`{f}" for f in ["GDP：当季值"]])
    script = f"""
    select timestamp,value as `GDP：当季值
    from loadTable("dfs://factors_1Y", `cn_factors_1Q)
    where factor_name in {factor_names_str} and
    timestamp between {start_time} and {end_time}
    """
    quarter_df = client.run(script)
    quarter_df["timestamp"] = pd.to_datetime(quarter_df["timestamp"])
    quarter_df.set_index("timestamp", inplace=True)
    quarter_df["滚动四季度总和"] = quarter_df["GDP：当季值"].rolling("365D").sum()
    quarter_df = quarter_df.iloc[3:]  # 去掉前三个季度，因为没有四个季度的数据
    # 获取总市值
    factor_names_str = "".join([f"`{f}" for f in ["总市值"]])
    symbols_str = "".join([f"`{f}" for f in ["EMM00612445"]])
    script = f"""
    select timestamp, value as `总市值
    from loadTable("dfs://factors_6M", `cn_factors_1D)
    where factor_name in {factor_names_str} and
    timestamp between {start_time} and {end_time} and
    symbol in {symbols_str}
    """
    mv_df = client.run(script)
    mv_df["timestamp"] = pd.to_datetime(mv_df["timestamp"])
    mv_df.set_index("timestamp", inplace=True)

    # 将数据向前移动48天
    month_df.index = month_df.index + pd.DateOffset(days=48)
    quarter_df.index = quarter_df.index + pd.DateOffset(days=48)

    mv_df = mv_df.merge(month_df, left_index=True, right_index=True, how="left")
    mv_df = mv_df.merge(quarter_df, left_index=True, right_index=True, how="left")

    mv_df.fillna(method="ffill", inplace=True)
    mv_df.query("@end_date >= timestamp >= @start_date", inplace=True)
    mv_df.eval("巴菲特估值方法的优化版指标 = 总市值 / (滚动四季度总和 + 央行总资产) * 100", inplace=True)

    mv_df["factor_name"] = "巴菲特估值方法的优化版指标"
    mv_df["symbol"] = "JNZD0000001"
    mv_df.rename(columns={"巴菲特估值方法的优化版指标": "value"}, inplace=True)
    mv_df.dropna(subset=["value"], inplace=True)
    mv_df.reset_index(drop=False, inplace=True)
    return mv_df[["timestamp", "symbol", "factor_name", "value"]]


if __name__ == "__main__":
    from jindata.factors.utils import timer_decorator

    start_date = "2023-01-17"
    end_date = "2023-07-17"
    calculate_reduction_percentage_optimized = timer_decorator(
        calculate_optimized_buffett
    )
    data = calculate_reduction_percentage_optimized(start_date, end_date)
    print(data.head())
    assert data[data["timestamp"] == "2023-07-17"].value.values[0] - 57.2054 <= 0.0001
    # 画图看下效果
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 6))
    plt.plot(data["timestamp"], data["value"], marker="o")
    plt.title("巴菲特估值方法的优化版指标")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid(True)
    plt.show()
