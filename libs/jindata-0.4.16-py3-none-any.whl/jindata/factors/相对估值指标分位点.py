import sys
import pandas as pd

from ..ddb_client import create_session_from_env
from .utils import get_symbols_script

client = create_session_from_env()

QUANTILES = {
    "当前分位点": lambda x: x.rank(pct=True).iloc[-1],
    "80%分位点": lambda x: x.quantile(0.8),
    "50%分位点": lambda x: x.quantile(0.5),
    "20%分位点": lambda x: x.quantile(0.2),
}


def get_quantile_key(quantiles_dict, number):
    for key in quantiles_dict:
        if str(number) in key:
            return key


def get_basic_data(
    start_date, end_date, factor_name, time_years, quantile_val
) -> pd.DataFrame:
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    start_time = (start_date - pd.DateOffset(days=time_years * 365 + 30)).strftime(
        "%Y.%m.%dT00:00:00"
    )
    end_time = end_date.strftime("%Y.%m.%dT00:00:00")

    symbols_script = get_symbols_script()
    stock_symbols = client.run(symbols_script)
    symbol_list = stock_symbols.symbol.unique().tolist()
    symbols_str = "".join([f"`{s}" for s in symbol_list])
    symbols_condition = f" and symbol in {symbols_str}"

    factor_names = [factor_name]
    window_size = time_years * 250  # 默认使用250天
    start_date_script = start_date.strftime("%Y.%m.%dT00:00:00")

    if quantile_val != "当前":
        script = f"""
        stockData = select timestamp, symbol, factor_name ,value
        from loadTable("dfs://factors_6M", `cn_factors_1D)
        where factor_name in {factor_names} and
        timestamp between {start_time} and {end_time}{symbols_condition};

        factor_df = select value from stockData
        where value is not null
        pivot by timestamp, symbol, factor_name;

        result = select timestamp, symbol,{factor_names[0]},
         mpercentile({factor_names[0]}, percent={quantile_val},
         window={window_size},minPeriods=1, interpolation="nearest") as quantile
        from factor_df context by symbol;

        result = select * from result where timestamp >= {start_date_script};
        result
        """
        data = client.run(script)
        quantile_key = get_quantile_key(QUANTILES, f"{quantile_val}%分位点")
        data.rename(
            columns={"quantile": f"{factor_name}_{quantile_key}_{time_years}年"},
            inplace=True,
        )
    else:
        script = f"""
        stockData = select timestamp, symbol, factor_name ,value
        from loadTable("dfs://factors_6M", `cn_factors_1D)
        where factor_name in {factor_names} and
        timestamp between {start_time} and {end_time}{symbols_condition};

        factor_df = select value from stockData
        where value is not null
        pivot by timestamp, symbol, factor_name;

        result = select timestamp, symbol,{factor_names[0]}, 
        tmrank(timestamp, {factor_names[0]}, true, {time_years}y,percent=true) as 当前分位点
        from factor_df context by symbol;

        result = select * from result where timestamp >= {start_date_script};
        result
        """
        data = client.run(script)
        cal_col = sorted([i for i in data.columns if "当前分位点" in i])
        data[cal_col] = data[cal_col].apply(lambda x: x * 100)
    # 记录所有分位点列
    cal_col = sorted([i for i in data.columns if "分位点" in i])
    data = data[["timestamp", "symbol"] + cal_col]
    df_melted = data.melt(
        id_vars=["timestamp", "symbol"],
        value_vars=cal_col,
        var_name="factor_name",
        value_name="value",
    )
    del data
    # 重新排序列
    df_melted = df_melted[["timestamp", "symbol", "factor_name", "value"]]
    return df_melted

def function_factory(factor_name, time_years, quantile_name):
    def dynamic_function(start_date, end_date):
        data = get_basic_data(
            start_date, end_date, factor_name, time_years, quantile_name
        )
        return data

    return dynamic_function


quantiles = [20, 50, 80, "当前"]
time_years_list = [3, 5, 10, 20]
factor_names = {
    "市盈率（滚动）": "pe_ttm",
    "市净率（静态）": "pb",
    "市现率（滚动）": "pcf_ttm",
    "市现率（经营性现金流、滚动）": "pcf_ocf_ttm",
    "市销率（滚动）": "ps_ttm",
}

for factor, factor_alias in factor_names.items():
    for quantile in quantiles:
        for time_years in time_years_list:
            func_name = f"cal_{factor_alias}_quantile_{quantile}_{time_years}"
            # print(func_name)
            func = function_factory(factor, time_years, quantile)
            setattr(sys.modules[__name__], func_name, func)

if __name__ == "__main__":
    start_date = "2021-01-01"
    end_date = "2022-01-01"
    import time

    start = time.time()
    result = eval("cal_pe_ttm_quantile_当前_3")(start_date, end_date)
    end = time.time()
    # 输出运行时间
    print(f"新代码运行时间:{end - start} 秒")  # 新代码运行时间:5.43687 秒
