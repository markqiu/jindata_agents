from typing import Optional, List

import pandas as pd
from scipy import stats


def get_holder_trading_script(start_date, end_date) -> str:
    return f"""
    select timestamp,trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol,
    change_pct
    from loadTable("dfs://cn_zvt", `holder_trading)
    where timestamp between {start_date} and {end_date} and holder_direction == `减持
    """


def get_equity_pledge_script(start_date, end_date) -> str:
    return f"""
    select timestamp,trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol,
    pledge_total_ratio, start_date, end_date, pledgor
    from loadTable("dfs://cn_zvt", `equity_pledge)
    where timestamp between {start_date} and {end_date}
    """


def get_symbols_script():
    return """
    select trim(upper(substr(entity_id, 6, 2)) + substr(entity_id, 9)) as symbol,
    list_date, end_date
    from loadTable("dfs://cn_zvt", `stock)
    where exchange in `sh`sz
    """


def get_finance_factors_1Q_script(
    factor_names,
    start_date,
    end_date,
    symbols: Optional[List[str]] = None,
    report_dates: Optional[List[str]] = None,
):
    factor_names_str = "".join([f"`{f}" for f in factor_names])
    symbols_condition = report_conditions = ""
    if symbols:
        symbols_str = "".join([f"`{s}" for s in symbols])
        symbols_condition = f" and symbol in {symbols_str}"
    if report_dates:
        report_dates = pd.to_datetime(report_dates)
        report_dates_str = ",".join(
            [date.strftime("%Y.%m.%dT%H:%M:%S") for date in report_dates]
        )
        report_conditions = f" and 报告期 in {report_dates_str}"
    script = f"""
    select value from loadTable("dfs://finance_factors_1Y", `cn_finance_factors_1Q)
    where factor_name in {factor_names_str} and
    timestamp between {start_date} and {end_date}{symbols_condition}{report_conditions}
    pivot by timestamp,报告期, symbol, factor_name;
    """
    return script


def get_symbols_active_on_date(df, target_date):
    """
    在给定的日期返回所有活跃的symbol

    :param df: DataFrame 包含 'list_date', 'end_date' 和 'symbol' 列
    :param target_date: 需要查询的日期, 格式为 'YYYY-MM-DD'
    :return: 该日期内活跃的symbol列表
    """
    target_date = pd.to_datetime(target_date)
    is_active_mask = (df["list_date"] <= target_date) & (df["end_date"] >= target_date)
    return df.loc[is_active_mask, "symbol"].tolist()


def timer_decorator(func):
    import time

    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print(f"Execution time of {func.__name__}: {end_time - start_time} seconds")
        return result

    return wrapper


def rolling_percentile(series, window):
    result = series.copy()
    for i in range(len(series)):
        data = series[max(0, i - window + 1) : i + 1]
        result[i] = stats.percentileofscore(data, series[i])
    return result
