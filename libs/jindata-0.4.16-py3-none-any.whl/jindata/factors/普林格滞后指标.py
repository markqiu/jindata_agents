import pandas as pd

from .utils import rolling_percentile
from ..ddb_client import create_session_from_env

client = create_session_from_env()


def calculate_synchronization_metrics(start_date: str, end_date: str) -> pd.DataFrame:
    """
    因子名称：普林格滞后指标
    symbol：JNZD0000004
    所属实体：宏观数据
    频率：月
    """
    # 计算滚动5年同比分位数所需的基础日期
    base_date = pd.to_datetime(start_date) - pd.Timedelta(days=365 * 6)

    start_time = pd.to_datetime(base_date).strftime("%Y.%m.%dT%H:%M:%S")
    end_time = pd.to_datetime(end_date).strftime("%Y.%m.%dT%H:%M:%S")

    factor_names = ["PPI：全部工业品：当月同比"]
    script = f"""
    select value
    from loadTable("dfs://factors_6M", `cn_factors_1M)
    where factor_name in {factor_names} and
    timestamp between {start_time} and {end_time}
    pivot by timestamp, factor_name;
    """
    df = client.run(script)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["value"] = rolling_percentile(df["PPI：全部工业品：当月同比"], window=5 * 12)
    df = df[df["timestamp"].between(start_date, end_date)]
    df.dropna(subset=["value"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    df["factor_name"] = "普林格滞后指标"
    df["symbol"] = "JNZD0000004"

    df = df[["timestamp", "symbol", "factor_name", "value"]]
    return df


if __name__ == "__main__":
    from jindata.factors.utils import timer_decorator

    start_date = "2000-01-01"
    end_date = "2023-07-17"
    calculate_reduction_percentage_optimized = timer_decorator(
        calculate_synchronization_metrics
    )
    data = calculate_reduction_percentage_optimized(start_date, end_date)
    print(data.head())
    assert data[data["timestamp"] == "2021-05-01"].value.values[0] - 100 <= 0.01
    # 画图看下效果
    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 6))
    plt.plot(data["timestamp"], data["value"], marker="o")
    plt.title("巴菲特估值方法的优化版指标")
    plt.xlabel("Date")
    plt.ylabel("Value")
    plt.grid(True)
    plt.show()
