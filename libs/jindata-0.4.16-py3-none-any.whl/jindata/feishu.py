import time
from datetime import datetime, timedelta
from typing import Tuple, Dict, List
import warnings

import pandas as pd
from collections import namedtuple
from larksuiteoapi import DOMAIN_FEISHU, Config
from loguru import logger

from larksuiteoapi.service.sheets.v2 import (
    Service,
    SpreadsheetsValuesGetResult,
    ValueRange,
    SpreadsheetsValuesBatchUpdateReqBody,
)

from .recorder.schema import gen_factor_db_name, gen_factor_table_name


_feishu_settings = Config.new_internal_app_settings(
    "cli_a07d06825479100d",
    "jIenzq0OAUphYmZUkbZK9gCrb1dVnKhz",
    "foLwdTJY1olsBdncrNokWeqLe2eWXFUw",
    "subscribe",
)
feishu_config = Config.new_config_with_memory_store(
    DOMAIN_FEISHU,
    _feishu_settings,
    logger,
    log_level=4,
)

service = Service(feishu_config)

# 测试sheet
# SHEET_TOKEN = "WeZwsK5rghBfuctMqO6c0YPQnrf"
SHEET_TOKEN = "shtcnIHASIEQ20MghqqZce2CFwc"


def get_sheet_values(
    token: str,
    range_: str,
) -> SpreadsheetsValuesGetResult:
    """获取表格元数据."""
    req = (
        service.spreadsheetss.values_get().set_spreadsheetToken(token).set_range(range_)
    )
    resp = req.do()
    return resp.data


def get_data_sheet_info(sheet_id: str) -> Tuple[str, str]:
    """获取元数据表某sheet的信息数据
    Args:
        sheet_id: 表的sheet id
    Returns:
        市场，新表名
    """
    data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", "7xGhlz")
    df = pd.DataFrame(data.value_range.values[1:], columns=data.value_range.values[0])
    df = df[df["sheet id"] == sheet_id]
    return df["市场"].values[0], df["新表名"].values[0]


def get_all_data_sheet_info() -> Dict[str, List[str]]:
    """获取元数据表的所有sheet的信息数据
    Returns:
        以new_table为key，对应的值为sheet_name, sheet_id, table_type, market_name, old_db, old_table, new_db, range_str, freq, is_vector。
    """
    data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", "7xGhlz")
    df = pd.DataFrame(data.value_range.values[1:], columns=data.value_range.values[0])
    result = {}
    for _, one_sheet in df.iterrows():
        sheet_name = one_sheet["数据名称"]
        sheet_id = one_sheet["sheet id"]
        market_name = one_sheet["市场"]
        old_db = one_sheet["旧数据库"]
        old_table = one_sheet["旧表名"]
        new_table_def = one_sheet["新表名"]
        table_type, freq, is_vector = new_table_def.split(",")
        is_vector = bool(int(is_vector))
        new_table = gen_factor_table_name(market_name, table_type, freq, is_vector)
        if table_type != "entity_info":
            range_str, new_db = gen_factor_db_name(table_type, freq, is_vector)
        else:
            range_str = ""
            new_db = "base_info"
            new_table = sheet_id
        new_item = (
            [
                sheet_name,
                sheet_id,
                table_type,
                market_name,
                old_db,
                old_table,
                new_db,
                range_str,
                freq,
                is_vector,
            ],
        )
        result[new_table] = (
            new_item + result[new_table] if new_table in result else new_item
        )
    return result


def get_metadata() -> pd.DataFrame:
    """获取元数据表的所有sheet的数据"""
    df_list = []
    table_info = get_all_data_sheet_info()
    for table in table_info:
        for (
            _sheet_name,
            sheet_id,
            _table_type,
            _market_name,
            _old_db,
            _old_table,
            _new_db,
            _range_str,
            _freq,
            _is_vector,
        ) in table_info[table]:
            data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", sheet_id)
            df = pd.DataFrame(
                data.value_range.values[1:], columns=data.value_range.values[0]
            )
            df_list.append(df[["指标名称", "所属实体", "频率", "单位"]])
    result = pd.concat(df_list)
    result.columns = ["数据名称", "所属实体名称", "频率", "单位"]  # 对齐概念，因为指标和数据有些混淆，统一为数据
    return result


AZ = [chr(ord("A") + i) for i in range(26)]

# def
# 实体表代码
# warnings.warn("deprecated", DeprecationWarning)
entity_table_map = {
    "A股股票": "stock",
    "ETF": "etf",
    "指数": "index",
    "板块": "block",
    "港股股票": "stock_hk",
}


def get_last_tradeday(ddb_session):
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    today = datetime.now().strftime("%Y.%m.%d")
    five_days_ago = (datetime.now() - timedelta(days=5)).strftime("%Y.%m.%d")
    trade_day = ddb_session.run(
        f"""getMarketCalendar('SSE', 2024.01.01 , {today})"""
    ).tolist()
    list_date = [i.strftime("%Y.%m.%d") for i in trade_day]
    result_list = [i for i in list_date if i <= five_days_ago]
    result = max(result_list)
    return result


#
def get_sample_values(table_name):
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    from jindata.ddb_client import create_session_from_env

    ddb_session = create_session_from_env()
    sql = f"select (upper(exchange)+code) as symbol from loadTable('dfs://cn_zvt','{table_name}') where end_date is null"
    if table_name == "stock":
        sql += " and exchange in `sh`sz`bj"
    elif table_name == "index":
        last_few_day = get_last_tradeday(ddb_session)
        sql = f"select upper(split(entity_id,'_')[1])+split(entity_id,'_')[2] as symbol from loadTable('dfs://cn_zvt','index_1d_kdata') where timestamp = {last_few_day}"
    elif table_name == "stock_hk":
        sql = f"select (upper(exchange)+code) as symbol from loadTable('dfs://cn_zvt','{table_name}')"
    df_symbol = ddb_session.run(sql)
    return df_symbol.symbol.tolist()


# 实体样本代码
def get_entity_sample_map(entity_table_map):
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    entity_sample_map = {}
    for k, v in entity_table_map.items():
        entity_sample_map[k] = get_sample_values(v)
    return entity_sample_map


# warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning)
sheet_name_map = {
    "A股股票-日": "factor,6M,1D,0",
    "A股股票-日（向量）": "factor,6M,1D,1",
    "ETF-行情-日": "factor,6M,1D,0",
    "指数-行情-日": "factor,6M,1D,0",
    "板块-行情-日": "factor,6M,1D,0",
    "港股股票-行情-日": "factor,6M,1D,0",
    "宏观数据-日": "macro,6M,1D,0",
    "宏观数据-月": "macro,6M,1M,0",
    "宏观数据-季": "macro,1Y,1Q,0",
    "A股股票-财务-季": "finance,1Y,1Q,0",
    "宏观数据-年": "macro,1Y,1Y,0",
    "A股股票-财务-年": "finance,1Y,1Y,0",
}


def get_symbols(
    metadata_df: pd.DataFrame, entity_type: str, factors: list[str]
) -> list[str]:
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    if entity_type == "宏观数据":
        df_ = metadata_df[metadata_df["指标名称"].isin(factors)]
        return df_["指标ID"].to_list()
    entity_sample_map = get_entity_sample_map(entity_table_map)
    return entity_sample_map[entity_type]


def get_end_date(
    metadata_df: pd.DataFrame, entity_type: str, factors: list[str], sheet_name: str
) -> str:
    """根据样本数据获取数据日期"""
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    from jindata.ddb_client import create_session_from_env

    ddb_session = create_session_from_env()
    dtype, source, frequency, _ = sheet_name_map[sheet_name].split(",")

    symbols = get_symbols(metadata_df, entity_type, factors)
    base_count, factors_num = len(symbols), len(factors)
    total_count = base_count * factors_num
    symbol_str = "".join(f"`{s}" for s in symbols)

    if dtype == "finance":
        factors_table_mapping = {
            "1Y": {"1Q": "cn_finance_factors_1Q", "1Y": "cn_finance_factors_1Y"},
        }
        table_name = factors_table_mapping[source][frequency]
        factor_str = "".join(f"`{s}" for s in factors)
        start_timestamp = (datetime.now() - timedelta(days=365)).strftime(
            "%Y.%m.%dT00:00:00"
        )
        end_timestamp = (datetime.now() + timedelta(days=1)).strftime(
            "%Y.%m.%dT00:00:00"
        )
        sql = f"""
        select value from
        loadTable("dfs://finance_factors_{source}", `{table_name})
        where timestamp between {start_timestamp} and {end_timestamp} and symbol in {symbol_str} and factor_name in {factor_str}
        pivot by timestamp, symbol, 报告期, nullFill(factor_name, 'unknown')
        """
        df_ = ddb_session.run(sql)
        df_count = df_[df_.timestamp.dt.date == datetime.now().date()]
        count_num = df_count.shape[0] / factors_num
        return df_["timestamp"].max().strftime("%Y-%m-%d"), base_count, count_num
    else:
        if sheet_name == "A股股票-日（向量）":
            sql = f"""
            select timestamp,symbol,value as 申万行业分类信息
            from loadTable("dfs://vectors_6M", `cn_vectors_1D)
            where factor_name = `申万行业分类信息 and symbol in {symbol_str}
            order by timestamp desc limit {total_count}
            """
        else:
            factors_table_mapping = {
                "6M": {"1D": "cn_factors_1D", "1M": "cn_factors_1M"},
                "1Y": {"1Q": "cn_factors_1Q", "1Y": "cn_factors_1Y"},
            }
            table_name = factors_table_mapping[source][frequency]
            factor_str = ",".join(f"'{name}'" for name in factors)
            sql = f"""
            select timestamp, symbol, factor_name ,value from loadTable("dfs://factors_{source}", `{table_name})
            where factor_name in ({factor_str}) and symbol in {symbol_str}
            order by timestamp desc limit {total_count}
            """
        df_ = ddb_session.run(sql)
        df_count = df_[df_.timestamp.dt.date == datetime.now().date()]
        count_num = df_count.shape[0] / factors_num
        return df_["timestamp"].max().strftime("%Y-%m-%d"), base_count, count_num


def update_metadata_sheet(
    metadata_df: pd.DataFrame,
    sheet_token: str,
    sheet_id: str,
    indicators: list[str],
    sheet_name: str,
) -> None:
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    metadata_df = metadata_df[metadata_df["指标名称"].isin(indicators)].copy()
    metadata_df["index"] = metadata_df.index
    # 计算相邻元素之间的差异
    diff = metadata_df["index"].diff().fillna(1)  # 第一个元素的差异填充为1
    # 创建布尔掩码，标识出相邻元素之间的差异是否为1
    mask = diff != 1
    # 使用cumsum()函数为连续的元素创建分组标签
    groups = mask.cumsum()
    # 用于保存元素之间的差异的值
    ranges = []

    end_date_column = AZ[metadata_df.columns.get_loc("数据结束日期")]
    update_column = AZ[metadata_df.columns.get_loc("最近更新时间")]
    updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        end_date, base_count, count_num = get_end_date(
            metadata_df, metadata_df["所属实体"].iloc[0], indicators, sheet_name
        )
    except Exception:
        end_date = ""
    for _, row in metadata_df.groupby(groups):
        start = min(row["index"])
        end = max(row["index"])
        if end_date and count_num >= base_count * 0.9:
            ranges.append(
                ValueRange(
                    range=f"{sheet_id}!{end_date_column}{start}:{end_date_column}{end}",
                    values=[[end_date] for _ in range(end - start + 1)],
                )
            )
        ranges.append(
            ValueRange(
                range=f"{sheet_id}!{update_column}{start}:{update_column}{end}",
                values=[[updated_at] for _ in range(end - start + 1)],
            )
        )

    body = SpreadsheetsValuesBatchUpdateReqBody(value_ranges=ranges)
    req = service.spreadsheetss.values_batch_update(body).set_spreadsheetToken(
        sheet_token
    )
    req.do()


Job = namedtuple(
    "Job", ["job_id", "sheet_token", "sheet_id", "indicators", "sheet_name"]
)


def check_jobs(
    jobs: list[Job], metadata_dfs: dict[str, pd.DataFrame], description: str
) -> None:
    warnings.warn("即将过期，或者移动到正确的位置，请勿使用！", DeprecationWarning, stacklevel=2)
    from jindata.ddb_client import create_session_from_env

    ddb_session = create_session_from_env()
    jobs_count = len(jobs)
    while jobs:
        completed_jobs = []
        logger.info(
            f"开始检查 {description}({jobs_count}/{jobs_count - len(jobs)}) 任务状态..."
        )
        for job in jobs:
            status_df = ddb_session.run(f"getJobStatus('{job.job_id}')")
            if status_df is not None and not status_df.empty:
                end_time = status_df.iloc[0]["endTime"]
                if end_time:
                    logger.info(f"任务 {description}-{job.job_id} 已完成.")
                    update_metadata_sheet(
                        metadata_dfs[job.sheet_id],
                        job.sheet_token,
                        job.sheet_id,
                        job.indicators,
                        job.sheet_name,
                    )
                    completed_jobs.append(job)
                    continue
        jobs = [job for job in jobs if job not in completed_jobs]
        if jobs:
            time.sleep(60)
    logger.info(f"检查 {description} 完成.")


if __name__ == "__main__":
    data = get_sheet_values("shtcnXMoD4ErJa1vugp0LmuPz0e", "hKBuPC")
    print(data)
    df = pd.DataFrame(data.value_range.values[1:], columns=data.value_range.values[0])
    print(df)
    data = get_sheet_values("shtcnIHASIEQ20MghqqZce2CFwc", "50a351")
    df = pd.DataFrame(data.value_range.values[1:], columns=data.value_range.values[0])
    df = df[df["数据源"].str.startswith("zvt.")]
    _, df["源数据表"], df["源字段"] = df["数据源"].str.split(".", 2).str
    zvt_import_info = {}
    for source_table, source_field in zip(
        df["源数据表"].tolist(), df["源字段"].tolist(), strict=True
    ):
        if source_table not in zvt_import_info:
            zvt_import_info[source_table] = [source_field]
        else:
            zvt_import_info[source_table].append(source_field)
    print(zvt_import_info)
