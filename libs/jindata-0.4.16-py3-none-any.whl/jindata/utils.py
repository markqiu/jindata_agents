class SingletonClass:
    @classmethod
    def __new__(cls):
        if not hasattr(cls, "instance"):
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        raise NotImplementedError(
            "This is a singleton class, you should not initialize it."
        )
