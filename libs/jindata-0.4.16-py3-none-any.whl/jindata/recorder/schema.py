from enum import Flag, auto
from typing import List, Dict

from . import 市场编码, 实体类型编码, IntervalLevel
from ..utils import SingletonClass


class KeepDuplicates(Flag):
    LAST = auto()
    ALL = auto()
    FIRST = auto()


class DolphinDbTableSchema:
    """DolphinDB的表的定义"""

    def __init__(
        self,
        db: str,
        table_name: str,
        cols: List[str],
        types: List[str],
        comments: List[str],
        compress_settings: List[str],
        partitionColumns: List[str],
        sortColumns: List[str],
        keepDuplicates: KeepDuplicates,
        load_history_sql: str = None,
    ):
        assert len(cols) == len(types) == len(comments) == len(compress_settings)
        assert all(
            item
            in [
                "VOID",
                "BOOL",
                "CHAR",
                "SHORT",
                "INT",
                "LONG",
                "DATE",
                "MONTH",
                "TIME",
                "MINUTE",
                "SECOND",
                "DATETIME",
                "TIMESTAMP",
                "NANOTIME",
                "NANOTIMESTAMP",
                "FLOAT",
                "DOUBLE",
                "SYMBOL",
                "STRING",
                "UUID",
                "FUNCTIONDEF",
                "HANDLE",
                "CODE",
                "DATASOURCE",
                "RESOURCE",
                "ANY",
                "COMPRESS",
                "ANY DICTIONARY",
                "DATEHOUR",
                "IPADDR",
                "INT128",
                "BLOB",
                "COMPLEX",
                "POINT",
                "DURATION",
                "DECIMAL32(S)",
                "DECIMAL64(S)",
            ]
            for item in types
        )
        assert all(item in ["lz4", "delta"] for item in compress_settings)
        self.db = db
        self.table_name = table_name
        self.cols = cols
        self.types = types
        self.comments = comments
        self.compress_settings = compress_settings
        self.partitionColumns = partitionColumns
        self.sortColumns = sortColumns
        self.keepDuplicates = keepDuplicates
        self.load_history_sql = load_history_sql
        TableStore().add_table(db, table_name, self)

    def to_schema(self) -> str:
        assert (
            len(self.cols)
            == len(self.types)
            == len(self.comments)
            == len(self.compress_settings)
        )
        schema = ""
        for i in range(len(self.cols)):
            schema += f'    {self.cols[i]}        {self.types[i]}[comment="{self.comments[i]}", compress="{self.compress_settings[i]}"]\n'
        return schema

    def to_sql(self) -> str:
        template = f" \
            create table \"{self.db}\".\"{self.table_name}\" (\n{self.to_schema()}\n) \n partitioned by {', '.join(self.partitionColumns)}, \n sortColumns={self.sortColumns}, \n keepDuplicates={self.keepDuplicates.name};"
        return template

    def set_load_history_sql(self, sql: str):
        self.load_history_sql = sql


class TableStore(SingletonClass):
    """用于存储所有的表的列表，以及表的定义，用于创建环境"""

    _tables: Dict[str, DolphinDbTableSchema] = {}

    def __new__(cls):
        super(SingletonClass, cls).__new__(cls)
        return cls

    @classmethod
    def add_table(
        cls,
        db: str,
        table_name: str,
        table_schema: DolphinDbTableSchema,
    ):
        cls._tables[f"{db}.{table_name}"] = table_schema

    @classmethod
    def get_table(cls, db: str, table_name: str) -> DolphinDbTableSchema:
        return cls._tables[f"{db}.{table_name}"]

    @classmethod
    def get_all_tables(cls) -> List[str]:
        return list(cls._tables.keys())

    @classmethod
    def get_all_table_schemas(
        cls,
    ) -> List[DolphinDbTableSchema]:
        return list(cls._tables.values())

    @classmethod
    def get_all_table_schemas_dict(cls) -> dict:
        return cls._tables

    @classmethod
    def remove_table(cls, db: str, table_name: str):
        del cls._tables[f"{db}.{table_name}"]

    @classmethod
    def clear(cls):
        cls._tables.clear()

    @classmethod
    def contains(cls, db: str, table_name: str) -> bool:
        return f"{db}.{table_name}" in cls._tables


class EntityInfoDataBase:
    """用于存储某市场下的所有的实体信息
    一个类只能定义一个市场，以及这个市场下的所有实体类型
    把建库、建表等方法都放在这里
    """

    def __init__(self, entity_market: 市场编码, entity_types: List[实体类型编码]):
        self.entity_market = entity_market
        self.entity_types = entity_types
        self.info_db_name = entity_market

    def drop_create_info_db(self):
        pass


def gen_factor_db_name(
    table_type: str,
    freq: IntervalLevel or str,
    is_vector: bool,
    db_name_prefix: str = None,
):
    """根据频率生成dolphindb数据库名和时间分区字符串
    Args:
        table_type: 表类型，finance、factor等
        freq: 频率
        is_vector: 是否是向量
        db_name_prefix: 数据库名前缀
    """
    if type(is_vector) != bool:
        is_vector = bool(int(is_vector))
    if table_type == "finance":
        db_name_prefix = f"{db_name_prefix+'_' if db_name_prefix else ''}finance"
    if type(freq) == str:
        freq = IntervalLevel.from_pd_freq(freq)

    db_name_suffix = "vectors" if is_vector else "factors"
    if freq < IntervalLevel.LEVEL_1DAY:
        range_str = "2005.01M..2030.01M"
        db = (
            f"dfs://{db_name_prefix + '_' if db_name_prefix else ''}{db_name_suffix}_1M"
        )
    elif IntervalLevel.LEVEL_1DAY <= freq <= IntervalLevel.LEVEL_1MON:
        range_str = "2005.01M + 6*0..44"
        db = (
            f"dfs://{db_name_prefix + '_' if db_name_prefix else ''}{db_name_suffix}_6M"
        )
    elif IntervalLevel.LEVEL_1MON < freq <= IntervalLevel.LEVEL_1YEAR:
        range_str = "2005.01M + 12*0..22"
        db = (
            f"dfs://{db_name_prefix + '_' if db_name_prefix else ''}{db_name_suffix}_1Y"
        )
    elif IntervalLevel.LEVEL_1YEAR < freq <= IntervalLevel.LEVEL_3YEAR:
        range_str = "2005.01M + 24*0..11"
        db = (
            f"dfs://{db_name_prefix + '_' if db_name_prefix else ''}{db_name_suffix}_2Y"
        )
    else:
        range_str = "2005.01M..2030.01M"
        db = (
            f"dfs://{db_name_prefix + '_' if db_name_prefix else ''}{db_name_suffix}_1M"
        )
    return range_str, db


def gen_factor_table_name(
    market_name: str,
    table_type: str,
    freq: IntervalLevel or str,
    is_vector: bool,
    table_name_prefix: str = None,
):
    """根据市场编码，表类型、频率等生成dolphindb表名
    Args:
        market_name: 市场编码，cn、us、hk等在市场编码中定义，和交易所编码区分开。交易所编码为 SH、SZ、HK等，是放在 symbol前面的前缀
        table_type: 表类型，finance、factor等
        freq: 频率
        is_vector: 是否是向量
        table_name_prefix: 表名前缀
    """
    if type(is_vector) != bool:
        is_vector = bool(int(is_vector))
    if type(freq) == str:
        freq = IntervalLevel.from_pd_freq(freq)

    if table_type == "finance":
        table_name_prefix = f"{table_name_prefix or ''}finance"
    return (
        f"{market_name}_{table_name_prefix + '_' if table_name_prefix else ''}vectors_{freq.to_pd_freq()}"
        if is_vector
        else f"{market_name}_{table_name_prefix + '_' if table_name_prefix else ''}factors_{freq.to_pd_freq()}"
    )
