from enum import Flag, auto, IntEnum, Enum


# 基础数据定义


class 市场编码(Enum):
    """市场编码"""

    cn = auto()
    hk = auto()
    us = auto()


class 交易所编码(Flag):
    """交易所编码 https://github.com/dolphindb/DolphinDBModules/tree/master/MarketHoliday#31-%E4%BA%A4%E6%98%93%E6%89%80iso-code"""

    SH = auto()
    SZ = auto()
    HK = auto()
    US = auto()


class 实体类型编码(Flag):
    """实体类型编码"""

    stocks = auto()
    index = auto()
    blocks = auto()
    funds = auto()
    economics = auto()
    portifolio = auto()


# 行业分类方法列表
行业分类方法列表 = {
    "sw_l1": "申万一级行业",
    "sw_l2": "申万二级行业",
    "sw_l3": "申万三级行业",
    "jq_l1": "聚宽一级行业",
    "jq_l2": "聚宽二级行业",
}

# 板块分类方法列表
板块分类方法列表 = {"jq": "聚宽概念板块"}


class IntervalLevel(IntEnum):
    """
    Repeated fixed time interval, e.g, 5m, 1d.
    """

    #: level tick
    LEVEL_TICK = 1
    #: 1 minute
    LEVEL_1MIN = 60
    #: 5 minutes
    LEVEL_5MIN = 300
    #: 15 minutes
    LEVEL_15MIN = 15 * 60
    #: 30 minutes
    LEVEL_30MIN = 30 * 60
    #: 1 hour
    LEVEL_1HOUR = 60 * 60
    #: 4 hours
    LEVEL_4HOUR = 4 * 60 * 60
    #: 1 day
    LEVEL_1DAY = 24 * 60 * 60
    #: 1 week
    LEVEL_1WEEK = 7 * 24 * 60 * 60
    #: 1 month
    LEVEL_1MON = 30 * 24 * 60 * 60
    #: 1 quarter
    LEVEL_1QUARTER = 90 * 24 * 60 * 60
    #: half year
    LEVEL_6MONTH = 180 * 24 * 60 * 60
    #: 1 year
    LEVEL_1YEAR = 365 * 24 * 60 * 60
    #: 3 years
    LEVEL_3YEAR = 3 * 365 * 24 * 60 * 60

    @staticmethod
    def from_pd_freq(freq):
        if freq == "1min":
            return IntervalLevel.LEVEL_1MIN
        if freq == "5min":
            return IntervalLevel.LEVEL_5MIN
        if freq == "15min":
            return IntervalLevel.LEVEL_15MIN
        if freq == "30min":
            return IntervalLevel.LEVEL_30MIN
        if freq == "1H":
            return IntervalLevel.LEVEL_1HOUR
        if freq == "4H":
            return IntervalLevel.LEVEL_4HOUR
        if freq == "1D":
            return IntervalLevel.LEVEL_1DAY
        if freq == "1W":
            return IntervalLevel.LEVEL_1WEEK
        if freq == "1M":
            return IntervalLevel.LEVEL_1MON
        if freq == "1Q":
            return IntervalLevel.LEVEL_1QUARTER
        if freq == "6M":
            return IntervalLevel.LEVEL_6MONTH
        if freq == "1Y":
            return IntervalLevel.LEVEL_1YEAR
        raise ValueError("invalid freq value: {}".format(freq))

    def to_pd_freq(self):
        if self == IntervalLevel.LEVEL_1MIN:
            return "1min"
        if self == IntervalLevel.LEVEL_5MIN:
            return "5min"
        if self == IntervalLevel.LEVEL_15MIN:
            return "15min"
        if self == IntervalLevel.LEVEL_30MIN:
            return "30min"
        if self == IntervalLevel.LEVEL_1HOUR:
            return "1H"
        if self == IntervalLevel.LEVEL_4HOUR:
            return "4H"
        if self == IntervalLevel.LEVEL_1DAY:
            return "1D"
        if self == IntervalLevel.LEVEL_1WEEK:
            return "1W"
        if self == IntervalLevel.LEVEL_1MON:
            return "1M"
        if self == IntervalLevel.LEVEL_1QUARTER:
            return "1Q"
        if self == IntervalLevel.LEVEL_6MONTH:
            return "6M"
        if self == IntervalLevel.LEVEL_1YEAR:
            return "1Y"

    def floor_timestamp(self, pd_timestamp):
        if self == IntervalLevel.LEVEL_1MIN:
            return pd_timestamp.floor("1min")
        if self == IntervalLevel.LEVEL_5MIN:
            return pd_timestamp.floor("5min")
        if self == IntervalLevel.LEVEL_15MIN:
            return pd_timestamp.floor("15min")
        if self == IntervalLevel.LEVEL_30MIN:
            return pd_timestamp.floor("30min")
        if self == IntervalLevel.LEVEL_1HOUR:
            return pd_timestamp.floor("1h")
        if self == IntervalLevel.LEVEL_4HOUR:
            return pd_timestamp.floor("4h")
        if self == IntervalLevel.LEVEL_1DAY:
            return pd_timestamp.floor("1d")
        if self == IntervalLevel.LEVEL_1WEEK:
            return pd_timestamp.floor("1w")
        if self == IntervalLevel.LEVEL_1MON:
            return pd_timestamp.floor("1m")
        if self == IntervalLevel.LEVEL_1QUARTER:
            return pd_timestamp.floor("1q")
        if self == IntervalLevel.LEVEL_6MONTH:
            return pd_timestamp.floor("6m")
        if self == IntervalLevel.LEVEL_1YEAR:
            return pd_timestamp.floor("1y")

    def to_minute(self):
        return int(self.to_second() / 60)

    def to_second(self):
        return int(self.to_ms() / 1000)

    def to_ms(self):
        """
        To seconds count in the interval

        :return: seconds count in the interval
        """
        #: we treat tick intervals is 5s, you could change it
        return self.value * 1000

    def __ge__(self, other):
        if self.__class__ is other.__class__:
            return self.to_ms() >= other.to_ms()
        return NotImplemented

    def __gt__(self, other):
        if self.__class__ is other.__class__:
            return self.to_ms() > other.to_ms()
        return NotImplemented

    def __le__(self, other):
        if self.__class__ is other.__class__:
            return self.to_ms() <= other.to_ms()
        return NotImplemented

    def __lt__(self, other):
        if self.__class__ is other.__class__:
            return self.to_ms() < other.to_ms()
        return NotImplemented
