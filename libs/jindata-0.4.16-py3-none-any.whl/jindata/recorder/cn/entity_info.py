from . import 数据库名称, 实体编码列表
from ...provider.api import get_all_securities
from ...ddb_client import create_session_from_env


def update_entity_info(start_date, end_date):
    """获取所有实体信息，并写入数据库"""
    # 第一步：获取ddb_client，建立ddb连接
    ddb_session = create_session_from_env()

    # 第二步：获取所有实体列表
    # TODO: 关注有些数据可能不是交易日，而是以自然日为索引。需要设计一下。
    data = get_all_securities(实体编码列表, start_date, end_date)

    # 第三步：将实体列表写入数据库
    ddb_session.append(数据库名称, "entity_info", data)
