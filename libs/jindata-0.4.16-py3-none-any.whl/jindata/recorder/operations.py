from typing import List

import pandas as pd
from loguru import logger
import dolphindb as ddb

from ..feishu import get_data_sheet_info
from . import IntervalLevel
from .schema import (
    TableStore,
    gen_factor_db_name,
    gen_factor_table_name,
)
from ..ddb_client import DolphindbSession


class DolphinDBRecorder(DolphindbSession):
    """用于dolphindb的数据存储，包括创建数据库、创建表、插入数据等操作
    """

    def __init__(self, host: str, port: int, user: str, password: str, startup: str = None):
        super().__init__(host, port, user, password, startup)

    def create_factor_db_table(
            self,
            market_name: str,
            table_type: str,
            factor_names: List[str],
            other_datetime_col_names: List[str] = None,
            other_datetime_col_types: List[str] = None,
            freq: IntervalLevel or str = IntervalLevel.LEVEL_1DAY,
            is_vector: bool = False,
            drop: bool = False,
            db_name_prefix: str = None,
            table_name_prefix: str = None,
    ):
        """建立窄表模型数据库
        Args:
            market_name: 市场名称
            table_type: 表类型，可选值为entity_info, factor, finance, event
            factor_names: 因子名称列表
            other_datetime_col_names: 其他datetime类型的列名称列表
            other_datetime_col_types: 其他datetime类型的列类型列表
            freq: 频率
            is_vector: 是否是向量
            drop: 是否删除已经存在的数据库
            db_name_prefix: 数据库名称前缀
            table_name_prefix: 表名称前缀
        """
        # 时间分区<1d的采用一个月一个分区，1d-6mon的freq采用半年一个分区，6mon-1y的freq采用一年一个分区，1y以上的freq采用2年一个分区
        # 全部从2005年1月开始
        range_str, db = gen_factor_db_name(
            table_type, freq, is_vector, db_name_prefix=db_name_prefix
        )
        table_name = gen_factor_table_name(
            market_name,
            table_type=table_type,
            freq=freq,
            is_vector=is_vector,
            table_name_prefix=table_name_prefix,
        )

        if other_datetime_col_names:
            assert len(other_datetime_col_names) == len(other_datetime_col_types)
            other_datetime_col_names_str = (
                f"""\"{", ".join(other_datetime_col_names)}\", """
            )
            other_datetime_col_types_str = ", ".join(other_datetime_col_types) + ", "
            compress_methods = f"""{{timestamp: "delta", {': "delta", '.join(other_datetime_col_names) + ': "delta"'}}}"""
        else:
            other_datetime_col_names_str = other_datetime_col_types_str = ""
            compress_methods = """{timestamp: "delta"}"""

        if drop and self.exists_table(db, table_name):
            logger.debug(f"删除表： {table_name}")
            self.drop_table(db, table_name)

        script = f"""
            if(not existsDatabase("{db}")){{
                dbTime = database("", RANGE, {range_str}) // 每半年一个分区
                dbFactor = database("", VALUE, {factor_names}) // 因子名分区
                db = database(directory="{db}", partitionType=COMPO, partitionScheme=[dbTime, dbFactor], chunkGranularity="TABLE", engine="TSDB")
            }}else{{
                db = database("{db}")
            }}
            //sortColumn降维函数
            def hashFunc(x){{
                return hashBucket(x,500)
            }}
            if(not existsTable("{db}", "{table_name}")){{
                col_names, col_types = ["timestamp", {other_datetime_col_names_str}"symbol", "factor_name", "value"],
                        [DATETIME, {other_datetime_col_types_str}SYMBOL, SYMBOL, DOUBLE{"[]" if is_vector else ""}]
                db = database("{db}")
                factor_partition = db.createPartitionedTable(
                    table=table(1:0, col_names, col_types), tableName = "{table_name}",
                    partitionColumns = ["timestamp", "factor_name"],
                    sortColumns = ["symbol", {other_datetime_col_names_str[:-2] or '"timestamp"'}], compressMethods = {compress_methods}, keepDuplicates = FIRST,
                    sortKeyMappingFunction = [hashFunc])
            }}
        """
        logger.debug(f"创建数据库： {db}")
        logger.debug(f"创建表： {table_name}")
        self.run(script)

    def drop_database(self, db: str):
        """删除数据库

        Args:
            db: 数据库名称

        Returns:

        """
        return self._s.dropDatabase(db)

    def append(self, db: str, table: str, data: pd.DataFrame):
        """append表，如果表不存在，则报错，如果表存在，则追加数据

        Parameters
        ----------
        db:
        table
        data

        Returns
        -------

        """
        if not data.empty:
            appender = ddb.tableAppender(db, table, self._s)
            appender.append(data)

    def upsert(self, db: str, table: str, data: pd.DataFrame):
        """插入或者更新表，用于批量更新带索引的数据表

        Args:
            db: 数据库名称
            table: 表名称
            data: 数据

        Returns:

        """
        upsert = ddb.tableUpsert(db, table, self._s)
        upsert.upsert(data)

    def exists_table(self, db: str, table: str) -> bool:
        """判断表是否存在

        Args:
            db: 数据库名称
            table: 表名称

        Returns:
            存在返回True，不存在返回False
        """
        return self._s.existsTable(db, table)

    def exists_database(self, db: str) -> bool:
        """判断数据库是否存在

        Args:
            db: 数据库名称

        Returns:
            存在返回True，不存在返回False
        """
        return self._s.existsDatabase(db)

    def add_value_partitions(self, db: str, partitions: List[str]):
        """添加分区

        Args:
            db: 数据库名称
            table: 表名称
            partitions: 分区列表

        Returns:

        """
        script = f"""
        db = database("{db}")
        addValuePartitions(db, {partitions}, level=1)
        """
        self.run(script)

    def drop_table(self, db: str, table: str):
        """删除表

        Args:
            db: 数据库名称
            table: 表名称

        Returns:

        """
        return self._s.dropTable(db, table)

    def create_table(self, db: str, table: str):
        """从TableStore中取出表信息，然后创建表

        Args:
            db: 数据库名称
            table: 表名称

        Returns:

        """
        return self.run(TableStore().get_table(db, table).to_sql())

    def import_history_data(
            self,
            start_year: int,
            end_year: int,
            old_db: str,
            old_table: str,
            new_db: str,
            sheet_id: str,
            sql: str,
    ):
        """从cn_zvt往因子表中按年导入历史数据

        Args:
            start_year: 开始年份
            end_year: 结束年份
            old_db: 源数据库
            old_table: 源数据表，要带有数据库名，如
            new_db: 目标数据库
            sheet_id: 元数据表sheet id
            sql: 从源数据库中取数据的sql

        Returns:

        """
        assert end_year >= start_year, "end_year must be greater than start_year"
        end_year - start_year if end_year > start_year else 1
        market_name, new_table_def = get_data_sheet_info(sheet_id)
        table_type, freq, is_vector = new_table_def.split(",")
        is_vector = bool(int(is_vector))
        new_table = gen_factor_table_name(
            market_name, table_type, IntervalLevel.from_pd_freq(freq), is_vector
        )
        script = f"""
            oldTable = loadTable("{old_db}", "{old_table}")
            newTable = loadTable("{new_db}", "{new_table}")
            // 根据目标表的partitionSchema计算导入间隔
            range_schema = schema(newTable).partitionSchema[0]
            i = 0
            range_list = []
            do{{
                r = datetime(date(range_schema[i]):date(range_schema[i+1]))
                if(r[1] > today()){{
                    r[1] = today()
                    i = size(range_schema)
                }}
                i += 1
                range_list.append!(r)
            }}while(i < size(range_schema))
            for(r in range_list){{
                year0, year1 = r
                if(year0 >= today()) break;
                year1 = temporalAdd(year1, -1, 'd')  // 因为between是包含边界的，所以需要减一天
                print 'importing from ' + year0 + " to " + year1
                records = {sql}
                jobId = submitJob("importing_{old_table}_{new_table}",,append!, newTable, records)
                print "Job of " + count(records) + " rows submited!"
            }}
        """
        self.run(script)

    def update_data(
            self,
            start_datetime: str,
            old_db: str,
            old_table: str,
            new_db: str,
            sheet_id: str,
            sql: str,
    ) -> str:
        """从cn_zvt往因子表中更新最新数据
        Note:
            本函数假设用户利用了dolphindb的keepDuplicates特性，所以不处理重复数据的问题

        Args:
            start_datetime: 开始日期时间，不要超过半年，要不然速度会慢
            old_db: 源数据库
            old_table: 源数据表，要带有数据库名，如
            new_db: 目标数据库
            sheet_id: 元数据表sheet id
            sql: 从源数据库中取数据的sql

        Returns:

        """
        market_name, new_table_def = get_data_sheet_info(sheet_id)
        table_type, freq, is_vector = new_table_def.split(",")
        is_vector = bool(int(is_vector))
        new_table = gen_factor_table_name(
            market_name, table_type, IntervalLevel.from_pd_freq(freq), is_vector
        )
        script = f"""
            year0 = {start_datetime or "datetime(getMarketCalendar('SSE', temporalAdd(today(), -1, 'M'), today()).head())"}
            year1 = datetime(now())
            oldTable = loadTable("{old_db}", "{old_table}")
            newTable = loadTable("{new_db}", "{new_table}")
            print 'importing from ' + year0 + " to " + year1
            records = {sql}
            submitJob("importing_{old_table}_{new_table}",,append!, newTable, records)
        """
        job_id = self.run(script)
        return job_id

    def append_factor(
            self, sheet_id: str, db_name: str, facor_name: str, data_df: pd.DataFrame
    ):
        """将因子数据插入到数据库相应的表中"""
        data_df["factor_name"] = facor_name
        market_name, new_table_def = get_data_sheet_info(sheet_id)
        table_type, freq, is_vector = new_table_def.split(",")
        is_vector = bool(int(is_vector))
        new_table = gen_factor_table_name(
            market_name, table_type, IntervalLevel.from_pd_freq(freq), is_vector
        )
        cols = (
            ["timestamp", "报告期", "symbol", "factor_name", "value"]
            if "报告期" in data_df.columns
            else ["timestamp", "symbol", "factor_name", "value"]
        )
        data_df = data_df[cols]
        self.append(db_name, new_table, data_df)

    def get_market_calendar(self, start_date: str = None, end_date: str = None):
        """获取交易日历
        Args:

        """
        if start_date and end_date:
            return self.run(f"getMarketCalendar('SSE', {start_date}, {end_date})")
        elif start_date:
            return self.run(f"getMarketCalendar('SSE', {start_date})")
        elif end_date:
            return self.run(f"getMarketCalendar('SSE', ,{end_date})")
        else:
            return self.run("getMarketCalendar('SSE')")

    def find_trade_day(self, observe_date: str = None, interval: int = -1) -> str:
        """获取观察点最近的交易日
        Args:
            observe_date: 观察点，缺省为None表示当天
            interval: 间隔，正值代表向前查找，负值代表向后查找。注意：abs(interval)<=20，缺省为-1
        """
        assert abs(interval) <= 20, "interval must be less than 20"

        script = f"""
        def find_trade_day(observe_date, interval){{
            if(interval >= 0){{ // 向前查找
                a = getMarketCalendar('SSE', observe_date, temporalAdd(observe_date, 2, 'M'));
                return a[interval-1]
            }}else{{ // 向后查找
                a = getMarketCalendar('SSE', temporalAdd(observe_date, -2, 'M'), observe_date);
                return a[size(a)+interval]
            }}
        }}
        find_trade_day({observe_date or "today()"}, {interval})
        """
        return self.run(script)
