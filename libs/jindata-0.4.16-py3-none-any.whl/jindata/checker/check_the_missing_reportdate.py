import pandas as pd
from dotenv import load_dotenv
from jindata.ddb_client import create_session_from_env


def compare_reportdate(ddb_session, cn_table, tu_table):
    name = "TS股票代码"
    if tu_table == "income":
        name = "TS代码"
    df = ddb_session.run(
        f"""
cn_temp= select right(entity_id,6) as symbol,date(report_date) as time from loadTable('dfs://cn_zvt','{cn_table}')
cn_cash= select symbol,count(time) as num1 from cn_temp where time > 2005.01.01 group by symbol order by symbol
tu_temp= select left({name},6) as symbol, date(实际公告日期) as time, date(报告期) as report_date from loadTable('dfs://tushare','{tu_table}')
tu_online = select 股票代码 as symbol from loadTable('dfs://tushare','basic_info') where 上市状态 != 'D'
tu_online2 = lj(tu_online,tu_temp,`symbol)
tu_temp2 = select symbol,report_date,max(time) as time from tu_online2 group by symbol,report_date
tu_temp3 = lj(tu_temp2,tu_temp,`symbol`report_date`time)
tu_cash= select symbol ,count(time) as num2 from tu_temp3 where report_date > 2005.01.01 group by symbol order by symbol
connector = lj(tu_cash,cn_cash,`symbol)
select symbol,num1,num2 from connector where num1 != num2
"""
    )
    df.rename(columns={"num1": "cn_num", "num2": "tu_num"}, inplace=True)
    df.fillna(0, inplace=True)
    df["difference"] = df["cn_num"] - df["tu_num"]
    df.sort_values(by=["difference"], ascending=True, inplace=True)
    df.to_excel(f"{tu_table}_compare.xlsx")


if __name__ == "__main__":
    # 将使用"dill"库进行数据的序列化和反序列化。
    load_dotenv()  # take environment variables from .env.
    ddb_session = create_session_from_env()
    compare_reportdate(ddb_session, "cash_flow_statement", "cashflow")
    compare_reportdate(ddb_session, "balance_sheet", "balancesheet")
    compare_reportdate(ddb_session, "income_statement", "income")
    ddb_session.close()
    for i in ["cashflow", "balancesheet", "income"]:
        df = pd.read_excel(f"{i}_compare.xlsx", dtype={"symbol": str})
        df = df[df["difference"] < 0]["symbol"]
        df.to_excel(f"result_{i}.xlsx")
        df.to_excel(
            f"D:/金虫子工作/PROJECT/zvt/zvt/recorders/emquantapi/finance/result_{i}.xlsx"
        )
