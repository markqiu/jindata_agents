# -*- encoding:utf-8 -*-
import json
from datetime import datetime, timedelta
import os
import pandas as pd
from dotenv import load_dotenv
from jindata.ddb_client import create_session_from_env
from joblib.externals.loky import set_loky_pickler
from loguru import logger

# 1263299,SH600519,2017-07-07,1.3837,1.52185
logger.add("process.log", rotation="500 MB")

base_stock_table_dict = {
    "stock_1d_kdata": "个股行情",
    "stock_1d_hfq_kdata": "个股后复权行情",
    "stock_1d_bfq_kdata": "个股不复权行情",
    # "stock_valuation_new2": "个股估值",
    # "stock_1d_block": "行业数据",
}
base_finance_table_dict = {
    # "balance_sheet": "资产负债表",
    "income_statement": "利润表",
    "income_statement_qtr": "单季合并利润表",
    "cash_flow_statement": "现金流量表",
    "cash_flow_statement_qtr": "单季现金流量表",
    "finance_per_share": "财务指标-每股",
    "finance_operational_capability": "财务指标-运营能力",
    "finance_profit_ability": "财务指标-盈利能力",
    "finance_capital_structure": "财务指标-资本结构",
    "finance_du_pont": "财务指标-杜邦分析",
    "finance_debtpaying_ability": "财务指标-偿债能力",
    "finance_cash_position": "财务指标-现金状况表",
    "finance_revenue_quality": "财务指标-收益质量表 ",
    # "finance_balance_sheet_structure_analysis": "财务指标-资产负债表结构分析",
    "finance_growth_ability": "财务指标-成长能力",
    "finance_derivative": "财务衍生数据",
    "finance_factor_ttm": "财务因子",
    "finance_income_statement_structure_analysis": "财务指标-利润表结构分析"
}
base_etf_table_dict = {
    "etf_1d_kdata": "ETF行情",
    "etf_1d_bfq_kdata": "ETF不复权行情",
    "etf_1d_hfq_kdata": "ETF后复权行情",
}
base_block_table_dict = {
    "block_1d_kdata": "板块行情",
}
base_index_table_dict = {
    "index_valuation": "指数估值数据",
    "index_1d_kdata": "指数行情数据",
}
base_fund_table_dict = {
    "fund_net_value": "场外基金净值数据",
}


def compare_hushen_daily_indicator(ddb_session, column, cn_column, column_cn, tu_rate, accuracy):
    df = ddb_session.run(
        f"""tu_indicator=select trim(right(ts_code,2)+left(ts_code,6)) as symbol ,lower(right(ts_code,2)) as exchange,date(trade_date) as time,{column}*{tu_rate} as {column} from loadTable('dfs://tushare','hushen_daily_indicator')
cn_val=select (upper(substr(id,6,2))+substr(id,9,6)) as symbol ,substr(id,6,2) as exchange,date(timestamp) as time,{cn_column} as {column} from loadTable('dfs://cn_zvt','stock_valuation_new2')
connector = lj(tu_indicator,cn_val,`symbol`time)
select symbol,time,{column},cn_val_{column} from connector where {column} is not null and cn_val_{column} is not null and (({column}/{accuracy} - cn_val_{column}/{accuracy}) >=1 or ({column}/{accuracy} - cn_val_{column}/{accuracy} <=-1))
                    """
    )
    num = df.shape[0]
    if num == 0:
        logger.info(f"对比指标{column_cn},对比无误")
    else:
        logger.info(f"对比指标{column_cn},结果保存到{column}.csv表中,共有{num}条")
    df.to_csv(f'{result_path}{column}.csv')


def compare_hushen_daily_line(ddb_session, column, column_ch):
    from loguru import logger

    df = ddb_session.run(
        f"""stock_bfq = select (upper(substr(id,6,2))+substr(id,9,6)) as symbol,date(timestamp) as time,{column} from loadTable('dfs://cn_zvt','stock_1d_bfq_kdata') where substr(id,6,2) in `sz`sh
tushare_daily = select (right(ts_code,2)+left(ts_code,6)) as symbol, date(trade_date) as time,{column} from loadTable('dfs://tushare','hushen_daily_line') where right(ts_code,2) in `SZ`SH
res = lj(tushare_daily,stock_bfq,`symbol`time)
select symbol,time,{column},stock_bfq_{column} from res where {column} is not null and round({column} - stock_bfq_{column}) != 0
            """
    )
    num = df.shape[0]
    logger.info(f"对比两张表中的{column_ch}（不复权）得到结果保存到{column}.csv中，共有{num}条")
    df.to_csv(f'{result_path}{column}.csv')


def compare_income(
        ddb_session,
        cn_table_name,
        column_cn_name,
        column_tu_name,
        column_res_name,
        difference,
):
    df = ddb_session.run(
        f"""cn_income = select upper((substr(id,6,2)+substr(id,9,6))) as symbol, date(report_date)as report_time,{column_cn_name} as {column_res_name} from loadTable('dfs://cn_zvt','{cn_table_name}') where substr(id,6,2) in `sz`sh
    tu_income = select (right(TS代码,2)+left(TS代码,6)) as symbol,date(报告期) as report_time,date(实际公告日期) as time, {column_tu_name} as {column_res_name}, case when 公司类型1一般工商业2银行3保险4证券 = '1' then 1 else 2 end as 公司类型1一般工商业2银行3保险4证券 from loadTable('dfs://tushare','income') where right(TS代码,2) in `SZ`SH  and 更新标识 = '1'
    tu_temp = select symbol,report_time,min(公司类型1一般工商业2银行3保险4证券) as 公司类型1一般工商业2银行3保险4证券,max(time) as time from tu_income group by symbol,report_time
    tu_income = lj(tu_temp,tu_income,`symbol`report_time`公司类型1一般工商业2银行3保险4证券`time)
    connector = lj(tu_income,cn_income,`symbol`report_time)
    connector2 = select *, cn_income_{column_res_name}/0.1 * (1-{difference}) as bottom_num,cn_income_{column_res_name}/0.1 * (1+{difference}) as top_num,{column_res_name}/0.1 as num from connector
    connector3 = select *, case when bottom_num <= top_num then bottom_num else top_num end as bottom_value, case when top_num >= bottom_num then top_num else bottom_num end as top_value from connector2
    select symbol,report_time,{column_res_name},cn_income_{column_res_name} from connector3 where {column_res_name} is not null and (num >= top_value or num <= bottom_value) and ({column_res_name} != cn_income_{column_res_name})
                            """
    )
    num = df.shape[0]
    if num == 0:
        logger.info(f"对比两张表中的{column_tu_name}字段,该字段对比无误")
    else:
        logger.info(f"对比两张表中的{column_tu_name}得到结果保存到{column_res_name}.csv中，共有{num}条")
        df.to_csv(f'{result_path}{column_res_name}.csv')
        # os.remove(f"{column_res_name}.csv")


def compare_balance(
        ddb_session,
        cn_table_name,
        column_cn_name,
        column_tu_name,
        column_res_name,
        cn_zvt_chinese,
        difference,
):
    df = ddb_session.run(
        f"""cn_balance = select upper(substr(id, 6, 2) + substr(id, 9, 6)) as symbol,date(report_date) as report_time,{column_cn_name} as {column_res_name} from loadTable('dfs://cn_zvt','{cn_table_name}') where substr(id, 6, 2) in `sz`sh
    tu_balance = select (right(TS股票代码,2)+left(TS股票代码,6)) as symbol,date(报告期) as report_time,date(实际公告日期) as time,{column_tu_name} as {column_res_name} from loadTable('dfs://tushare','balancesheet') where right(TS股票代码,2) in `SZ`SH and 更新标识 = '1'
    tu_temp = select symbol, report_time, max(time) as time from tu_balance group by symbol,report_time
    tu_balance = lj(tu_temp,tu_balance,`symbol`report_time`time)
    connector = lj(tu_balance,cn_balance,`symbol`report_time)
    connector2 = select *, cn_balance_{column_res_name}/0.1 * (1-{difference}) as bottom_num,cn_balance_{column_res_name}/0.1 * (1+{difference}) as top_num,{column_res_name}/0.1 as num from connector
    connector3 = select *, case when bottom_num <= top_num then bottom_num else top_num end as bottom_value, case when top_num >= bottom_num then top_num else bottom_num end as top_value from connector2
    select symbol,report_time,{column_res_name},cn_balance_{column_res_name} from connector3 where {column_res_name} is not null and (num >= top_value or num <= bottom_value) and ({column_res_name} != cn_balance_{column_res_name})
                            """
    )
    num = df.shape[0]
    if num == 0:
        logger.info(f"对比两张表中的{column_tu_name}字段,该字段对比无误")
    else:
        logger.info(f"对比两张表中的{column_tu_name}得到结果保存到{column_res_name}.csv中，共有{num}条")
        df.to_csv(f'{result_path}{column_res_name}.csv')
        # os.remove(f"{column_res_name}.csv")


def compare_cashflow(
        ddb_session,
        cn_table_name,
        column_cn_name,
        column_tu_name,
        column_res_name,
        difference,
):
    df = ddb_session.run(
        f"""cn_cashflow = select upper(substr(id, 6, 2) + substr(id, 9, 6)) as symbol,date(report_date) as report_time,{column_cn_name} as {column_res_name} from loadTable('dfs://cn_zvt','{cn_table_name}') where substr(id, 6, 2) in `sz`sh
    tu_cashflow = select (right(TS股票代码,2)+left(TS股票代码,6)) as symbol,date(报告期) as report_time,date(实际公告日期) as time,{column_tu_name} as {column_res_name} from loadTable('dfs://tushare','cashflow') where right(TS股票代码,2) in `SZ`SH
    tu_temp = select symbol, report_time, max(time) as time from tu_cashflow group by symbol,report_time
    tu_cashflow = lj(tu_temp,tu_cashflow,`symbol`report_time`time)
    connector = lj(tu_cashflow,cn_cashflow,`symbol`report_time)
    connector2 = select *, cn_cashflow_{column_res_name}/0.1 * (1-{difference}) as bottom_num,cn_cashflow_{column_res_name}/0.1 * (1+{difference}) as top_num,{column_res_name}/0.1 as num from connector
    connector3 = select *, case when bottom_num <= top_num then bottom_num else top_num end as bottom_value, case when top_num >= bottom_num then top_num else bottom_num end as top_value from connector2
    select symbol,report_time,{column_res_name},cn_cashflow_{column_res_name} from connector3 where {column_res_name} is not null and (num >= top_value or num <= bottom_value) and ({column_res_name} != cn_cashflow_{column_res_name})
                            """
    )
    num = df.shape[0]
    if num == 0:
        logger.info(f"对比两张表中的{column_tu_name}字段,该字段对比无误")
    else:
        logger.info(f"对比两张表中的{column_tu_name}得到结果保存到{column_res_name}.csv中，共有{num}条")
        # os.remove(f"{column_res_name}.csv")
        df.to_csv(f'{result_path}{column_res_name}.csv')


def compare_financefactor(
        ddb_session,
        cn_table_name,
        column_cn_name,
        column_tu_name,
        column_res_name,
        difference,
        df_finance_dict,
        rate
):
    df = ddb_session.run(
        f"""cn_financefactor = select upper(substr(id, 6, 2) + substr(id, 9, 6)) as symbol,date(report_date) as report_time,{column_cn_name} as {column_res_name} from loadTable('dfs://cn_zvt','{cn_table_name}') where substr(id, 6, 2) in `sz`sh
    tu_financefactor = select (right(ts_code,2)+left(ts_code,6)) as symbol,date(end_date) as report_time,date(ann_date) as time,{column_tu_name}*{rate} as {column_res_name} from loadTable('dfs://tushare','finance_indicator') where right(ts_code,2) in `SZ`SH
    tu_temp = select symbol, report_time, max(time) as time from tu_financefactor group by symbol,report_time
    tu_financefactor = lj(tu_temp,tu_financefactor,`symbol`report_time`time)
    connector = lj(tu_financefactor,cn_financefactor,`symbol`report_time)
    connector2 = select *, cn_financefactor_{column_res_name}/0.1 * (1-{difference}) as bottom_num,cn_financefactor_{column_res_name}/0.1 * (1+{difference}) as top_num,{column_res_name}/0.1 as num from connector
    connector3 = select *, case when bottom_num <= top_num then bottom_num else top_num end as bottom_value, case when top_num >= bottom_num then top_num else bottom_num end as top_value from connector2
    select symbol,report_time,{column_res_name},cn_financefactor_{column_res_name} from connector3 where {column_res_name} is not null and (num >= top_value or num <= bottom_value) and ({column_res_name} != cn_financefactor_{column_res_name})
                            """
    )
    num = df.shape[0]
    if num == 0:
        logger.info(f"使用tushare数据检查表{cn_table_name}中的{df_finance_dict[column_res_name]}字段,该字段对比无误")
    else:
        logger.info(
            f"使用tushare数据检查表{cn_table_name}中的{df_finance_dict[column_res_name]}字段,得到结果保存到{column_res_name}.csv中，共有{num}条")
        # os.remove(f"{column_res_name}.csv")
        df.to_csv(f'{result_path}{column_res_name}.csv')
    df_change = pd.read_excel("D:/jinniu/working_record/因子数据检查2-其他财务因子.xlsx", sheet_name="Sheet1")
    df_change.loc[df_change["tushare字段名（英文）"] == f"{column_res_name}", "after_change"] = num
    df_change.to_excel("D:/jinniu/working_record/因子数据检查2-其他财务因子.xlsx", sheet_name="Sheet1", index=False)


def compare_stock(ddb_session):
    df = ddb_session.run(
        f"""cn = select code from loadTable('dfs://cn_zvt','stock') where exchange in `sz`sh
            tu = select 股票代码 as code from loadTable('dfs://tushare','basic_info') where right(TS代码,2) in `SZ`SH
            select code from tu where code not in (select code from cn)
                            """
    )
    df.to_csv(f'{result_path}diff_stock.csv')


def compare_stock_self(ddb_session, table_dict):
    for key, value in table_dict.items():
        logger.info(f"检查{value}表中没有的股票")
        df = ddb_session.run(f"""stock_temp = select code from loadTable('dfs://cn_zvt','stock') where exchange in `sz`sh;
table_temp = select code,count(*) as num from loadTable('dfs://cn_zvt','{key}') group by code;
connector = lj(stock_temp,table_temp,`code)
select code from connector where num is null;""")
        df.to_csv(f'{result_path}{value}_no_stock.csv')


def check_trade_day_tushare(ddb_session):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    df = ddb_session.run(
        """select code,list_date,end_date from loadTable('dfs://cn_zvt','stock') where exchange in `sh`sz""")
    base_list = df.to_numpy().tolist()
    result_dict = {}
    for i in base_list:
        print(i[0])
        start = i[1].strftime("%Y-%m-%d")
        if pd.isna(i[2]):
            end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        else:
            end = i[2].strftime("%Y-%m-%d")
        right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
        df_check = ddb_session.run(
            f"""select timestamp from loadTable('dfs://cn_zvt','stock_1d_kdata') where code = '{i[0]}';""")
        df_check_ignore = ddb_session.run(
            f"""select trade_date from loadTable('dfs://tushare','suspend_d') where left(TS代码,6) ='{i[0]}';""")
        df_check_list = df_check.timestamp.to_list()
        df_check_list2 = df_check_ignore.trade_date.to_list()
        df_check = df_check_list + df_check_list2
        df_check_list = [i.strftime("%Y-%m-%d") for i in df_check]
        check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list]
        check_result_more = [i for i in df_check_list if i not in right_stock_trade_day]
        if len(check_result_miss) != 0:
            result_dict[f"{i[0]}"] = check_result_miss
            print(f"{i[0]}交易日不全")
            print(result_dict)
    print(result_dict)


def check_stock_trade_day(ddb_session, left_code):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    df = ddb_session.run(
        f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','stock') where left(code,3) ='{left_code}' and exchange in `sh`sz""")
    base_list = df.to_numpy().tolist()
    # table_name = ["stock_valuation_new2",
    #               "stock_1d_block", "etf_1d_kdata", "index_valuation", "index_1d_kdata", "etf_1d_bfq_kdata",
    #               "etf_1d_hfq_kdata", "block_1d_kdata",
    #               ]
    # table_name = ["stock_valuation_new2"]
    # table_name = ["stock_1d_kdata", "stock_1d_hfq_kdata", "stock_1d_bfq_kdata","stock_valuation_new2","stock_1d_block"]
    table_name = ["stock_1d_kdata", "stock_valuation_new2", "stock_1d_block"]
    # table_name = ["stock_1d_kdata", "stock_1d_hfq_kdata", "stock_1d_bfq_kdata", "stock_1d_block"]
    for table in table_name:
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
                # end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_ignore = ddb_session.run(
                f"""select 交易日期 from loadTable('dfs://choice2','trade_status') where 代码 = '{i[0]}' and 交易状态 in ["停牌一天","暂停上市","未上市","终止上市","连续停牌"]""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            if table == "stock_1d_block":
                pass
            else:
                for item in df_check_list:
                    if item in seen:
                        duplicates.add(item)
                    else:
                        seen.add(item)
                if len(duplicates) != 0:
                    print(f"{i[0]}的重复情况为{duplicates}")
            df_check_ignore_list = df_check_ignore.交易日期.to_list()
            df_check = df_check_list + df_check_ignore_list
            # merge_list = [i for i in df_check_list if i in df_check_ignore_list]
            df_check_list_total = [i.strftime("%Y-%m-%d") for i in df_check]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list_total]
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day or i < start]
            # if len(merge_list) != 0:
            #     logger.info("存在问题,查看这支股票" + i[0] + "的这些日期")
            #     print(merge_list)
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{left_code}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            # with open(f"{result_path}_{left_code}_{table}.json", 'w') as file:
            #     json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表{left_code}开头代码检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")


index_code_list = ["000001", "000002", "000003", "000009", "000010", "000016", "000171", "000300", "000688", "000698",
                   "000813", "000827", "000852", "000861", "000903", "000904", "000905", "000906", "000907", "000922",
                   "000931", "000932", "000933", "000942", "000949", "000964", "000977", "000985", "000991", "000998",
                   "399001", "399005", "399006", "399008", "399012", "399101", "399102", "399106", "399107", "399303",
                   "399330", "399673", "399808", "399814", "399967", "399970", "399974", "399975", "399976", "399986",
                   "399989", "800000", "800001", "801010", "801030", "801040", "801050", "801080", "801110", "801120",
                   "801130", "801140", "801150", "801160", "801170", "801180", "801200", "801210", "801230", "801250",
                   "801260", "801710", "801720", "801730", "801740", "801750", "801760", "801770", "801780", "801790",
                   "801880", "801890", "801950", "801960", "801970", "801980", "930599", "930608", "930653", "930697",
                   "930708", "930712", "930713", "930721", "930820", "930850", "930851", "930997", "931151", "931152",
                   "931187", "931463", "931494", "931524", "931582", "931643", "931719", "931755", "932000"]


def check_bj_stock_trade_day(ddb_session, base_stock_table_dict):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    df = ddb_session.run(
        f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','stock') where exchange = 'bj'""")
    base_list = df.to_numpy().tolist()
    tabel_name = [i for i in base_stock_table_dict.keys()]
    for table in tabel_name:
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
                # end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_ignore = ddb_session.run(
                f"""select 交易日期 from loadTable('dfs://choice2','trade_status') where 代码 = '{i[0]}' and 交易状态 in ["停牌一天","暂停上市","未上市","终止上市","连续停牌"]""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            if table == "stock_1d_block":
                pass
            else:
                for item in df_check_list:
                    if item in seen:
                        duplicates.add(item)
                    else:
                        seen.add(item)
                if len(duplicates) != 0:
                    print(f"{i[0]}的重复情况为{duplicates}")
            df_check_ignore_list = df_check_ignore.交易日期.to_list()
            df_check = df_check_list + df_check_ignore_list
            # merge_list = [i for i in df_check_list if i in df_check_ignore_list]
            df_check_list_total = [i.strftime("%Y-%m-%d") for i in df_check]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list_total]
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day or i < start]
            # if len(merge_list) != 0:
            #     logger.info("存在问题,查看这支股票" + i[0] + "的这些日期")
            #     print(merge_list)
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            with open(f"{result_path}_{table}.json", 'w') as file:
                json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表北交所数据检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")


def check_index_trade_day(ddb_session, base_index_table_dict):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    tabel_name = [i for i in base_index_table_dict.keys()]
    for table in tabel_name:
        if table == "index_valuation":
            df = ddb_session.run(
                f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','index')where code in {index_code_list}""")
            base_list = df.to_numpy().tolist()
        else:
            df = ddb_session.run(
                f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','index') where exchange in["sh","sz","swi"]and code in {index_code_list}""")
            base_list = df.to_numpy().tolist()
        # base_list is from the basic table
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                # in case today's data is not in the table
                end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
                # end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            for item in df_check_list:
                if item in seen:
                    duplicates.add(item)
                else:
                    seen.add(item)
            if len(duplicates) != 0:
                print(f"{i[0]}的重复情况为{duplicates}")
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day]
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            with open(f"{result_path}_{table}.json", 'w') as file:
                json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")

def check_etf_trade_day(ddb_session,base_etf_table_dict):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    tabel_name = [i for i in base_etf_table_dict.keys()]
    for table in tabel_name:
        # base_list is from the basic table
        df = ddb_session.run(
            f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','etf')""")
        base_list = df.to_numpy().tolist()
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                # in case today's data is not in the table
                end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
                # end = datetime.now().strftime("%Y-%m-%d")
                # end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            for item in df_check_list:
                if item in seen:
                    duplicates.add(item)
                else:
                    seen.add(item)
            if len(duplicates) != 0:
                print(f"{i[0]}的重复情况为{duplicates}")
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day]
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            with open(f"{result_path}_{table}.json", 'w') as file:
                json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")

def check_block_trade_day(ddb_session,base_block_table_dict):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    tabel_name = [i for i in base_block_table_dict.keys()]
    for table in tabel_name:
        # base_list is from the basic table
        df = ddb_session.run(
            f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','block')""")
        base_list = df.to_numpy().tolist()
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                # in case today's data is not in the table
                end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
                # end = datetime.now().strftime("%Y-%m-%d")
                # end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            for item in df_check_list:
                if item in seen:
                    duplicates.add(item)
                else:
                    seen.add(item)
            if len(duplicates) != 0:
                print(f"{i[0]}的重复情况为{duplicates}")
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day]
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            with open(f"{result_path}_{table}.json", 'w') as file:
                json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")
def check_fund_trade_day(ddb_session,base_fund_table_dict):
    basic_tradeday = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    basic_tradeday.sort()
    tabel_name = [i for i in base_fund_table_dict.keys()]
    for table in tabel_name:
        # base_list is from the basic table
        df = ddb_session.run(
            f"""select code,list_date,end_date from loadTable('dfs://cn_zvt','fund') where category in ('stock_fund','fund_fund')""")
        base_list = df.to_numpy().tolist()
        logger.info(f"开始检查表{table}表")
        result_dict_miss = {}
        result_dict_redundant = {}
        count_miss = 0
        count_redundant = 0
        count_redundant_code = 0
        for i in base_list:
            # print(i[0])
            start = i[1].strftime("%Y-%m-%d")
            if pd.isna(i[2]):
                # in case today's data is not in the table
                end = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
                # end = datetime.now().strftime("%Y-%m-%d")
                # end = "2023-12-07"
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start]
            else:
                end = i[2].strftime("%Y-%m-%d")
                wrong_stock_trade_day = [i for i in basic_tradeday if i < start or i > end]
            right_stock_trade_day = [i for i in basic_tradeday if i >= start and i <= end]
            df_check = ddb_session.run(
                f"""select timestamp from loadTable('dfs://cn_zvt','{table}') where code = '{i[0]}';""")
            df_check_list = df_check.timestamp.to_list()
            seen = set()
            duplicates = set()
            for item in df_check_list:
                if item in seen:
                    duplicates.add(item)
                else:
                    seen.add(item)
            if len(duplicates) != 0:
                print(f"{i[0]}的重复情况为{duplicates}")
            df_check_list = [i.strftime("%Y-%m-%d") for i in df_check_list]
            check_result_miss = [i for i in right_stock_trade_day if i not in df_check_list]
            check_result_redundant = [i for i in df_check_list if i in wrong_stock_trade_day]
            if len(check_result_redundant) != 0:
                count_redundant_code += 1
                count_redundant += len(check_result_redundant)
                result_dict_redundant[f"{i[0]}"] = check_result_redundant
                print(f"{i[0]}数据冗余")
            with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                json.dump(result_dict_redundant, file)
            if len(check_result_miss) != 0:
                count_miss += len(check_result_miss)
                result_dict_miss[f"{i[0]}"] = check_result_miss
                print(f"{i[0]}交易日不全")
            with open(f"{result_path}_{table}.json", 'w') as file:
                json.dump(result_dict_miss, file)
        logger.info(
            f"{table}表检查完毕,检查结果为：缺失条目数{count_miss},冗余股票数为{count_redundant_code},冗余数据条目数为{count_redundant}")
def compare_financialreport(ddb_session, base_finance_table_dict):
    for table in base_finance_table_dict.keys():
        print(f"{base_finance_table_dict[table]}正在检查当中...")
        df_code = ddb_session.run(
            f"""select code from loadTable('dfs://cn_zvt','stock_financial_report')  where exchange in `sz`sh group by code order by code"""
        )
        code_list = df_code.code.tolist()
        result_wrong_dict = {}
        result_redundant_dict = {}
        result_missing_dict = {}
        count_miss, count_miss_code = 0, 0
        count_redundant, count_redundant_code = 0, 0
        count_wrong, count_wrong_code = 0, 0
        for code in code_list:
            print(f"{code}正在检查当中")
            right_timestamp = ddb_session.run(
                f"""select report_date,timestamp from loadTable('dfs://cn_zvt','stock_financial_report')  where code = '{code}' order by report_date"""
            )
            check_timestamp = ddb_session.run(
                f"""select report_date,timestamp from loadTable('dfs://cn_zvt','{table}')  where code = '{code}' order by report_date"""
            )
            right_timestamp_temp = right_timestamp.report_date.tolist()
            right_timestamp_list = [i.strftime("%Y-%m-%d") for i in right_timestamp_temp]
            check_timestamp_temp = check_timestamp.report_date.tolist()
            check_timestamp_list = [i.strftime("%Y-%m-%d") for i in check_timestamp_temp]
            redundant_list = [i for i in check_timestamp_list if i in right_timestamp_list]
            missing_list = [i for i in right_timestamp_list if i not in check_timestamp_list]
            if len(redundant_list) > 0:
                count_redundant_code += 1
                count_redundant += len(redundant_list)
                result_redundant_dict[code] = redundant_list
                with open(f"{result_path}_{table}_redundant.json", 'w') as file:
                    json.dump(result_redundant_dict, file)
            if len(missing_list) > 0:
                count_miss_code += 1
                count_miss += len(missing_list)
                result_missing_dict[code] = missing_list
                with open(f"{result_path}_{table}_missing.json", 'w') as file:
                    json.dump(result_missing_dict, file)
            if not check_timestamp.empty and len(missing_list) == 0:
                df_merge = pd.merge(right_timestamp, check_timestamp, on="report_date", suffixes=("_right", ""),
                                    how="left")
                df_wrong = df_merge[df_merge["timestamp_right"] != df_merge["timestamp"]]
                if not df_wrong.empty:
                    count_wrong_code += 1
                    df_wrong_copy = df_wrong.copy()
                    df_wrong_copy.loc[:, 'combined'] = df_wrong.apply(
                        lambda row: [row['report_date'].strftime("%Y-%m-%d"),
                                     row['timestamp_right'].strftime("%Y-%m-%d"),
                                     row['timestamp'].strftime("%Y-%m-%d")], axis=1)
                    df_wrong_list = df_wrong_copy["combined"].to_list()
                    count_wrong += len(df_wrong_list)
                    result_wrong_dict[code] = df_wrong_list
                    with open(f"{result_path}_{table}_wrong.json", 'w') as file:
                        json.dump(result_wrong_dict, file)
        logger.info(
            f"{table}表检查完毕,检查结果为：缺失报告期的股票数为{count_miss_code},缺失报告期数为{count_miss};冗余报告期的股票数为{count_redundant_code},冗余报告期数为{count_redundant};错误公告日期的股票数为{count_wrong_code},错误公告期数为{count_wrong}")


def get_stocktrade_day(ddb_session, format):
    end = datetime.now().date().strftime("%Y.%m.%d")
    result = ddb_session.run(f"""getMarketCalendar('SSE', 2005.01.01 , {end})""")
    temp = result.tolist()
    result = [i.strftime(format) for i in temp]
    return result


if __name__ == "__main__":

    # 将使用"dill"库进行数据的序列化和反序列化。
    load_dotenv()  # take environment variables from .env.
    ddb_session = create_session_from_env()
    if not os.path.exists(f'./check_result'):
        os.makedirs(f'./check_result')
    result_path = f'./check_result/'

    # # stock_valuation_new2
    # daily_indicator = pd.read_csv('./daily_indicator_assets.csv')
    # for index, row in daily_indicator.iterrows():
    #     compare_hushen_daily_indicator(ddb_session, row['column'], row['cn_column'],row['column_cn'],row['tu_rate'],row['accuracy'])
    #
    # # stock_1d_bfq_kdata
    # df_dailyline = pd.read_csv('./daily_line_assets.csv')
    # for index, row in df_dailyline.iterrows():
    #     compare_hushen_daily_line(ddb_session, row['column'], row['column_ch'])
    # # volume
    # df = ddb_session.run(
    #     """stock_bfq = select (upper(substr(id,6,2))+substr(id,9,6)) as symbol,date(timestamp) as time,volume as vol from loadTable('dfs://cn_zvt','stock_1d_bfq_kdata') where vol is not null and substr(id,6,2) in `sz`sh
    # tushare_daily_line = select (right(ts_code,2)+left(ts_code,6)) as symbol, date(trade_date) as time,vol*100 as vol from loadTable('dfs://tushare','hushen_daily_line') where vol is not null and right(ts_code,2) in `SZ`SH
    # res = lj(stock_bfq,tushare_daily_line,`symbol`time)
    # select symbol,time,vol,tushare_daily_line_vol from res where vol is not null and tushare_daily_line_vol is not null and round(round(vol/1000000) - round(tushare_daily_line_vol/1000000)) >=2
    #             """)
    # num_vol = df.shape[0]
    # logger.info(f'对比两张表中的成交量（不复权）得到结果保存到vol.csv中，共有{num_vol}条')
    # if num_vol >= 500:
    #     df.to_csv('vol.csv')

    # 下面方法中间的数字是两表筛选数据的差距大小，可以手动调整0-1
    # #  income
    # df_income = pd.read_csv(
    #     "./income_assets.csv"
    # )
    # for _index, row in df_income.iterrows():
    #     compare_income(
    #         ddb_session,
    #         row["cn_table_name"],
    #         row["column_cn_name"],
    #         row["column_tu_name"],
    #         row["column_res_name"],
    #         0.05,
    #     )
    #

    # # #   balance
    # df_balance = pd.read_csv(
    #     "./balance_assets.csv"
    # )
    # for _index, row in df_balance.iterrows():
    #     compare_balance(
    #         ddb_session,
    #         row["cn_table_name"],
    #         row["column_cn_name"],
    #         row["column_tu_name"],
    #         row["column_res_name"],
    #         0.05,
    #     )

    # # cashflow
    # df_cashflow = pd.read_csv(
    #     "./cashflow_assets.csv"
    # )
    # for _index, row in df_cashflow.iterrows():
    #     compare_cashflow(
    #         ddb_session,
    #         row["cn_table_name"],
    #         row["column_cn_name"],
    #         row["column_tu_name"],
    #         row["column_res_name"],
    #         0.05,
    #     )

    # df_finance_factor = pd.read_csv(
    #     "./finance_factor_assets.csv"
    # )
    # df_finance_dict = df_finance_factor.set_index('column_res_name')['cn_zvt_chinese'].to_dict()
    # for _index, row in df_finance_factor.iterrows():
    #     compare_financefactor(
    #         ddb_session,
    #         row["cn_table_name"],
    #         row["column_cn_name"],
    #         row["column_tu_name"],
    #         row["column_res_name"],
    #         0.05,
    #         df_finance_dict,
    #         row["rate"]
    #     )

    # stock
    # compare_stock(ddb_session)

    # stock推广
    # check_stock_dict = {**base_finance_table_dict, **base_stock_table_dict}
    # compare_stock_self(ddb_session, check_stock_dict

    # stock_financial_report
    # compare_financialreport(ddb_session, base_finance_table_dict)

    # check_stock_trade_day
    # check_trade_day_tushare(ddb_session)
    # for i in ['000','001','002','003','300','301','600','601','603','605','688','689']:
    #     check_stock_trade_day(ddb_session, i)

    # check_bj_trade_day
    # check_bj_stock_trade_day(ddb_session,base_stock_table_dict)

    # check_index
    # check_index_trade_day(ddb_session, base_index_table_dict)

    # check_etf_trade_day
    # check_etf_trade_day(ddb_session,base_etf_table_dict)

    # check_block_trade_day
    # check_block_trade_day(ddb_session, base_block_table_dict)

    # check_fund_net_value
    check_fund_trade_day(ddb_session,base_fund_table_dict)



    ddb_session.close()
