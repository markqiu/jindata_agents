# TODO
#  1. 按照zvt的更新逻辑（entity+日期+频率）的检查每一个因子是否有值，找出缺失的日期和entity_id
#  2. 按照zvt的更新逻辑（entity+日期+频率）的检查每一个因子的值是否正确（从其他接口取数检查，抽样检查），找出缺失的日期和entity_id
#  3. 重复数据检查
"""
1. 检查base_info
    1. 每个交易日的每种entity的数量一致
    2. 每种entity的每个entity的总交易日一致
"""
