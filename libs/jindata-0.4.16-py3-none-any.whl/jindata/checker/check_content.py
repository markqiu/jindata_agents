import pandas as pd
from typing import List
from jindata.ddb_client import create_session_from_env
import tushare as ts
import time

client = create_session_from_env()


def get_factor_names(
    dfs_name: str,
    factors_table: str,
    symbols: List[str] = None,
) -> pd.DataFrame:
    """
    Args:
        dfs_name: DolphinDB中的dfs名称
        factors_table: DolphinDB中的因子表名称
    """
    start_date = pd.to_datetime("2010-01-01").strftime("%Y.%m.%dT00:00:00")
    end_date = pd.to_datetime("2011-01-01").strftime("%Y.%m.%dT00:00:00")
    if symbols:
        symbols_str = "".join([f"`{s}" for s in symbols])
        symbol_condition = f" and symbol in {symbols_str}"
    else:
        symbol_condition = " and symbol in `SZ000005"

    script = f"""
    select factor_name from loadTable("dfs://{dfs_name}", `{factors_table})
    where timestamp between {start_date} and {end_date}{symbol_condition}
    """
    return client.run(script)


def get_factors_6m(
    start_date: str,
    end_date: str,
    factor_names: List[str],
    symbols: List[str] = None,
) -> pd.DataFrame:
    """从DolphinDB加载财务数据。
    Args:
        start_date: 开始日期，日期格式为'yyyy.mm.dd'T'HH:MM:SS'
        end_date: 结束日期，日期格式为'yyyy.mm.dd'T'HH:MM:SS'
        factor_names: 因子名称列表。
        symbols: 股票代码列表。
    Returns:
        返回一个DataFrame，其中包含查询结果。
    """
    # 将factor_names列表转为DolphinDB脚本可以接受的字符串
    factor_names_str = "".join([f"`{f}" for f in factor_names])
    start_date = pd.to_datetime(start_date).strftime("%Y.%m.%dT00:00:00")
    end_date = pd.to_datetime(end_date).strftime("%Y.%m.%dT00:00:00")
    # 如果symbols不为空，生成相应的字符串
    if symbols:
        symbols_str = "".join([f"`{s}" for s in symbols])
        symbol_condition = f" and symbol in {symbols_str}"
    else:
        symbol_condition = ""
    script = f"""
    select value from loadTable("dfs://factors_6M", `cn_factors_1D)
    where timestamp between {start_date} and {end_date} and
    factor_name in {factor_names_str}{symbol_condition}
    pivot by timestamp, symbol, factor_name
    """
    return client.run(script)


def get_finance_factors_1Y(
    factor_names: List[str],
    start_date: str = None,
    end_date: str = None,
    symbols: List[str] = None,
    report_dates: List[str] = None,
) -> pd.DataFrame:
    """从DolphinDB加载财务数据。
    Args:
        start_date: 开始日期，日期格式为'yyyy.mm.dd'T'HH:MM:SS'
        end_date: 结束日期，日期格式为'yyyy.mm.dd'T'HH:MM:SS'
        factor_names: 因子名称列表。
        symbols: 股票代码列表。
    Returns:
        返回一个DataFrame，其中包含查询结果。
    """
    # 将factor_names列表转为DolphinDB脚本可以接受的字符串
    factor_names_str = "".join([f"`{f}" for f in factor_names])
    if start_date and end_date:
        start_date = pd.to_datetime(start_date).strftime("%Y.%m.%dT00:00:00")
        end_date = pd.to_datetime(end_date).strftime("%Y.%m.%dT00:00:00")
        timestamp_condition = f" and timestamp between {start_date} and {end_date}"
    else:
        timestamp_condition = ""
    # 如果symbols不为空，生成相应的字符串
    if symbols:
        symbols_str = "".join([f"`{s}" for s in symbols])
        symbol_condition = f" and symbol in {symbols_str}"
    else:
        symbol_condition = ""
    if report_dates:
        report_dates_str = "".join(
            [f"{pd.to_datetime(s).strftime('%Y.%m.%dT00:00:00')}" for s in report_dates]
        )
        report_condition = f" and 报告期 in {report_dates_str}"
    else:
        report_condition = ""
    script = f"""
    select * from loadTable("dfs://finance_factors_1Y", `cn_finance_factors_1Q)
    where factor_name in {factor_names_str}{symbol_condition}{report_condition}{timestamp_condition}
    """
    return client.run(script)


def get_symbols(
    target_date: str = None,
    symbols: List[str] = None,
) -> pd.DataFrame:
    # 如果symbols不为空，生成相应的字符串
    if symbols:
        symbols_str = ",".join([f"`{s}`" for s in symbols])  # 修改为逗号分隔
        symbol_condition = f" and symbol in ({symbols_str})"
    else:
        symbol_condition = ""

    # 添加 target_date 的条件
    if target_date:
        target_date = pd.to_datetime(target_date).strftime("%Y.%m.%dT00:00:00")
        date_condition = (
            f" and list_date <= {target_date} and end_date >= {target_date}"
        )
    else:
        date_condition = ""

    script = f"""
    select entity_id, list_date, end_date from loadTable("dfs://cn_zvt", `stock)
    where  exchange in `sh`sz{symbol_condition}{date_condition}
    """

    df = client.run(script)
    df["end_date"] = pd.to_datetime(df["end_date"].fillna(pd.to_datetime("2200-12-31")))

    df["symbol"] = df.apply(lambda x: x.entity_id.split("_"), axis=1)
    df = df[df["symbol"].apply(lambda x: "sz" in x or "sh" in x)]
    df["symbol"] = df["symbol"].apply(lambda x: f"{x[1].upper()}{x[-1]}")

    del df["entity_id"]
    df["list_date"] = pd.to_datetime(df["list_date"])
    df["end_date"] = pd.to_datetime(df["end_date"])

    return df


def get_symbols_active_on_date(df, target_date):
    """
    在给定的日期返回所有活跃的symbol

    :param df: DataFrame 包含 'list_date', 'end_date' 和 'symbol' 列
    :param target_date: 需要查询的日期, 格式为 'YYYY-MM-DD'
    :return: 该日期内活跃的symbol列表
    """
    target_date = pd.to_datetime(target_date)
    is_active_mask = (df["list_date"] <= target_date) & (df["end_date"] >= target_date)
    return df.loc[is_active_mask, "symbol"].tolist()


def get_report_date(start_date, end_date) -> pd.DataFrame:
    """
    获取对应股票的财务报表发布时间信息，包括股票代码, 计划披露时间，实际披露时间，对应报告期

    ---
    :param tickers: 股票代码或股票列表
    :param start_date: 搜索起始时间
    :param end_date: 搜索结束时间
    """
    pro = ts.pro_api()

    start_date = pd.to_datetime(start_date).strftime("%Y%m%d")
    end_date = pd.to_datetime(end_date).strftime("%Y%m%d")

    # 返回值数据格式设置
    ret_df = pd.DataFrame()

    # 报告期与时区设置，默认东八区
    report_dates = ["0331", "0630", "0930", "1231"]

    # 找到最接近的可能报告期，这里采用最近的两期报告期
    start_report_date = None
    end_report_date = None
    if start_date <= start_date[:4] + report_dates[0]:
        start_report_date = str(int(start_date[:4]) - 1) + report_dates[2]
    elif start_date <= start_date[:4] + report_dates[1]:
        start_report_date = str(int(start_date[:4]) - 1) + report_dates[3]
    elif start_date <= start_date[:4] + report_dates[2]:
        start_report_date = start_date[:4] + report_dates[0]
    else:
        start_report_date = start_date[:4] + report_dates[1]

    # 结束日期，找到最近一起的报告期
    if end_date <= end_date[:4] + report_dates[0]:
        end_report_date = str(int(end_date[:4]) - 1) + report_dates[3]
    elif end_date <= end_date[:4] + report_dates[1]:
        end_report_date = end_date[:4] + report_dates[0]
    elif end_date <= end_date[:4] + report_dates[2]:
        end_report_date = end_date[:4] + report_dates[1]
    else:
        end_report_date = end_date[:4] + report_dates[2]

    if (not start_report_date) or (not end_report_date):
        raise ValueError("[ValueError]\t无法获取最近的报告日期，检查输入的日期格式")

    # 配置对应日期内的报告期列表
    report_dates_queried = []
    if start_report_date[:4] == end_report_date[:4]:
        idx_start = report_dates.index(start_report_date[4:])
        idx_end = report_dates.index(end_report_date[4:]) + 1
        report_dates_queried = [
            start_report_date[:4] + x for x in report_dates[idx_start:idx_end]
        ]
    elif start_report_date[:4] < end_report_date[:4]:
        diff_years = int(end_report_date[:4]) - int(start_report_date[:4])
        idx_start_1 = report_dates.index(start_report_date[4:])
        idx_end_1 = len(report_dates) + 1
        report_dates_queried = [
            start_report_date[:4] + x for x in report_dates[idx_start_1:idx_end_1]
        ]
        idx_start_2 = 0
        idx_end_2 = report_dates.index(end_report_date[4:]) + 1
        for i in range(1, diff_years + 1):
            cursor_year = int(start_report_date[:4]) + i
            if cursor_year != int(end_report_date[:4]):
                report_dates_queried += [str(cursor_year)[:4] + x for x in report_dates]
            else:
                report_dates_queried += [
                    end_report_date[:4] + x for x in report_dates[idx_start_2:idx_end_2]
                ]

    def _get_total_disclosure_date(end_date: str = None):
        try:
            df_local = pro.disclosure_date(end_date=end_date)
            return df_local
        except:  # noqa: E722
            raise ValueError("[ValueError]\t接口调用失败, 返回")  # noqa: B904

    for report_date in report_dates_queried:
        try:
            df_tmp_1 = _get_total_disclosure_date(report_date)
        except:  # noqa: E722
            print("全量查询中...等待 65 秒")
            time.sleep(65)
            try:
                df_tmp_1 = _get_total_disclosure_date(report_date)
            except:  # noqa: E722
                raise ValueError("[ValueError]\t接口调用连续两次出错，返回")  # noqa: B904
        ret_df = ret_df.append(df_tmp_1, ignore_index=True)
    ret_df = (
        ret_df.loc[~ret_df.actual_date.isna()]
        .loc[(ret_df.actual_date >= start_date) & (ret_df.actual_date <= end_date)]
        .reset_index(drop=True)
    )
    ret_df["symbol"] = ret_df["ts_code"].apply(
        lambda x: x.split(".")[1] + x.split(".")[0]
    )
    ret_df = ret_df[ret_df["symbol"].str.contains("SH|SZ")]
    return ret_df
