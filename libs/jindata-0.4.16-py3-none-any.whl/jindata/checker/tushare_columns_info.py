balancesheet_columns_info = [
    {"name": "ts_code", "comment": "symbol"},
    {"name": "ann_date", "comment": "公告日期"},
    {"name": "f_ann_date", "comment": "实际公告日期"},
    {"name": "end_date", "comment": "报告期"},
    {"name": "report_type", "comment": "报表类型"},
    {"name": "comp_type", "comment": "公司类型(1一般工商业2银行3保险4证券)"},
    {"name": "end_type", "comment": "报告期类型"},
    {"name": "total_share", "comment": "期末总股本"},  # 没有
    {"name": "cap_rese", "comment": "资本公积"},
    {"name": "undistr_porfit", "comment": "未分配利润"},
    {"name": "surplus_rese", "comment": "盈余公积"},
    {"name": "special_rese", "comment": "专项储备"},  # 没有
    {"name": "money_cap", "comment": "货币资金"},
    {"name": "trad_asset", "comment": "交易性金融资产"},  # ZVT有  dolphindb 没有
    {"name": "notes_receiv", "comment": "应收票据"},
    {"name": "accounts_receiv", "comment": "应收账款"},
    {"name": "oth_receiv", "comment": "其他应收款"},
    {"name": "prepayment", "comment": "预付款项"},
    {"name": "div_receiv", "comment": "应收股利"},  # 没有
    {"name": "int_receiv", "comment": "应收利息"},  # 没有
    {"name": "inventories", "comment": "存货"},
    {"name": "amor_exp", "comment": "待摊费用"},  # 没有
    {"name": "nca_within_1y", "comment": "一年内到期的非流动资产"},
    {"name": "sett_rsrv", "comment": "结算备付金"},  # 没有
    {"name": "loanto_oth_bank_fi", "comment": "拆出资金"},  # 没有
    {"name": "premium_receiv", "comment": "应收保费"},  # 没有
    {"name": "reinsur_receiv", "comment": "应收分保账款"},  # 没有
    {"name": "reinsur_res_receiv", "comment": "应收分保合同准备金"},  # 没有
    {"name": "pur_resale_fa", "comment": "买入返售金融资产"},  # 没有 查下
    {"name": "oth_cur_assets", "comment": "其他流动资产"},  # 没有
    {"name": "total_cur_assets", "comment": "流动资产合计"},
    {"name": "fa_avail_for_sale", "comment": "可供出售金融资产"},
    {"name": "htm_invest", "comment": "持有至到期投资"},  # 没有
    {"name": "lt_eqt_invest", "comment": "长期股权投资"},
    {"name": "invest_real_estate", "comment": "投资性房地产"},
    {"name": "time_deposits", "comment": "定期存款"},  # 没有
    {"name": "oth_assets", "comment": "其他资产"},  # 没有
    {"name": "lt_rec", "comment": "长期应收款"},
    {"name": "fix_assets", "comment": "固定资产"},
    {"name": "cip", "comment": "在建工程"},
    {"name": "const_materials", "comment": "工程物资"},  # 没有
    {"name": "fixed_assets_disp", "comment": "固定资产清理"},  # 没有
    {"name": "produc_bio_assets", "comment": "生产性生物资产"},  # 没有
    {"name": "oil_and_gas_assets", "comment": "油气资产"},  # 没有
    {"name": "intan_assets", "comment": "无形资产"},
    {"name": "r_and_d", "comment": "研发支出"},
    {"name": "goodwill", "comment": "商誉"},  # 没有
    {"name": "lt_amor_exp", "comment": "长期待摊费用"},
    {"name": "defer_tax_assets", "comment": "递延所得税资产"},
    {"name": "decr_in_disbur", "comment": "发放贷款及垫款"},  # 没有
    {"name": "oth_nca", "comment": "其他非流动资产"},  # 没有
    {"name": "total_nca", "comment": "非流动资产合计"},
    {"name": "cash_reser_cb", "comment": "现金及存放中央银行款项"},  # 没有
    {"name": "depos_in_oth_bfi", "comment": "存放同业和其它金融机构款项"},  #
    {"name": "prec_metals", "comment": "贵金属"},  # 没有
    {"name": "deriv_assets", "comment": "衍生金融资产"},  # 没有
    {"name": "rr_reins_une_prem", "comment": "应收分保未到期责任准备金"},  # 没有
    {"name": "rr_reins_outstd_cla", "comment": "应收分保未决赔款准备金"},  # 没有
    {"name": "rr_reins_lins_liab", "comment": "应收分保寿险责任准备金"},  # 没有
    {"name": "rr_reins_lthins_liab", "comment": "应收分保长期健康险责任准备金"},  # 没有
    {"name": "refund_depos", "comment": "存出保证金"},  # 没有
    {"name": "ph_pledge_loans", "comment": "保户质押贷款"},  # 没有
    {"name": "refund_cap_depos", "comment": "存出资本保证金"},  # 没有
    {"name": "indep_acct_assets", "comment": "独立账户资产"},  # 没有
    {"name": "client_depos", "comment": "其中：客户资金存款"},  # 没有
    {"name": "client_prov", "comment": "其中：客户备付金"},  # 没有
    {"name": "transac_seat_fee", "comment": "其中:交易席位费"},  # 没有
    {"name": "invest_as_receiv", "comment": "应收款项类投资"},  # 没有
    {"name": "total_assets", "comment": "资产总计"},
    {"name": "lt_borr", "comment": "长期借款"},
    {"name": "st_borr", "comment": "短期借款"},
    {"name": "cb_borr", "comment": "向中央银行借款"},  # 没有
    {"name": "depos_ib_deposits", "comment": "吸收存款及同业存放"},  # 没有
    {"name": "loan_oth_bank", "comment": "拆入资金"},  # 没有
    {"name": "trading_fl", "comment": "交易性金融负债"},  # 没有
    {"name": "notes_payable", "comment": "应付票据"},  # 没有
    {"name": "acct_payable", "comment": "应付账款"},
    {"name": "adv_receipts", "comment": "预收款项"},
    {"name": "sold_for_repur_fa", "comment": "卖出回购金融资产款"},  # 没有
    {"name": "comm_payable", "comment": "应付手续费及佣金"},  # 没有
    {"name": "payroll_payable", "comment": "应付职工薪酬"},
    {"name": "taxes_payable", "comment": "应交税费"},
    {"name": "int_payable", "comment": "应付利息"},
    {"name": "div_payable", "comment": "应付股利"},  # 没有
    {"name": "oth_payable", "comment": "其他应付款"},
    {"name": "acc_exp", "comment": "预提费用"},  # 没有
    {"name": "deferred_inc", "comment": "递延收益"},
    {"name": "st_bonds_payable", "comment": "应付短期债券"},  # 没有
    {"name": "payable_to_reinsurer", "comment": "应付分保账款"},  # 没有
    {"name": "rsrv_insur_cont", "comment": "保险合同准备金"},  # 没有
    {"name": "acting_trading_sec", "comment": "代理买卖证券款"},  # 没有
    {"name": "acting_uw_sec", "comment": "代理承销证券款"},  # 没有
    {"name": "non_cur_liab_due_1y", "comment": "一年内到期的非流动负债"},  # 没有
    {"name": "oth_cur_liab", "comment": "其他流动负债"},  # 没有
    {"name": "total_cur_liab", "comment": "流动负债合计"},
    {"name": "bond_payable", "comment": "应付债券"},  # 没有
    {"name": "lt_payable", "comment": "长期应付款"},
    {"name": "specific_payables", "comment": "专项应付款"},  # 没有
    {"name": "estimated_liab", "comment": "预计负债"},  # 没有
    {"name": "defer_tax_liab", "comment": "递延所得税负债"},  # 没有
    {"name": "defer_inc_non_cur_liab", "comment": "递延收益-非流动负债"},  # 没有
    {"name": "oth_ncl", "comment": "其他非流动负债"},  # 没有
    {"name": "total_ncl", "comment": "非流动负债合计"},
    {"name": "depos_oth_bfi", "comment": "同业和其它金融机构存放款项"},  # 没有
    {"name": "deriv_liab", "comment": "衍生金融负债"},  # 没有
    {"name": "depos", "comment": "吸收存款"},  # 没有
    {"name": "agency_bus_liab", "comment": "代理业务负债"},  # 没有
    {"name": "oth_liab", "comment": "其他负债"},  # 没有
    {"name": "prem_receiv_adva", "comment": "预收保费"},  # 没有
    {"name": "depos_received", "comment": "存入保证金"},  # 没有
    {"name": "ph_invest", "comment": "保户储金及投资款"},  # 没有
    {"name": "reser_une_prem", "comment": "未到期责任准备金"},  # 没有
    {"name": "reser_outstd_claims", "comment": "未决赔款准备金"},  # 没有
    {"name": "reser_lins_liab", "comment": "寿险责任准备金"},  # 没有
    {"name": "reser_lthins_liab", "comment": "长期健康险责任准备金"},  # 没有
    {"name": "indept_acc_liab", "comment": "独立账户负债"},  # 没有
    {"name": "pledge_borr", "comment": "其中:质押借款"},  # 没有
    {"name": "indem_payable", "comment": "应付赔付款"},  # 没有
    {"name": "policy_div_payable", "comment": "应付保单红利"},  # 没有
    {"name": "total_liab", "comment": "负债合计"},
    {"name": "treasury_share", "comment": "减:库存股"},  # 没有
    {"name": "ordin_risk_reser", "comment": "一般风险准备"},  # 没有
    {"name": "forex_differ", "comment": "外币报表折算差额"},  # 没有
    {"name": "invest_loss_unconf", "comment": "未确认的投资损失"},  # 没有
    {"name": "minority_int", "comment": "少数股东权益"},
    {
        "name": "total_hldr_eqy_exc_min_int",
        "comment": "股东权益合计(不含少数股东权益)",
    },  # 没有
    {"name": "total_hldr_eqy_inc_min_int", "comment": "股东权益合计"},
    {"name": "total_liab_hldr_eqy", "comment": "负债和股东权益合计"},
    {"name": "lt_payroll_payable", "comment": "长期应付职工薪酬"},  # 没有
    {"name": "oth_comp_income", "comment": "其他综合收益"},
    {"name": "oth_eqt_tools", "comment": "其他权益工具"},  # 没有
    {"name": "oth_eqt_tools_p_shr", "comment": "其他权益工具(优先股)"},  # 没有
    {"name": "lending_funds", "comment": "融出资金"},  # 没有
    {"name": "acc_receivable", "comment": "应收款项"},  # 没有
    {"name": "st_fin_payable", "comment": "应付短期融资款"},  # 没有
    {"name": "payables", "comment": "应付款项"},  # 没有
    {"name": "hfs_assets", "comment": "持有待售的资产"},  # 没有
    {"name": "hfs_sales", "comment": "持有待售的负债"},  # 没有
    {"name": "cost_fin_assets", "comment": "以摊余成本计量的金融资产"},  # 没有
    {
        "name": "fair_value_fin_assets",
        "comment": "以公允价值计量且其变动计入其他综合收益的金融资产",
    },  # 没有
    {"name": "contract_assets", "comment": "合同资产"},  # 没有
    {"name": "contract_liab", "comment": "合同负债"},  # 没有
    {"name": "accounts_receiv_bill", "comment": "应收票据及应收账款"},  # 没有
    {"name": "accounts_pay", "comment": "应付票据及应付账款"},  # 没有
    {"name": "oth_rcv_total", "comment": "其他应收款(合计)（元）"},  # 没有
    {"name": "fix_assets_total", "comment": "固定资产(合计)(元)"},  # 没有
    {"name": "cip_total", "comment": "在建工程"},
    {"name": "oth_pay_total", "comment": "其他应付款(合计)(元)"},
    {"name": "long_pay_total", "comment": "长期应付款"},
    {"name": "debt_invest", "comment": "债权投资(元)"},  # 没有
    {"name": "oth_debt_invest", "comment": "其他债权投资(元)"},  # 没有
    {"name": "oth_eq_invest", "comment": "其他权益工具投资(元)"},  # 没有
    {"name": "oth_illiq_fin_assets", "comment": "其他非流动金融资产(元)"},  # 没有
    {"name": "oth_eq_ppbond", "comment": "其他权益工具:永续债(元)"},  # 没有
    {"name": "receiv_financing", "comment": "应收款项融资"},  # 没有
    {"name": "use_right_assets", "comment": "使用权资产"},  # 没有
    {"name": "lease_liab", "comment": "租赁负债"},  # 没有
    {"name": "update_flag", "comment": "更新标识"},
]
cashflow_columns_info = [
    {"name": "ts_code", "comment": "TS股票代码"},
    {"name": "ann_date", "comment": "公告日期"},
    {"name": "f_ann_date", "comment": "实际公告日期"},
    {"name": "end_date", "comment": "报告期"},
    {"name": "comp_type", "comment": "公司类型(1一般工商业2银行3保险4证券)"},
    {"name": "report_type", "comment": "报表类型"},
    {"name": "end_type", "comment": "报告期类型"},
    {"name": "net_profit", "comment": "净利润"},
    {"name": "finan_exp", "comment": "财务费用"},
    {
        "name": "c_fr_sale_sg",
        "comment": "销售商品、提供劳务收到的现金",
    },  # 销售商品提供劳务收到的现金 没有顿号合理吗
    {"name": "recp_tax_rends", "comment": "收到的税费返还"},
    {"name": "n_depos_incr_fi", "comment": "客户存款和同业存放款项净增加额"},  # 没有
    {"name": "n_incr_loans_cb", "comment": "向中央银行借款净增加额"},  # 没有
    {"name": "n_inc_borr_oth_fi", "comment": "向其他金融机构拆入资金净增加额"},  # 没有
    {"name": "prem_fr_orig_contr", "comment": "收到原保险合同保费取得的现金"},  # 没有
    {"name": "n_incr_insured_dep", "comment": "保户储金净增加额"},  # 没有
    {"name": "n_reinsur_prem", "comment": "收到再保业务现金净额"},  # 没有
    {"name": "n_incr_disp_tfa", "comment": "处置交易性金融资产净增加额"},  # 没有
    {"name": "ifc_cash_incr", "comment": "收取利息和手续费净增加额"},  # 没有
    {"name": "n_incr_disp_faas", "comment": "处置可供出售金融资产净增加额"},  # 没有
    {"name": "n_incr_loans_oth_bank", "comment": "拆入资金净增加额"},  # 没有
    {"name": "n_cap_incr_repur", "comment": "回购业务资金净增加额"},  # 没有
    {"name": "c_fr_oth_operate_a", "comment": "收到其他与经营活动有关的现金"},
    {"name": "c_inf_fr_operate_a", "comment": "经营活动现金流入小计"},
    {"name": "c_paid_goods_s", "comment": "购买商品、接受劳务支付的现金"},
    {"name": "c_paid_to_for_empl", "comment": "支付给职工以及为职工支付的现金"},
    {"name": "c_paid_for_taxes", "comment": "支付的各项税费"},
    {"name": "n_incr_clt_loan_adv", "comment": "客户贷款及垫款净增加额"},  # 没有
    {"name": "n_incr_dep_cbob", "comment": "存放央行和同业款项净增加额"},  # 没有
    {
        "name": "c_pay_claims_orig_inco",
        "comment": "支付原保险合同赔付款项的现金",
    },  # 没有
    {"name": "pay_handling_chrg", "comment": "支付手续费的现金"},  # 没有
    {"name": "pay_comm_insur_plcy", "comment": "支付保单红利的现金"},  # 没有
    {"name": "oth_cash_pay_oper_act", "comment": "支付其他与经营活动有关的现金"},
    {"name": "st_cash_out_act", "comment": "经营活动现金流出小计"},
    {"name": "n_cashflow_act", "comment": "经营活动产生的现金流量净额"},
    {"name": "oth_recp_ral_inv_act", "comment": "收到其他与投资活动有关的现金"},
    {"name": "c_disp_withdrwl_invest", "comment": "收回投资收到的现金"},  # 没有
    {"name": "c_recp_return_invest", "comment": "取得投资收益收到的现金"},
    {
        "name": "n_recp_disp_fiolta",
        "comment": "处置固定资产、无形资产和其他长期资产收回的现金净额",
    },
    {
        "name": "n_recp_disp_sobu",
        "comment": "处置子公司及其他营业单位收到的现金净额",
    },  # 没有
    {"name": "stot_inflows_inv_act", "comment": "投资活动现金流入小计"},
    {
        "name": "c_pay_acq_const_fiolta",
        "comment": "购建固定资产、无形资产和其他长期资产支付的现金",
    },
    {"name": "c_paid_invest", "comment": "投资支付的现金"},
    {"name": "n_disp_subs_oth_biz", "comment": "取得子公司及其他营业单位支付的现金净额"},  # 没有
    {"name": "oth_pay_ral_inv_act", "comment": "支付其他与投资活动有关的现金"},  # 没有
    {"name": "n_incr_pledge_loan", "comment": "质押贷款净增加额"},  # 没有
    {"name": "stot_out_inv_act", "comment": "投资活动现金流出小计"},
    {"name": "n_cashflow_inv_act", "comment": "投资活动产生的现金流量净额"},
    {"name": "c_recp_borrow", "comment": "取得借款收到的现金"},
    {"name": "proc_issue_bonds", "comment": "发行债券收到的现金"},  # 没有
    {"name": "oth_cash_recp_ral_fnc_act", "comment": "收到其他与筹资活动有关的现金"},
    {"name": "stot_cash_in_fnc_act", "comment": "筹资活动现金流入小计"},
    {"name": "free_cashflow", "comment": "企业自由现金流量"},
    {"name": "c_prepay_amt_borr", "comment": "偿还债务支付的现金"},
    {
        "name": "c_pay_dist_dpcp_int_exp",
        "comment": "分配股利、利润或偿付利息支付的现金",
    },
    {
        "name": "incl_dvd_profit_paid_sc_ms",
        "comment": "其中:子公司支付给少数股东的股利、利润",  # 没有
    },
    {
        "name": "oth_cashpay_ral_fnc_act",
        "comment": "支付其他与筹资活动有关的现金",
    },  # 没有
    {"name": "stot_cashout_fnc_act", "comment": "筹资活动现金流出小计"},
    {"name": "n_cash_flows_fnc_act", "comment": "筹资活动产生的现金流量净额"},
    {"name": "eff_fx_flu_cash", "comment": "汇率变动对现金及现金等价物的影响"},
    {"name": "n_incr_cash_cash_equ", "comment": "现金及现金等价物净增加额"},
    {"name": "c_cash_equ_beg_period", "comment": "加：期初现金及现金等价物余额"},
    {"name": "c_cash_equ_end_period", "comment": "期末现金及现金等价物余额"},
    {"name": "c_recp_cap_contrib", "comment": "吸收投资收到的现金"},
    {
        "name": "incl_cash_rec_saims",
        "comment": "其中:子公司吸收少数股东投资收到的现金",
    },  # 没有
    {"name": "uncon_invest_loss", "comment": "未确认投资损失"},  # 没有
    {"name": "prov_depr_assets", "comment": "资产减值准备"},
    {
        "name": "depr_fa_coga_dpba",
        "comment": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    },
    {"name": "amort_intang_assets", "comment": "无形资产摊销"},
    {"name": "lt_amort_deferred_exp", "comment": "长期待摊费用摊销"},
    {"name": "decr_deferred_exp", "comment": "待摊费用减少"},  # 没有
    {"name": "incr_acc_exp", "comment": "预提费用增加"},
    {"name": "loss_disp_fiolta", "comment": "处置固定资产、无形资产和其他长期资产的损失"},
    {"name": "loss_scr_fa", "comment": "固定资产报废损失"},  # 没有
    {"name": "loss_fv_chg", "comment": "公允价值变动损失"},  # 没有
    {"name": "invest_loss", "comment": "投资损失"},  # 没有
    {"name": "decr_def_inc_tax_assets", "comment": "递延所得税资产减少"},  # 没有
    {"name": "incr_def_inc_tax_liab", "comment": "递延所得税负债增加"},  # 没有
    {"name": "decr_inventories", "comment": "存货的减少"},  # 没有
    {"name": "decr_oper_payable", "comment": "经营性应收项目的减少"},  # 没有
    {"name": "incr_oper_payable", "comment": "经营性应付项目的增加"},  # 没有
    {"name": "others", "comment": "其他"},  # 没有
    {
        "name": "im_net_cashflow_oper_act",
        "comment": "经营活动产生的现金流量净额(间接法)",  # 没有
    },
    {"name": "conv_debt_into_cap", "comment": "债务转为资本"},  # 没有
    {
        "name": "conv_copbonds_due_within_1y",
        "comment": "一年内到期的可转换公司债券",  # 没有
    },
    {"name": "fa_fnc_leases", "comment": "融资租入固定资产"},  # 没有
    {
        "name": "im_n_incr_cash_equ",
        "comment": "现金及现金等价物净增加额(间接法)",  # 没有
    },
    {"name": "net_dism_capital_add", "comment": "拆出资金净增加额"},  # 没有
    {"name": "net_cash_rece_sec", "comment": "代理买卖证券收到的现金净额(元)"},  # 没有
    {"name": "credit_impa_loss", "comment": "信用减值损失"},  # 没有
    {"name": "use_right_asset_dep", "comment": "使用权资产折旧"},  # 没有
    {"name": "oth_loss_asset", "comment": "其他资产减值损失"},  # 没有
    {"name": "end_bal_cash", "comment": "现金的期末余额"},  # 没有
    {"name": "beg_bal_cash", "comment": "减:现金的期初余额"},  # 没有
    {"name": "end_bal_cash_equ", "comment": "加:现金等价物的期末余额"},
    {"name": "beg_bal_cash_equ", "comment": "减:现金等价物的期初余额"},
    {"name": "update_flag", "comment": "更新标识"},
]
income_columns_info = [
    {"name": "ts_code", "comment": "TS代码"},
    {"name": "ann_date", "comment": "公告日期"},
    {"name": "f_ann_date", "comment": "实际公告日期"},
    {"name": "end_date", "comment": "报告期"},
    {"name": "comp_type", "comment": "公司类型(1一般工商业2银行3保险4证券)"},
    {"name": "end_type", "comment": "报告期类型"},
    {"name": "basic_eps", "comment": "基本每股收益"},  # 没有
    {"name": "diluted_eps", "comment": "稀释每股收益"},
    {"name": "total_revenue", "comment": "营业总收入"},
    {"name": "revenue", "comment": "营业收入"},
    {"name": "int_income", "comment": "利息收入"},  # 没有
    {"name": "prem_earned", "comment": "已赚保费"},  # 没有
    {"name": "comm_income", "comment": "手续费及佣金收入"},  # 没有
    {"name": "n_commis_income", "comment": "手续费及佣金净收入"},  # 没有
    {"name": "n_oth_income", "comment": "其他经营净收益"},  # 没有
    {"name": "n_oth_b_income", "comment": "加:其他业务净收益"},  # 没有
    {"name": "prem_income", "comment": "保险业务收入"},  # 没有
    {"name": "out_prem", "comment": "减:分出保费"},  # 没有
    {"name": "une_prem_reser", "comment": "提取未到期责任准备金"},  # 没有
    {"name": "reins_income", "comment": "其中:分保费收入"},  # 没有
    {"name": "n_sec_tb_income", "comment": "代理买卖证券业务净收入"},  # 没有
    {"name": "n_sec_uw_income", "comment": "证券承销业务净收入"},  # 没有
    {"name": "n_asset_mg_income", "comment": "受托客户资产管理业务净收入"},  # 没有
    {"name": "oth_b_income", "comment": "其他业务收入"},  # 没有
    {"name": "fv_value_chg_gain", "comment": "加:公允价值变动净收益"},  # 没有
    {"name": "invest_income", "comment": "加:投资净收益"},  # 没有
    {"name": "ass_invest_income", "comment": "其中:对联营企业和合营企业的投资收益"},
    {"name": "forex_gain", "comment": "加:汇兑净收益"},  # 没有
    {"name": "total_cogs", "comment": "营业总成本"},
    {"name": "oper_cost", "comment": "营业成本"},
    {"name": "int_exp", "comment": "减:利息支出"},  # 没有
    {"name": "comm_exp", "comment": "减:手续费及佣金支出"},  # 没有
    {"name": "biz_tax_surchg", "comment": "营业税金及附加"},
    {"name": "sell_exp", "comment": "销售费用"},
    {"name": "admin_exp", "comment": "管理费用"},
    {"name": "fin_exp", "comment": "财务费用"},
    {"name": "assets_impair_loss", "comment": "资产减值损失"},
    {"name": "prem_refund", "comment": "退保金"},  # 没有
    {"name": "compens_payout", "comment": "赔付总支出"},  # 没有
    {"name": "reser_insur_liab", "comment": "提取保险责任准备金"},  # 没有
    {"name": "div_payt", "comment": "保户红利支出"},  # 没有
    {"name": "reins_exp", "comment": "分保费用"},  # 没有
    {"name": "oper_exp", "comment": "营业支出"},  # 没有
    {"name": "compens_payout_refu", "comment": "减:摊回赔付支出"},  # 没有
    {"name": "insur_reser_refu", "comment": "减:摊回保险责任准备金"},  # 没有
    {"name": "reins_cost_refund", "comment": "减:摊回分保费用"},  # 没有
    {"name": "other_bus_cost", "comment": "其他业务成本"},
    {"name": "operate_profit", "comment": "营业利润"},
    {"name": "non_oper_income", "comment": "加:营业外收入"},
    {"name": "non_oper_exp", "comment": "减:营业外支出"},
    {"name": "nca_disploss", "comment": "其中：非流动资产处置净损失"},
    {"name": "total_profit", "comment": "利润总额"},
    {"name": "income_tax", "comment": "所得税费用"},
    {"name": "n_income", "comment": "净利润(含少数股东损益)"},  # 没有
    {"name": "n_income_attr_p", "comment": "净利润(不含少数股东损益)"},  # 没有
    {"name": "minority_gain", "comment": "少数股东损益"},
    {"name": "oth_compr_income", "comment": "其他综合收益（利润表）"},
    {"name": "t_compr_income", "comment": "综合收益总额"},
    {"name": "compr_inc_attr_p", "comment": "归属于母公司所有者的综合收益总额"},
    {"name": "compr_inc_attr_m_s", "comment": "归属于少数股东的综合收益总额"},
    {"name": "ebit", "comment": "息税前利润"},
    {"name": "ebitda", "comment": "息税折旧摊销前利润"},
    {"name": "insurance_exp", "comment": "保险业务支出"},  # 没有
    {"name": "undist_profit", "comment": "年初未分配利润"},  # 没有
    {"name": "distable_profit", "comment": "可分配利润"},  # 没有
    {"name": "rd_exp", "comment": "研发费用"},  # 没有
    {"name": "fin_exp_int_exp", "comment": "财务费用:利息费用"},  # 没有
    {"name": "fin_exp_int_inc", "comment": "财务费用:利息收入"},  # 没有
    {"name": "transfer_surplus_rese", "comment": "盈余公积转入"},  # 没有
    {"name": "transfer_housing_imprest", "comment": "住房周转金转入"},  # 没有
    {"name": "transfer_oth", "comment": "其他转入"},  # 没有
    {"name": "adj_lossgain", "comment": "调整以前年度损益"},  # 没有
    {"name": "withdra_legal_surplus", "comment": "提取法定盈余公积"},  # 没有
    {"name": "withdra_legal_pubfund", "comment": "提取法定公益金"},  # 没有
    {"name": "withdra_biz_devfund", "comment": "提取企业发展基金"},  # 没有
    {"name": "withdra_rese_fund", "comment": "提取储备基金"},  # 没有
    {"name": "withdra_oth_ersu", "comment": "提取任意盈余公积金"},  # 没有
    {"name": "workers_welfare", "comment": "职工奖金福利"},  # 没有
    {"name": "distr_profit_shrhder", "comment": "可供股东分配的利润"},  # 没有
    {"name": "prfshare_payable_dvd", "comment": "应付优先股股利"},  # 没有
    {"name": "comshare_payable_dvd", "comment": "应付普通股股利"},  # 没有
    {"name": "capit_comstock_div", "comment": "转作股本的普通股股利"},  # 没有
    #     {
    #     "name": "net_after_nr_lp_correct",
    #
    #     "comment": "扣除非经常性损益后的归属于上市公司股东的净利润"  # 扣除非经常性损益后的净利润（更正前） 没有这个字段
    # },
    {"name": "oth_income", "comment": "其他收益"},  # 没有
    {"name": "asset_disp_income", "comment": "资产处置收益"},  # 没有
    {"name": "continued_net_profit", "comment": "持续经营净利润"},  # 没有
    {"name": "end_net_profit", "comment": "终止经营净利润"},  # 没有
    {"name": "credit_impa_loss", "comment": "信用减值损失"},  # 没有
    {"name": "net_expo_hedging_benefits", "comment": "净敞口套期收益"},  # 没有
    {"name": "oth_impair_loss_assets", "comment": "其他资产减值损失"},  # 没有
    # {"name": "total_opcost", "comment": "营业总成本2"},# 没有
    {"name": "amodcost_fin_assets", "comment": "以摊余成本计量的金融资产终止确认收益"},  # 没有
    {"name": "update_flag", "comment": "更新标识"},
]
fina_columns_info = [
    {"name": "ts_code", "comment": "TS代码"},
    {"name": "ann_date", "comment": "公告日期"},
    {"name": "end_date", "comment": "报告期"},
    {"name": "eps", "comment": "基本每股收益"},  # 没有
    {"name": "dt_eps", "comment": "稀释每股收益"},
    {"name": "total_revenue_ps", "comment": "每股营业总收入（元）"},
    {"name": "revenue_ps", "comment": "每股营业收入（元）"},
    {"name": "capital_rese_ps", "comment": "每股资本公积（元）"},
    {"name": "surplus_rese_ps", "comment": "每股盈余公积（元）"},
    {"name": "undist_profit_ps", "comment": "每股未分配利润（元）"},
    {"name": "extra_item", "comment": "非经常性损益"},
    {"name": "profit_dedt", "comment": "扣除非经常性损益后的归属于上市公司股东的净利润"},
    {"name": "gross_margin", "comment": "毛利"},
    {"name": "current_ratio", "comment": "流动比率"},
    {"name": "quick_ratio", "comment": "速动比率"},
    {"name": "cash_ratio", "comment": "保守速动比率"},
    {"name": "invturn_days", "comment": "存货周转天数"},
    {"name": "arturn_days", "comment": "应收账款周转天数（含应收票据）"},
    {"name": "inv_turn", "comment": "存货周转率"},
    {"name": "ar_turn", "comment": "应收账款周转率（含应收票据）"},
    {"name": "ca_turn", "comment": "流动资产周转率"},
    {"name": "fa_turn", "comment": "固定资产周转率"},
    {"name": "assets_turn", "comment": "总资产周转率"},
    {"name": "op_income", "comment": "经营活动净收益"},
    {"name": "valuechange_income", "comment": "价值变动净收益"},
    {"name": "interst_income", "comment": "利息费用"},  # 没有
    {"name": "daa", "comment": "折旧与摊销"},
    {"name": "ebit", "comment": "息税前利润"},
    {"name": "ebitda", "comment": "息税折旧摊销前利润"},
    {"name": "fcff", "comment": "企业自由现金流量"},
    {"name": "fcfe", "comment": "股权自由现金流量"},
    {"name": "current_exint", "comment": "无息流动负债"},
    {"name": "noncurrent_exint", "comment": "无息非流动负债"},
    {"name": "interestdebt", "comment": "带息债务"},
    {"name": "netdebt", "comment": "净债务"},
    {"name": "tangible_asset", "comment": "有形资产"},  # 没有
    {"name": "working_capital", "comment": "营运资金"},  # 没有
    {"name": "networking_capital", "comment": "营运流动资本"},  # 没有
    {"name": "invest_capital", "comment": "全部投入资本"},  # 没有
    {"name": "retained_earnings", "comment": "留存收益"},
    {"name": "diluted2_eps", "comment": "期末摊薄每股收益（元）"},
    {"name": "bps", "comment": "每股净资产（元）"},
    {"name": "ocfps", "comment": "每股经营活动产生的现金流量净额（元）"},
    {"name": "retainedps", "comment": "每股留存收益（元）"},
    {"name": "cfps", "comment": "每股现金流量净额（元）"},
    {"name": "ebit_ps", "comment": "每股息税前利润（元）"},
    {"name": "fcff_ps", "comment": "每股企业自由现金流量（元）"},
    {"name": "fcfe_ps", "comment": "每股股东自由现金流量（元）"},
    {"name": "netprofit_margin", "comment": "销售净利率（百分比）"},
    {"name": "grossprofit_margin", "comment": "销售毛利率（百分比）"},
    {"name": "cogs_of_sales", "comment": "销售成本率"},  # 没有
    {"name": "expense_of_sales", "comment": "销售期间费用率（百分比）"},
    {"name": "profit_to_gr", "comment": "净利润比营业总收入"},
    {"name": "saleexp_to_gr", "comment": "销售费用/营业总收入"},  # 没有
    {"name": "adminexp_of_gr", "comment": "管理费用与营业总收入之比"},
    {"name": "finaexp_of_gr", "comment": "财务费用与营业总收入之比"},
    {"name": "impai_ttm", "comment": "资产减值损失/营业总收入"},  # 没有
    {"name": "gc_of_gr", "comment": "营业总成本与营业总收入之比"},
    {"name": "op_of_gr", "comment": "营业利润与营业总收入之比"},
    {"name": "ebit_of_gr", "comment": "息税前利润比营业总收入"},
    {"name": "roe", "comment": "净资产收益率ROE（摊薄）（百分比）"},
    {"name": "roe_waa", "comment": "净资产收益率ROE（加权）（百分比）"},
    {"name": "roe_dt", "comment": "净资产收益率ROETTM（扣非）（百分比）"},
    {"name": "roa", "comment": "总资产报酬率ROA（百分比）"},
    {"name": "npta", "comment": "总资产净利率ROA（百分比）"},
    {"name": "roic", "comment": "投入资本回报率ROIC（百分比）"},
    {"name": "roe_yearly", "comment": "年化净资产收益率"},  # 没有
    {"name": "roa2_yearly", "comment": "年化总资产报酬率"},  # 没有
    {"name": "roe_avg", "comment": "平均净资产收益率(增发条件)"},  # 没有
    {"name": "opincome_of_ebt", "comment": "经营活动净收益比利润总额"},
    {"name": "investincome_of_ebt", "comment": "价值变动净收益比利润总额"},
    {"name": "n_op_profit_of_ebt", "comment": "营业外收支净额比利润总额"},
    {"name": "tax_to_ebt", "comment": "所得税比利润总额"},
    {"name": "dtprofit_to_profit", "comment": "扣除非经常性损益的净利润比净利润"},
    {"name": "salescash_to_or", "comment": "销售商品提供劳务收到的现金比营业收入"},
    {"name": "ocf_to_or", "comment": "经营活动产生的现金流量净额比营业收入"},
    {"name": "ocf_to_opincome", "comment": "经营活动产生的现金流量净额比经营活动净收益"},
    {"name": "capitalized_to_da", "comment": "资本支出/折旧和摊销"},  # 没有
    {"name": "debt_to_assets", "comment": "资产负债率"},
    {"name": "assets_to_eqt", "comment": "权益乘数"},  # 没有
    {"name": "dp_assets_to_eqt", "comment": "权益乘数(杜邦分析)"},
    {"name": "ca_to_assets", "comment": "流动资产比总资产（百分比）"},
    {"name": "nca_to_assets", "comment": "非流动资产比总资产（百分比）"},
    {"name": "tbassets_to_totalassets", "comment": "有形资产比总资产（百分比）"},
    {"name": "int_to_talcap", "comment": "带息负债比全部投入资本（百分比）"},
    {"name": "eqt_to_talcapital", "comment": "归属母公司股东的权益比全部投入资本（百分比）"},
    {"name": "currentdebt_to_debt", "comment": "流动负债比负债合计（百分比）"},
    {"name": "longdeb_to_debt", "comment": "非流动负债比负债合计（百分比）"},
    {"name": "ocf_to_shortdebt", "comment": "经营活动产生的现金流量净额比流动负债"},
    {"name": "debt_to_eqt", "comment": "产权比率"},
    {"name": "eqt_to_debt", "comment": "归属母公司股东的权益比负债合计"},  # 没有
    {
        "name": "eqt_to_interestdebt",
        "comment": "归属母公司股东的权益比带息债务",  # 没有
    },
    {"name": "tangibleasset_to_debt", "comment": "有形资产比负债合计"},
    {"name": "tangasset_to_intdebt", "comment": "有形资产比带息债务"},
    {"name": "tangibleasset_to_netdebt", "comment": "有形资产比净债务"},
    {"name": "ocf_to_debt", "comment": "经营活动产生的现金流量净额比负债合计"},
    {"name": "ocf_to_interestdebt", "comment": "经营活动产生的现金流量净额比带息债务"},
    {"name": "ocf_to_netdebt", "comment": "经营活动产生的现金流量净额比净债务"},
    {"name": "ebit_to_interest", "comment": "已获利息倍数(EBIT/利息费用)"},  # 没有
    {
        "name": "longdebt_to_workingcapital",
        "comment": "长期债务与营运资金比率",
    },  # 没有
    {"name": "ebitda_to_debt", "comment": "息税折旧摊销前利润/负债合计"},  # 没有
    {"name": "turn_days", "comment": "营业周期"},
    {"name": "roa_yearly", "comment": "年化总资产净利率"},  # 没有
    {"name": "roa_dp", "comment": "总资产净利率ROA（百分比）"},  # 没有
    {"name": "fixed_assets", "comment": "固定资产"},
    {"name": "profit_prefin_exp", "comment": "扣除财务费用前营业利润"},  # 没有
    {"name": "non_op_profit", "comment": "非营业利润"},
    {"name": "op_to_ebt", "comment": "营业利润／利润总额"},  # 没有
    {"name": "nop_to_ebt", "comment": "非营业利润／利润总额"},  # 没有
    {"name": "ocf_to_profit", "comment": "经营活动产生的现金流量净额／营业利润"},  # 没有
    {"name": "cash_to_liqdebt", "comment": "货币资金／流动负债"},  # 没有
    {
        "name": "cash_to_liqdebt_withinterest",
        "comment": "货币资金／带息流动负债",
    },  # 没有
    {"name": "op_to_liqdebt", "comment": "营业利润／流动负债"},  # 没有
    {"name": "op_to_debt", "comment": "营业利润／负债合计"},  # 没有
    {"name": "roic_yearly", "comment": "年化投入资本回报率"},  # 没有
    {"name": "total_fa_trun", "comment": "固定资产合计周转率"},  # 没有
    {"name": "profit_to_op", "comment": "利润总额／营业收入"},  # 没有
    {"name": "q_opincome", "comment": "经营活动单季度净收益"},  # 没有
    {"name": "q_investincome", "comment": "价值变动单季度净收益"},  # 没有
    {"name": "q_dtprofit", "comment": "扣除非经常损益后的单季度净利润"},  # 没有
    {"name": "q_eps", "comment": "每股收益(单季度)"},  # 没有
    {"name": "q_netprofit_margin", "comment": "销售净利率(单季度)"},  # 没有
    {"name": "q_gsprofit_margin", "comment": "销售毛利率(单季度)"},  # 没有
    {"name": "q_exp_to_sales", "comment": "销售期间费用率(单季度)"},  # 没有
    {"name": "q_profit_to_gr", "comment": "净利润／营业总收入(单季度)"},  # 没有
    {"name": "q_saleexp_to_gr", "comment": "销售费用／营业总收入 (单季度)"},  # 没有
    {"name": "q_adminexp_to_gr", "comment": "管理费用／营业总收入 (单季度)"},  # 没有
    {"name": "q_finaexp_to_gr", "comment": "财务费用／营业总收入 (单季度)"},  # 没有
    {
        "name": "q_impair_to_gr_ttm",
        "comment": "资产减值损失／营业总收入(单季度)",  # 没有
    },
    {"name": "q_gc_to_gr", "comment": "营业总成本／营业总收入 (单季度)"},  # 没有
    {"name": "q_op_to_gr", "comment": "营业利润／营业总收入(单季度)"},  # 没有
    {"name": "q_roe", "comment": "净资产收益率(单季度)"},  # 没有
    {"name": "q_dt_roe", "comment": "净资产单季度收益率(扣除非经常损益)"},  # 没有
    {"name": "q_npta", "comment": "总资产净利润(单季度)"},  # 没有
    {
        "name": "q_opincome_to_ebt",
        "comment": "经营活动净收益／利润总额(单季度)",
    },  # 没有
    {
        "name": "q_investincome_to_ebt",
        "comment": "价值变动净收益／利润总额(单季度)",
    },  # 没有
    {
        "name": "q_dtprofit_to_profit",
        "comment": "扣除非经常损益后的净利润／净利润(单季度)",
    },  # 没有
    {
        "name": "q_salescash_to_or",
        "comment": "销售商品提供劳务收到的现金／营业收入(单季度)",
    },  # 没有
    {
        "name": "q_ocf_to_sales",
        "comment": "经营活动产生的现金流量净额／营业收入(单季度)",
    },  # 没有
    {
        "name": "q_ocf_to_or",
        "comment": "经营活动产生的现金流量净额／经营活动净收益(单季度)",
    },  # 没有
    {"name": "basic_eps_yoy", "comment": "基本每股收益同比增长率（百分比）"},
    {"name": "dt_eps_yoy", "comment": "稀释每股收益同比增长率（百分比）"},
    {"name": "cfps_yoy", "comment": "每股经营活动产生的现金流量净额同比增长率（百分比）"},
    {"name": "op_yoy", "comment": "营业利润同比增长率（百分比）"},
    {"name": "ebt_yoy", "comment": "利润总额同比增长率（百分比）"},
    {"name": "netprofit_yoy", "comment": "归属母公司股东的净利润同比增长率（百分比）"},
    {
        "name": "dt_netprofit_yoy",
        "comment": "归属母公司股东的净利润同比增长率（扣非）（百分比）",
    },
    {"name": "ocf_yoy", "comment": "经营活动产生的现金流量净额同比增长率（百分比）"},
    {"name": "roe_yoy", "comment": "净资产收益率同比增长率（摊薄）（百分比）"},
    {"name": "bps_yoy", "comment": "每股净资产相对年初增长率（百分比）"},
    {"name": "assets_yoy", "comment": "资产总计相对年初增长率（百分比）"},
    {"name": "eqt_yoy", "comment": "归属母公司股东的权益相对年初增长率（百分比）"},
    {"name": "tr_yoy", "comment": "营业总收入同比增长率（百分比）"},
    {"name": "or_yoy", "comment": "营业收入同比增长率(%)"},  # 没有
    {"name": "q_gr_yoy", "comment": "营业总收入同比增长率(%)(单季度)"},  # 没有
    {"name": "q_gr_qoq", "comment": "营业总收入环比增长率(%)(单季度)"},  # 没有
    {"name": "q_sales_yoy", "comment": "营业收入同比增长率(%)(单季度)"},  # 没有
    {"name": "q_sales_qoq", "comment": "营业收入环比增长率(%)(单季度)"},  # 没有
    {"name": "q_op_yoy", "comment": "营业利润同比增长率(%)(单季度)"},  # 没有
    {"name": "q_op_qoq", "comment": "营业利润环比增长率(%)(单季度)"},  # 没有
    {"name": "q_profit_yoy", "comment": "净利润同比增长率(%)(单季度)"},  # 没有
    {"name": "q_profit_qoq", "comment": "净利润环比增长率(%)(单季度)"},  # 没有
    {
        "name": "q_netprofit_yoy",
        "comment": "归属母公司股东的净利润同比增长率(%)(单季度)",
    },  # 没有
    {
        "name": "q_netprofit_qoq",
        "comment": "归属母公司股东的净利润环比增长率(%)(单季度)",
    },  # 没有
    {"name": "equity_yoy", "comment": "净资产同比增长率"},  # 没有
    {"name": "rd_exp", "comment": "研发费用"},  # 没有
    {"name": "update_flag", "comment": "更新标识"},
]
