# import pandas as pd
#
# from jindata.checker.check_content import get_base_info
# from jindata.ddb_client import create_session_from_env
#
# # TODO 检查交易日是否都有数据
#
# start_date = "2016-01-01"
# end_date = "2016-06-01"
#
# ddb_session = create_session_from_env()
# dolphindb_data = get_base_info(start_date, end_date)
#
#
# # 批量获取所有相关的证券曾用名信息
# all_stock_codes = dolphindb_data["symbol"].unique()
# # 检查数据
# issues = []
# issues.append(f"开始检查{start_date}-{end_date} base_info 数据")
# # i = 0
# for symbol, dd_row in dolphindb_data.groupby("symbol"):
#     print(symbol)
#     # symbol = 'SH600000'
#     ts_code = symbol[2:] + "." + symbol[:2]
#     # if '600110.SH' == ts_code:
#     #     break
#     matched_row = tushare_data[tushare_data["ts_code"] == ts_code]
#
#     # 1、检查股票代码
#     if matched_row.empty:
#         issues.append(f"Tushare 中没有发现：{ts_code}-{symbol}")
#         continue
#
#     # 2、检查交易所编码
#     if symbol[:2] != matched_row["ts_code"].values[0].split(".")[-1]:
#         issues.append(
#             f"检查交易所出现错误： - DolphinDB: {symbol[:2]}, Tushare: {matched_row['ts_code'].values[0].split('.')[-1]}"
#         )
#
#     # 3、检查上市日期
#     def check_list_date(row):
#         if row["上市日期"] != row["list_date"]:
#             issues.append(
#                 f"检查上市日期出现错误：{row['symbol']} 时间：{row['timestamp'].strftime('%Y%m%d')} - DolphinDB: {row['上市日期']}, Tushare: {row['list_date']}"
#             )
#
#     dd_row["list_date"] = pd.to_datetime(matched_row["list_date"].values[0])
#     dd_row.apply(check_list_date, axis=1)
#
#     # 4、检查停牌信息
#     def check_suspend_timing(row):
#         if row["是否停牌"] != row["Tushare是否停牌"]:
#             issues.append(
#                 f"检查是否停牌出现错误：{row['symbol']} 时间：{row['timestamp'].strftime('%Y%m%d')} - DolphinDB: {row['是否停牌']}, Tushare: {row['Tushare是否停牌']}"
#             )
#
#     dd_row["Tushare是否停牌"] = False
#
#     if tushare_suspend_info.empty:
#         dd_row["Tushare是否停牌"] = False
#     else:
#         tushare_suspend_info["Tushare停牌日期"] = pd.to_datetime(
#             tushare_suspend_info["trade_date"]
#         )
#         dd_row["timestamp"] = pd.to_datetime(dd_row["timestamp"])
#         # 使用security_code作为键来合并dd_row和suspend_info
#         dd_row = dd_row.merge(
#             tushare_suspend_info[["Tushare停牌日期"]],
#             left_on="timestamp",
#             right_on="Tushare停牌日期",
#             how="left",
#         )
#         dd_row["Tushare是否停牌"] = dd_row.apply(
#             lambda x: True if pd.notna(x["Tushare停牌日期"]) else False, axis=1
#         )
#     dd_row.apply(check_suspend_timing, axis=1)
#
#     # 5、检查证券名称
#     def check_name_consistency(row):
#         # 定义一个函数，接收一行数据，并对比 '名称' 和 'name' 列
#         if row["名称"] != row["name"]:
#             issues.append(
#                 f"检查证券名称出现错误：{row['symbol']} 时间：{row['timestamp'].strftime('%Y%m%d')} - DolphinDB: {row['名称']}, Tushare: {row['name']}"
#             )
#
#     if name_change_info.empty:  # 可能从未改过名
#         if len(set(dd_row["名称"])) != 1:
#             issues.append(
#                 f"检查证券名称出现错误：{symbol}  - DolphinDB: {set(dd_row['名称'])}, Tushare 为空,但是DolphinDB中有多个名称"
#             )
#     else:
#         name_change_info.sort_values(by="start_date", inplace=True)
#         name_change_info["start_date"] = pd.to_datetime(name_change_info["start_date"])
#         check_name_data = pd.merge_asof(
#             dd_row,
#             name_change_info[["start_date", "name"]],
#             left_on="timestamp",
#             right_on="start_date",
#             direction="backward",
#         )
#         check_name_data.apply(check_name_consistency, axis=1)
#     # 6、检查数据量，获取交易日期，和上时间进行对比
#     # i += 1
#     # if i > 30:
#     #     break
# issues.append(f"结束检查{start_date}-{end_date} base_info 数据")
#
# # 记录问题
# with open(f"{start_date}-{end_date} base_info 检查结果.txt", "w") as f:
#     for issue in issues:
#         f.write(f"{issue}\n")
