from datetime import datetime
from typing import List
import numpy as np
import pandas as pd
import tushare as ts
from dotenv import load_dotenv
from joblib import Parallel, delayed
from pandas import DataFrame

from jindata.ddb_client import create_session_from_env
from loguru import logger
import time
from EmQuantAPI import c
from jindata.zvt import zvt_env

#
loginResult = c.start(f"ForceLogin=1,UserName={zvt_env['em_username']},PassWord={zvt_env['em_password']}", "", )


def create_table(
        ddb_session,
        db_path: str,
        table_name: str,
        cols: str,
        col_types: str,
        partition_cols: str = None,
):
    script = f"""
        dbPath = "{db_path}"
        tableName = "{table_name}"
        db=database(dbPath)
        if(existsTable(dbPath, tableName)){{
            dropTable(db, tableName)
        }}
        columns1={cols}
        type1={col_types}
        db.{"createPartitionedTable" if partition_cols else "createTable"}(table(1000:0,columns1,type1),tableName, {partition_cols or ""})
    """
    ddb_session.run(script)


def generate_stock_trade_day_date(ddb_session, start, end):
    date_array = ddb_session.run(f"""getMarketCalendar('SSE', {start} , {end})""")
    return date_array


def get_stocktrade_day(ddb_session, format):
    end = datetime.now().date().strftime("%Y.%m.%d")
    result = ddb_session.run(f"""getMarketCalendar('SSE', 2005.01.01 , {end})""")
    temp = result.tolist()
    result = [i.strftime(format) for i in temp]
    return result


def generate_stock_trade_day_code(ddb_session, first_code):
    code = ddb_session.run(
        f"""select code,(code+"."+upper(exchange))as code_str from loadTable('dfs://cn_zvt','stock') where left(code,3) ='{first_code}' and exchange in `sz`sh""")
    code_list = code.values.tolist()
    return code_list


def generate_bj_trade_day_code(ddb_session):
    code = ddb_session.run(
        f"""select code,(code+"."+upper(exchange))as code_str from loadTable('dfs://cn_zvt','stock') where exchange ='bj'""")
    code_list = code.values.tolist()
    return code_list

def generate_start_date(ddb_session):
    start_date = ddb_session.run(
        f"""select min(list_date) as start_date from loadTable('dfs://cn_zvt','stock') where exchange ='bj'""")
    start_date = start_date['start_date'][0]
    return start_date.strftime("%Y-%m-%d")


def split_list_average_n(origin_list, n):
    for i in range(0, len(origin_list), n):
        yield origin_list[i:i + n]


def deal_stock1dblock(ddb_session, db_path, start, end):
    table_name = "stock1dblock"
    # create_table(
    #     ddb_session,
    #     db_path,
    #     table_name=table_name,
    #     cols="`时间`指数代码`行业指数名称`行业指数代码",
    #     col_types="`DATETIME`SYMBOL`SYMBOL`SYMBOL",
    #     partition_cols="`时间",
    # )
    date_array = generate_stock_trade_day_date(ddb_session, start, end)
    code_list = generate_stock_trade_day_code(ddb_session)
    all_data = []
    for date in date_array:
        print(f"{date}日期数据获取中")
        # for i in code_list:
        dt_str = np.datetime_as_string(date, unit='D')
        date = pd.to_datetime(dt_str)
        code = "000155"
        # code = i[0]
        code_str = "000155.SZ"
        # code_str = i[1]
        data1 = c.css(f"{code_str}", "BLHSWSINDCODE,BLHSWSIND", f"EndDate={dt_str},ClassiFication=1")
        if data1.Data[f'{code_str}'][0] == None:
            continue
        data2 = c.css(f"{code_str}", "BLHSWSINDCODE,BLHSWSIND", f"EndDate={dt_str},ClassiFication=2")
        data3 = c.css(f"{code_str}", "BLHSWSINDCODE,BLHSWSIND", f"EndDate={dt_str},ClassiFication=3")
        industry_name1, industry_name2, industry_name3 = data1.Data[f'{code_str}'][1], data2.Data['000155.SZ'][1], \
            data3.Data['000155.SZ'][1]
        industry_code1, industry_code2, industry_code3 = data1.Data[f'{code_str}'][0].split('.')[0], \
            data2.Data['000155.SZ'][0].split('.')[0], data3.Data['000155.SZ'][0].split('.')[0]
        df_data = {
            '时间': [date, date, date],
            '股票代码': [code, code, code],
            '行业指数名称': [industry_name1, industry_name2, industry_name3],
            '行业指数代码': [industry_code1, industry_code2, industry_code3]
        }
        df = pd.DataFrame(data=df_data)
        all_data.append(df)
    result = pd.concat(all_data)
    t = ddb_session._s.loadTable(tableName=table_name, dbPath="dfs://choice")
    t.append(ddb_session._s.table(data=result))

    # logger.info(f"正在导入{}日期数据")


def deal_suspend_d(ddb_session, db_path, first_code, start_date, end_date):
    table_name = "trade_status"
    # create_table(
    #     ddb_session,
    #     db_path,
    #     table_name=table_name,
    #     cols="`交易日期`代码`交易状态",
    #     col_types="`DATETIME`SYMBOL`SYMBOL",
    #     partition_cols="`交易日期",
    # )
    stock_trade_day = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    # 2005-01-01到2005-03-14的数据已经导入完成，周日上午任务完成后补，这个任务分成两部分，股票代码000开头的先全部导入，其余的后面再导入
    stock_trade_day = [i for i in stock_trade_day if i >= start_date and i <= end_date]
    # stock_trade_day = [i for i in stock_trade_day if i > "2023-12-07"]
    code_list = generate_stock_trade_day_code(ddb_session, first_code)
    code_str = []
    for i in code_list:
        code_str.append(i[1])
    for date in stock_trade_day:
        all_data = []
        logger.info(f"{date}日期数据获取中")
        codes = split_list_average_n(code_str, 50)
        for code in codes:
            df = c.css(code, "TRADESTATUS", f"TradeDate={date},ispandas=1")
            df.reset_index(inplace=True)
            df["交易日期"] = pd.to_datetime(date)
            df["交易状态"] = df["TRADESTATUS"]
            df['代码'] = df['CODES'].apply(lambda x: x[:6])
            # df['id'] = date + '-' + df['代码']
            # result = df[["id", "交易日期", "代码", "交易状态"]]
            result = df[["交易日期", "代码", "交易状态"]]
            all_data.append(result)
        results = pd.concat(all_data)
        t = ddb_session._s.loadTable(tableName=table_name, dbPath=db_path)
        t.append(ddb_session._s.table(data=results))

def deal_bj_trade_status(ddb_session, db_path, end_date):
    table_name = "trade_status"
    # create_table(
    #     ddb_session,
    #     db_path,
    #     table_name=table_name,
    #     cols="`交易日期`代码`交易状态",
    #     col_types="`DATETIME`SYMBOL`SYMBOL",
    #     partition_cols="`交易日期",
    # )
    stock_trade_day = get_stocktrade_day(ddb_session, "%Y-%m-%d")
    start_date = generate_start_date(ddb_session)
    # 2005-01-01到2005-03-14的数据已经导入完成，周日上午任务完成后补，这个任务分成两部分，股票代码000开头的先全部导入，其余的后面再导入
    stock_trade_day = [i for i in stock_trade_day if i >= start_date and i <= end_date]
    # stock_trade_day = [i for i in stock_trade_day if i > "2023-12-07"]
    code_list = generate_bj_trade_day_code(ddb_session)
    code_str = []
    for i in code_list:
        code_str.append(i[1])
    for date in stock_trade_day:
        all_data = []
        logger.info(f"{date}日期数据获取中")
        codes = split_list_average_n(code_str, 50)
        for code in codes:
            df = c.css(code, "TRADESTATUS", f"TradeDate={date},ispandas=1")
            df.reset_index(inplace=True)
            df["交易日期"] = pd.to_datetime(date)
            df["交易状态"] = df["TRADESTATUS"]
            df['代码'] = df['CODES'].apply(lambda x: x[:6])
            # df['id'] = date + '-' + df['代码']
            # result = df[["id", "交易日期", "代码", "交易状态"]]
            result = df[["交易日期", "代码", "交易状态"]]
            all_data.append(result)
        results = pd.concat(all_data)
        t = ddb_session._s.loadTable(tableName=table_name, dbPath=db_path)
        t.append(ddb_session._s.table(data=results))


if __name__ == "__main__":
    load_dotenv()  # take environment variables from .env.
    # 创建我们dolphindb的对象
    ddb_session = create_session_from_env()
    # 指定数据库路径
    db_path = "dfs://choice2"
    # deal_stock1dblock(ddb_session, db_path, start='2017.01.01', end='2020.01.01') 补充非京交所的股票交易状态
    # deal_suspend_d(ddb_session, db_path, "600", "2005-03-15", "2023-12-07")
    # deal_bj_trade_status补充京交所的股票交易状态
    deal_bj_trade_status(ddb_session,db_path,"2023-12-07")
    ddb_session.close()
