import tushare as ts
import numpy as np
import pandas as pd
from loguru import logger
from fuzzywuzzy import process
from jindata.checker.check_content import (
    get_symbols,
    get_factor_names,
    get_finance_factors_1Y,
    get_report_date,
)
from jindata.ddb_client import create_session_from_env
from jindata.checker.tushare_columns_info import (
    balancesheet_columns_info,
    cashflow_columns_info,
    income_columns_info,
)

start_date = "2016-01-01"
end_date = "2016-06-01"

dfs_name = "finance_factors_1Y"
factors_table = "cn_finance_factors_1Q"

logger.add(
    f"{start_date}-{end_date} cn_finance_factors_1Q 检查结果.log",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
)


ddb_session = create_session_from_env()
dolphindb_data = get_symbols()

# 使用Tushare获取数据
ts.set_token("856e62cca82eaeb5634edf18d6b08f971859763b1d963cf321436213")
pro = ts.pro_api()

factors_name = get_factor_names(
    dfs_name,
    factors_table,
)
factor_name_1Y = factors_name.factor_name.unique()

# 批量获取所有相关的证券曾用名信息
all_stock_codes = dolphindb_data["symbol"].unique()
# 检查数据
issues = []
logger.warning(f"开始检查 {start_date}-{end_date} finance_factors_1Y 数据")

all_reprt_date = get_report_date(start_date=start_date, end_date=end_date)
# tushare的资产负债表字段map
balancesheet_columns_map = {
    item["name"]: item["comment"] for item in balancesheet_columns_info
}
cashflow_columns_map = {item["name"]: item["comment"] for item in cashflow_columns_info}
income_columns_map = {item["name"]: item["comment"] for item in income_columns_info}

# 设置相似度阈值，只有当相似度高于此值时才认为两个列名相似
similarity_threshold = 95
# 指定容差值
tolerance = 1e-6


def get_tushare_data(ts_code, period, columns_info, func):
    tushare_df = func(period=period, ts_code=ts_code)
    tushare_df.rename(columns=columns_info, inplace=True)
    tushare_df.sort_values(by="更新标识", inplace=True)
    tushare_df.drop_duplicates(subset=["实际公告日期", "报告期"], keep="last", inplace=True)
    return tushare_df


def fetch_and_compare(
    tushare_df,
    dolphindb_factor_names,
    tushare_column_map,
    similarity_threshold,
    tolerance,
):
    tushare_df.rename(columns=tushare_column_map, inplace=True)
    tushare_df.sort_values(by="更新标识", inplace=True)
    tushare_df.drop_duplicates(subset=["实际公告日期", "报告期"], keep="last", inplace=True)
    tushare_columns = tushare_df.columns.tolist()

    for dolphindb_factor_name in dolphindb_factor_names:
        if "报告期" in dolphindb_factor_name or "symbol" in dolphindb_factor_name:
            continue

        best_match = process.extractOne(dolphindb_factor_name, tushare_columns)
        if best_match[1] >= similarity_threshold:
            matched_factor_name = best_match[0]
            tushare_factor_data = tushare_df[matched_factor_name].fillna(0).values[0]
            dolphindb_factor_data = (
                period_factor_data[dolphindb_factor_name].fillna(0).values[0]
            )

            if (
                isinstance(tushare_factor_data, np.ndarray)
                and len(tushare_factor_data) > 1
            ):
                tushare_factor_data = tushare_factor_data[0]
            if not np.isclose(
                dolphindb_factor_data, tushare_factor_data, atol=tolerance
            ):
                logger.warning(
                    f"检查因子：{dolphindb_factor_name}, 发现不同, 股票代码为 {symbol},确实报告期为： "
                    f"{period} - DolphinDB: {dolphindb_factor_name}: "
                    f"{dolphindb_factor_data}, Tushare: "
                    f"{matched_factor_name}: {tushare_factor_data}"
                )


for symbol, _dd_row in dolphindb_data.groupby("symbol"):
    ts_code = symbol[2:] + "." + symbol[:2]

    factor_data = get_finance_factors_1Y(
        factor_names=factor_name_1Y,
        start_date=start_date,
        end_date=end_date,
        symbols=[symbol],
    )

    factor_data = factor_data.pivot_table(
        index=["symbol", "报告期"], columns="factor_name", values="value"
    )
    factor_data.reset_index(inplace=True, drop=False)

    symbol_report_date = (
        all_reprt_date[all_reprt_date["symbol"] == symbol].end_date.unique().tolist()
    )

    missing_report_date = set(pd.to_datetime(symbol_report_date)) - set(factor_data.报告期)
    if missing_report_date:
        logger.warning(
            f"检查因子：报告期, 发现缺失值, 股票代码为 {symbol},确实报告期为： {missing_report_date} "
        )

    dolphindb_factor_names = factor_data.columns

    for period in symbol_report_date:
        period_factor_data = factor_data[factor_data["报告期"] == pd.to_datetime(period)]
        tushare_balancesheet_df = get_tushare_data(
            ts_code, period, balancesheet_columns_map, pro.balancesheet_vip
        )
        tushare_cashflow_df = get_tushare_data(
            ts_code, period, cashflow_columns_map, pro.cashflow_vip
        )
        tushare_income_df = get_tushare_data(
            ts_code, period, income_columns_map, pro.income_vip
        )

        fetch_and_compare(
            tushare_balancesheet_df,
            dolphindb_factor_names,
            balancesheet_columns_map,
            similarity_threshold,
            tolerance,
        )
        fetch_and_compare(
            tushare_cashflow_df,
            dolphindb_factor_names,
            cashflow_columns_map,
            similarity_threshold,
            tolerance,
        )
        fetch_and_compare(
            tushare_income_df,
            dolphindb_factor_names,
            income_columns_map,
            similarity_threshold,
            tolerance,
        )

logger.info(f"结束检查{start_date}-{end_date} finance_factors_1Y 数据")
