with open(file="./daily_indicator.txt", encoding="utf8", mode="r") as f:
    data = f.readlines()
    str2 = ""
    str1 = ""
    num1 = 0
    for i in data:
        a = "`" + i.split("\t")[0][:-1]
        a = a.replace(" ", "")
        a = a.replace("(", "")
        a = a.replace(")", "")
        a = a.replace(":", "")
        a = a.replace("（", "")
        a = a.replace("）", "")
        a = a.replace("-", "")
        a = a.replace("：", "")
        str1 += a
        num1 += 1
    print(str1)
    print(num1)

    # for j in data:
    #
    #     b = j.split('\t')[1]
    #     if b == 'float':
    #         b = 'double'.upper()
    #     if b == 'str':
    #         b = 'symbol'.upper()
    #     c = '`' + b
    #     str2 += c
    # print(str2)

    num = 0
    for i in data:
        num += 1
        a = "'" + i.split("\t")[0] + "'" + ","
        a = a.replace(" ", "")
        a = a.replace("(", "")
        a = a.replace(")", "")
        a = a.replace(":", "")
        str2 += a
    print(str2)
    print(num)
