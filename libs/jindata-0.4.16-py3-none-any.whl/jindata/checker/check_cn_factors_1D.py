import tushare as ts
import pandas as pd
from loguru import logger

from jindata.checker.check_content import (
    get_symbols,
    get_factor_names,
    get_factors_6m,
)
from jindata.ddb_client import create_session_from_env

start_date = "2016-01-01"
end_date = "2016-06-01"

dfs_name = "factors_6M"
factors_table = "cn_factors_1D"

logger.add(
    f"{start_date}-{end_date} cn_factors_1D 检查结果.log",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
)
ddb_session = create_session_from_env()
dolphindb_data = get_symbols()

# 使用Tushare获取数据
ts.set_token("856e62cca82eaeb5634edf18d6b08f971859763b1d963cf321436213")
pro = ts.pro_api()

factors_name = get_factor_names(
    dfs_name,
    factors_table,
)
factor_name_6M = factors_name.factor_name.unique()

# 批量获取所有相关的证券曾用名信息
all_stock_codes = dolphindb_data["symbol"].unique()
# 检查数据
issues = []
logger.info(f"开始检查 {start_date}-{end_date} factors_6M 数据")

for symbol, _dd_row in dolphindb_data.groupby("symbol"):
    ts_code = symbol[2:] + "." + symbol[:2]
    ts_daily_hq = pro.query(
        "daily",
        ts_code=ts_code,
        start_date=start_date.replace("-", ""),
        end_date=end_date.replace("-", ""),
    )
    ts_daily_hq["trade_date"] = pd.to_datetime(ts_daily_hq["trade_date"])

    factor_data = get_factors_6m(
        start_date,
        end_date,
        factor_names=factor_name_6M,
        symbols=[symbol],
    )
    # 1、检查非停牌日的空值
    for _index, row in factor_data.iterrows():
        if ts_daily_hq["trade_date"].isin([row["timestamp"]]).any():
            for col in factor_data.columns:
                # 检查是否有空值
                if pd.isna(row[col]):
                    logger.warning(
                        f"检查因子：{col}, 发现缺失值, 股票代码为 {row['symbol']},时间戳为 {row['timestamp'].strftime('%Y%m%d')} "
                    )

    # 2、检查非停牌日的重复值和缺失的交易日
    for tradedata in ts_daily_hq["trade_date"]:
        row_df = factor_data[factor_data["timestamp"].isin([row["timestamp"]])]
        if row_df.shape[0] == 0:
            logger.warning(
                f"检查factors_6M,发现缺失交易日, 股票代码为 {row['symbol']},时间戳为 {tradedata.strftime('%Y%m%d')} "
            )
        elif row_df.shape[0] > 1:
            logger.warning(
                f"检查factors_6M,发现交易日有多条数据, 股票代码为 {row['symbol']},时间戳为 {tradedata.strftime('%Y%m%d')} "
            )

logger.info(f"结束检查{start_date}-{end_date} factors_6M 数据")
