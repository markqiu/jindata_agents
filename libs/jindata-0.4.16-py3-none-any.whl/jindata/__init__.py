from jindata.__version__ import VERSION
